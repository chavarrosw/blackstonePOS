# Production Servers

* \\\\PSWEB01\inetpub$\sites_prod\mobile.blackstonepos.com
* \\\\PSWEB02\inetpub$\sites_prod\mobile.blackstonepos.com

## Source Control

http://pstfs:8080/tfs/Pinserve_Collection/_git/BlackstonePOS