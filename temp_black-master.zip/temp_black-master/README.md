# Blackston POS

Link to [POS](https://mobile.blackstonepos.com)

## Main Components

* BsUiMessages

## BsUiMessages

BsUiMessages is a constant object for registering messages meant to be displayed for users with feedback and notification purposes.