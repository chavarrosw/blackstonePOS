(function () {
  'use strict';

  angular.module('posClient')
    .constant('API_URL', 'https://bsapi.pinserve.com/api/')
    //.constant('API_URL', 'http://bsapi-dev.pinserve.com/api/')
    // .constant('API_URL', 'http://localhost:50230/api/')
    .constant('ANALYTICS', {
      api: 'https://analytics.pinserve.com/'
    })
    .constant('BsUiMessages', {
      serverError: {
        message: 'Something went wrong!'
      },
      invalidForm: {
        message: 'Oops, form is invalid.'
      },
      successMessages: {
        activation: 'Success Activation'
      },
      smsReceiptSuccess: {
        message: 'Receipt sms has been sent.'
      },
      smsReceiptFailed: {
        message: 'Oops, failed to send receipt sms.'
      },
      unauthorizedLocation: "Unauthorized location",
      unauthorizedLogin: "Unauthorized login."

    })
    .constant('POSGlobalConfig', {
      localStorageExpirationInMinutes: 60,
      blackstone: {
        customerServicePhone: '1-800-483-2891',
        logoUrl: '/assets/images/temp/BSTONE_POS_Logo.png',
        internationalTopUpImageUrl: '/assets/images/temp/BS_International_Topup_BG.png',
        wirelessImageUrl: '/assets/images/temp/BS_Wireless_Recharge_BG.png',
        longDistanceImageUrl: '/assets/images/temp/BS_Long_Distance_BG.png',
        pinlessImageUrl: '/assets/images/temp/BS_Pinless_Product_BG.png'
      },
      fullcarga: {
        customerServicePhone: '1-888-684-7323',
        logoUrl: '/assets/images/temp/Full_Carga_USA_Logo.jpg',
        internationalTopUpImageUrl: '/assets/images/temp/International_Topup_BG.png',
        wirelessImageUrl: '/assets/images/temp/Wireless_Recharge_BG.png',
        longDistanceImageUrl: '/assets/images/temp/Long_Distance_BG.png',
        pinlessImageUrl: '/assets/images/temp/Pinless_Product_BG.png'
      }
    })
    .constant('InquiryMap', {
      '301630': 'app/inquiry/comcast/comcast-index.html'
    })
    .constant('ActivationMap', {
      'AT&T': 'app/activation/att/activation-index-att.html',
      'BLACK WIRELESS': 'app/activation/blackwireless/activation-index-blackwireless.html',
      'MANGO WIRELESS': 'app/activation/blackwireless/activation-index-blackwireless.html'
    })
    .constant('URL_BACKEND', 'https://recarga.rapiditopr.com')
    //.constant('URL_BACKEND', 'http://localhost:8950')
})();
