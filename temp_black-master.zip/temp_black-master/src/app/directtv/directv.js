(function () {
  'use strict';

  angular.module('posClient')
    // might ngInject
    // list all categories
    .controller('IndexDirectTvCategoriesCtrl', ['$scope', '$routeParams', 'DirectTvFactory', '$location',
      function ($scope, $routeParams, DirectTvFactory, $location) {
        // var category = $routeParams.category;
        $scope.useMostPopular = false;
        $scope.isMostPopular = false;
        $scope.useAcronym = false;
        $scope.useConfig = false;
        $scope.type = $location.path().split('/').splice(1, 1).toString();
        $scope.mostpopular = 'category/popular';

        $scope.getDirectTvCategories = function () {
          DirectTvFactory.getDirectTvCategories().then(
            function (data) {
              $scope.items = data;
              // console.log(data);
            },
            function (error) {
              void 0;
            }
          );
        };
        $scope.getDirectTvCategories();
      }
    ])
    // might ngInject
    // list products by category or all
    .controller('IndexDirectTvByCategoryCtrl', ['$scope', '$routeParams', 'DirectTvFactory', 'ProdsFactory', '$location',
      function ($scope, $routeParams, DirectTvFactory, ProdsFactory, $location) {

        $scope.useMostPopular = true;
        $scope.isMostPopular = true;
        $scope.useAcronym = false;
        $scope.showAcronym = true;
        $scope.useConfig = true;
        $scope.configPath = 'categories';
        $scope.configDisplay = 'Category';
        $scope.type = $location.path().split('/').splice(1, 1).toString();
        $scope.mostpopular = 'popular';

        var category = $routeParams.category;

        $scope.getDirectTvProductsByCategory = function () {
          DirectTvFactory.getDirectTvProductsByCategory(category).then(
            function (data) {
              $scope.items = data;
              void 0;
            },
            function (error) {
              void 0;
            }
          );
        };
        $scope.getDirectTvProductsByCategory();
      }
    ])
    // might ngInject
    .controller('showDirectTvCtrl', ['$scope', 'DirectTvFactory', 'ProdsFactory', '$routeParams', 'Notification', 'localStorageService', 'AuthenticationFactory', 'SharedFunctions', '$uibModal', 'ConfirmationFactory',
      function ($scope, DirectTvFactory, ProdsFactory, $routeParams, Notification, localStorageService, AuthenticationFactory, SharedFunctions, $uibModalInstance, ConfirmationFactory) {

        var id = $routeParams.product;

        $scope.getDirectTvProduct = function () {
          DirectTvFactory.getDirectTvProduct(id).then(
            function (data) {
              $scope.item = data;
              // console.log(data);
            },
            function (error) {
              void 0;
            }
          );
        };
        $scope.getDirectTvProduct();

        // FORM SUBMIT HANDLER
        $scope.submit = function (form) {
          void 0;

          // Trigger validation flag.
          $scope.submitted = true;

          // If form is invalid, return and let AngularJS show validation errors.
          if (form.$invalid) {
            Notification.error('Check errors below (in red color)');
            return;
          } else {
            $scope.isBlocked = true;

            var userInfo = AuthenticationFactory.getUserInfo();

            var order = {
              MerchantId: userInfo.MerchantId,
              MerchantPassword: userInfo.MerchantPassword, // string
              OperatorName: userInfo.userName, // string
              ProfileId: userInfo.profileId, // int
              TerminalId: userInfo.terminalId, // int

              Amount: $scope.item.price,
              // PhoneNumber: $scope.phoneNumber.value,
              ProductMainCode: $scope.item.id
              // CountryCode: $scope.item.DialCountryCode
            };

            void 0;
            // console.log(userInfo);

            ProdsFactory.doBlackstonePosOperation(order).then(
              function (response) {

                //console.log(response);

                if (response.Status === 200 || response.Status === 203) {

                  var orderResultText = response.Status === 200 ? 'Order processed!' : 'Order placed. Pending for further Execution!';

                  $scope.showReceipt = true;
                  $scope.submitted = false;
                  Notification.success(orderResultText);

                  $scope.receipt = response.Data;

                  //console.log('from transaction:' + receipt);

                } else {
                  Notification.error(response.ErrorMessage);
                  // Trigger validation flag.
                  $scope.isBlocked = false;
                }


              },
              function (error) {
                $scope.isBlocked = false;
                Notification.error('Invalid Credentials');
              }
            );

            $scope.showReceipt = false;
          }
        };

        // PRINT RECEIPT
        $scope.printInfo = function () {
          window.print();
        };

        // SEND RECEIPT AS SMS
        $scope.sendSms = function (form) {

          // Trigger validation flag.
          $scope.submittedSms = true;

          // If form is invalid, return and let AngularJS show validation errors.
          if (form.$invalid) {
            Notification.error('Check form errors');
            return;
          } else {
            var receipt = $scope.receipt;
            var phone = $scope.phoneToSend;

            ConfirmationFactory.sendConfirmationSms(receipt, phone).then(
              function (response) {
                $scope.submittedSms = false;

                if (response.Status === 200) {
                  Notification.success('The Receipt has been sent as sms successfully!');
                } else {
                  Notification.error('Sorry, an error has happened. Please, try again.');
                }
                void 0;
              },
              function (response) {
                Notification.error(response.ErrorMessage);
              }
            );
          }
        };

        // SEND RECEIPT AS EMAIL
        $scope.sendEmail = function (form) {

          // Trigger validation flag.
          $scope.submittedEmail = true;

          // If form is invalid, return and let AngularJS show validation errors.
          if (form.$invalid) {
            Notification.error('Check form errors');
            return;

          } else {
            var receipt = $scope.receipt;
            var email = $scope.emailToSend;

            ConfirmationFactory.sendConfirmationEmail(receipt, email).then(
              function (response) {
                $scope.submittedEmail = false;

                if (response.Status === 200) {
                  Notification.success('The Receipt has been sent as sms successfully!');
                } else {
                  Notification.error('Sorry, an error has happened. Please, try again.');
                }
                void 0;
              },
              function (response) {
                Notification.error(response.ErrorMessage);
                void 0;
              }
            );
          }
        };

        // Modal (ui.bootstrap.modal). In Docs (item) pass modal size, here pass the single item object
        $scope.open = function (items) {
          var info = {
            firstItem: $scope.item.productName,
            secondItem: null,
            thirdItem: $scope.item.price
          };

          // angular.extend(dst, src);
          items = angular.extend(items, info);
          // console.log(items);
          // console.log(JSON.stringify(items));

          var modalInstance = $uibModalInstance.open({
            templateUrl: 'app/products/_modal-product-tpl.html',
            controller: 'ModalInstanceCtrl',
            size: 'lg',
            windowClass: 'product-modal',
            resolve: {
              item: function () {
                return items;
              }
            }
          });

          modalInstance.result.then(function (selectedItem) {
            $scope.selected = selectedItem;
          }, function () {
            // $log.info('Modal dismissed at: ' + new Date());
          });
        };
      }
    ]);
}());

(function () {
  'use strict';
  angular.module('directTvServices', [])
    // might ngInject
    /* DIRECT TV */
    .factory('DirectTvFactory', ['$http', '$rootScope', 'API_URL', '$q', 'SharedFunctions', 'localStorageService', 'AuthenticationFactory',
      function ($http, $rootScope, API_URL, $q, SharedFunctions, localStorageService, AuthenticationFactory) {
        var arr = [];
        var userInfo = AuthenticationFactory.getUserInfo();
        var merchant = {
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword
        };

        return {
          // GET DIRECT TV CATEGORIES
          getDirectTvAllProducts: function (category) {
            var queryObj = {
              MerchantId: merchant.MerchantId,
              MerchantPassword: merchant.MerchantPassword,
              CategoryId: category
            };

            var deferred = $q.defer();

            $http.post(API_URL + 'DirectTv/GetDirectTvAllProducts', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  // console.log(arr);
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // GET DIRECT TV CATEGORIES
          getDirectTvCategories: function () {
            var queryObj = {
              MerchantId: merchant.MerchantId,
              MerchantPassword: merchant.MerchantPassword
            };

            var deferred = $q.defer();

            $http.post(API_URL + 'DirectTv/GetDirectTvCategories', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  void 0;
                  deferred.resolve(arr);
                },
                function (response) {
                  // console.log(response);
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // GET DIRECT TV PRODUCTS BY CATEGORY
          getDirectTvProductsByCategory: function (category) {
            var queryObj = {
              MerchantId: merchant.MerchantId,
              MerchantPassword: merchant.MerchantPassword,
              Category: category
            };

            var deferred = $q.defer();

            $http.post(API_URL + 'DirectTv/GetDirectTvProductsByCategory', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  // console.log(response);
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          getDirectTvProduct: function (id) {
            var queryObj = {
              MerchantId: merchant.MerchantId,
              MerchantPassword: merchant.MerchantPassword,
              ProductMainCode: id
            };
            // console.log(queryObj);

            var deferred = $q.defer();

            $http.post(API_URL + 'DirectTv/GetDirectTvProduct', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  void 0;
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          }
        };
      }
    ]);
}());
