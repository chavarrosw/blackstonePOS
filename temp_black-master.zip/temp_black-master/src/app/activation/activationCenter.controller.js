﻿(function () {
  'use strict';
  angular
    .module('posClient')
    .controller('ActivationController', ActivationController);

  ActivationController.$inject = ['$log', '$routeParams', '$scope', '$location', 'ConfirmationFactory', 'Black011ActivationService', 'ActivationMap', 'Notification', '$uibModal', 'SharedData', '$timeout', 'BsUiMessages'];

  function ActivationController($log, $routeParams, $scope, $location, ConfirmationFactory, Black011ActivationService, ActivationMap, Notification, $modal, SharedData, $timeout, BsUiMessages) {
    var vm = this;

    vm.activationTemplateUrl = '';
    vm.carrier = '';
    
    vm.presentPlan = function(plan) {
      return '$' + plan.Denominations[0] + ' - ' + plan.Name;
    };

    vm.groupId = $routeParams.groupId;

    vm.black011 = {
      plans: [],
      carriers: []
    };

    vm.selectTab = selectTab;
    vm.submitActivation = submitActivation;
    vm.openModal = openModal;
    vm.showReceipt = false;
    vm.showForm = true;

    vm.tabs = [{
      displayName: "Activation",
      name: "activation",
      active: true
    }, {
      displayName: "Porting",
      name: "porting",
      active: false
    }];

    vm.portingInformation = {};

    vm.activationForm = {
      acceptTermsAndConditions: false
      //REMOVE FROM HERE
      //            sim: "1234567890",
      //            email: "jdoe@example.com",
      //            contactPhone: "7863221111",
      //            addressOne: "12313 SW 29th St",
      //            addressTwo: "Apt 10B",
      //            addressCity: "Miami",
      //            addressState: "FL",
      //            zipCode: 33123,
      //Porting Fields
      //            requiredPortIn: true,
      //            portingPhoneNumber: '7863007263',
      //            portingFirstName: 'Jhon',
      //            portingLastName: 'Doe',
      //            portingAccountNumber: '123456789',
      //            portingPassword: '1306',
      // portingCarrier: vm.portingCarriers[0],
      //            portingZip: '33183'


    };

    // vm.portingForm = {

    // };

    function activate() {
      getPlans();      
    }

    

    activate();

    function selectTab(tab) {
      for (var i = 0; i < vm.tabs.length; i++) {
        vm.tabs[i].active = false;
      }

      tab.active = true;
    }

    function getPlans() {
      var plans = [];

      //Call Web API to get Plans, Dont forget Spinner!!!
      Black011ActivationService.getPlansByGrouperId(vm.groupId).then(function (data) {
        plans = data;

        if (plans.length > 0) {
          getPorInCarriersByProductMainCode(plans[0].Code);
        }

        //Select first plan, if no planId was passed in the route, find and select that one
        selectFormPlan(plans);        

        vm.black011.plans = plans;
        if (vm.black011.plans.length > 0) {
          vm.carrier = vm.black011.plans[0].CarrierName;
          vm.activationTemplateUrl = ActivationMap[vm.carrier];
          vm.message = vm.carrier + " Activation Center";
        }
      });
    }

    function selectFormPlan(plans) {
      if ($routeParams.code) {
        for (var i = 0; i < plans.length; i++) {
          if (plans[i].Code == $routeParams.code) {
            vm.activationForm.plan = plans[i];            
            return;
          }
        }
      }
      vm.activationForm.plan = plans[0];
    }

    function getPorInCarriersByProductMainCode(productMainCode) {
      Black011ActivationService.getPortInCarriersByProductMainCode(productMainCode)
        .then(function (data) {
          vm.portingCarriers = data;
        });
    }

    function submitActivation(valid) {
      if (valid) {
        var activationRequestObject = buildActivationRequestObject(vm.activationForm);

        SharedData.setActivationRequestObject(activationRequestObject);

        Black011ActivationService.activateNewBlack011(activationRequestObject).then(function (data) {
          if (data.Status != "200")
            if (data.ErrorMessage != null){
              Notification.error(data.ErrorMessage);
            }else{
              Notification.error(BsUiMessages.serverError.message);
            }
          else {
            Notification.success(BsUiMessages.successMessages.activation);
            //processActivationResponse(data.Data);
            vm.receipt = data.Data;

            // if (vm.activationForm.requiredPortIn)
            //   doPortInRequestWithLinkedOrderId(data.Order.Id);
            // else
            vm.showReceipt = true;
            vm.showForm = false;
              //showActivationResult();
          }
        }, function () {
          Notification.error(BsUiMessages.serverError.message);
        });
      }
    }

    // function buildActivationRequestObject(activationForm) {
    //   var jsonBody = {
    //     EzCode: activationForm.ezCode,
    //     SimNumber: activationForm.sim,
    //     Imei: activationForm.Imei,
    //     ProductId: activationForm.plan.Code,
    //     ProductName: activationForm.plan.Name,
    //     TotalAmount: activationForm.plan.DenominationsConfig[0].Denomination,
    //     First: activationForm.portingFirstName,
    //     Last: activationForm.portingLastName,
    //     Email: activationForm.email,
    //     ContactPhone: activationForm.contactPhone,
    //     AddressOne: activationForm.addressOne,
    //     AddressTwo: activationForm.addressTwo,
    //     City: activationForm.addressCity,
    //     State: activationForm.addressState,
    //     AreaCode: activationForm.AreaCode,
    //     Zip: activationForm.zipCode,
    //     RequirePortIn: activationForm.requiredPortIn
    //   };

    //   return jsonBody;
    // }

    function buildActivationRequestObject(activationForm) {
      var portingCarrier = true;
      if (activationForm.portingCarrier == null){
        portingCarrier = false;
      }
      
      var jsonBody = {        
        SimNumber: activationForm.sim,
        Imei: activationForm.Imei,
        AreaCode: activationForm.AreaCode,
        EZCodeNumber: activationForm.ezCode,
        ContactEmail: activationForm.email,
        ContactPhone: activationForm.contactPhone,
        ContactZipCode: activationForm.zipCode,
        PortInAfterActivate: activationForm.requiredPortIn,        
        FirstName: activationForm.portingFirstName,
        LastName: activationForm.portingLastName,
        StreetNumber : activationForm.StreetNumber,
        StreetName: activationForm.StreetName,
        AddressOne: activationForm.addressOne,
        AddressTwo: activationForm.addressTwo,
        City: activationForm.addressCity,
        State: activationForm.addressState,
        PhoneToPort: activationForm.portingPhoneNumber,
        OldAccountNumber: activationForm.portingAccountNumber,
        OldAccountPassword: activationForm.portingPassword,
        OldCarrierId: portingCarrier ? activationForm.portingCarrier.Id : "0",
        Amount: activationForm.plan.DenominationsConfig[0].Denomination,
        Fee: activationForm.plan.Fee,
        Tax: activationForm.plan.Tax,
        ProductMainCode: activationForm.plan.Code,
        E911: "0",
        SystemType: 4               
      };

      return jsonBody;
    }

    // function buildActivationRequestObject(activationForm) {
    //   var jsonBody = {        
    //     SimNumber: "890100000000000000",
    //     Imei: "127898756777789",
    //     AreaCode: "305",
    //     EZCodeNumber: "",
    //     ContactEmail: "eaguiar@Blackstoneonline.com",
    //     ContactPhone: "7863947971",
    //     ContactZipCode: "33165",
    //     PortInAfterActivate: "true",        
    //     FirstName: "Esteban",
    //     LastName: "Aguiare",
    //     StreetNumber : "9267 NW",
    //     StreetName: " 37th st",
    //     City: "Miami",
    //     State: "FL",
    //     PhoneToPort: "7867774444",
    //     OldAccountNumber: "123456789",
    //     OldAccountPassword: "zeratul",
    //     OldCarrierId: "1914",
    //     Amount: "35",
    //     Fee: "0",
    //     Tax: "0",
    //     ProductMainCode: "301659",
    //     E911: "0",
    //     SystemType: 4,
    //     OrderDate: "6/5/2018 4:29:09 PM"        
    //   };

    //   return jsonBody;
    // }

    function buildPortInRequestObject(activationForm, orderId) {
      var jsonBody = {
        ProductId: activationForm.plan.Code,
        RtrAmount: activationForm.plan.DenominationsConfig[0].Denomination,
        First: activationForm.portingFirstName,
        Last: activationForm.portingLastName,
        AccountNumber: activationForm.portingAccountNumber,
        AccountPassword: activationForm.portingPassword,
        ServiceZip: activationForm.portingZip,
        Email: activationForm.email,
        ContactPhone: activationForm.contactPhone,
        SimNumber: activationForm.sim,
        EzCode: activationForm.ezCode,
        NumberToPort: activationForm.portingPhoneNumber,
        OldCarrierId: activationForm.portingCarrier.Id,
        OldCarrierName: activationForm.portingCarrier.Name,
        OrderId: orderId
      };

      return jsonBody;
    }

    function processActivationResponse(data) {
      SharedData.setActivationResponse(data);
    }

    function doPortInRequestWithLinkedOrderId(orderId) {
      Notification.info('Port in request is being processed');

      var portInRequestObject = buildPortInRequestObject(vm.activationForm, orderId);

      SharedData.setPortInRequestObject(portInRequestObject);

      Black011ActivationService.requestPortIn(portInRequestObject).then(function (response) {
        if (response.data.ErrorCode && response.data.ErrorCode !== '0') {
          Notification.error('Port in failed!');
        } else
          Notification.success('Port in request success!');

        SharedData.setPortInResponse(response.data);
      }).catch(function (error) {
        SharedData.setPortInResponse(error.data);
        Notification.error('Port in request failed!');
      }).then(function (result) {
        showActivationResult();
      }).catch(function (error) {
        Notification.error('Redirecting to activation result page failed!');
      });

    }

    function showActivationResult() {
      $location.path('/pos/activation/result')
    }

    function resetActivationForm() {
      var temp = vm.activationForm.plan;
      vm.activationForm = {
        plan: temp
      };

      $scope.activation.$setPristine();
      $scope.activation.$setUntouched();
    }

    function openModal(items) {
      var info = {
        firstItem: "First Item",
        secondItem: "Second Item"
      };

      items = angular.extend(items, info);

      $modal.open({
        templateUrl: 'app/products/_modal-product-tpl.html',
        controller: 'ModalInstanceCtrl',
        size: 'lg',
        windowClass: 'product-modal',
        resolve: {
          item: function () {
            return items;
          }
        }
      });
    };
    // send receipt as sms
    vm.sendSms = function (form) {

      // Trigger validation flag.
      vm.submittedSms = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll()
        Notification.error(BsUiMessages.invalidForm.message);
        $log.debug(BsUiMessages.invalidForm.message);

      } else {

        // remove any previous alert
        Notification.clearAll();

        var receipt = vm.receipt;
        var phone = vm.phoneToSend;

        ConfirmationFactory.sendConfirmationSms(receipt, phone).then(
          function (response) {

            Notification.clearAll();
            vm.submittedSms = false;

            if (response.Status === 200) {
              Notification.success(BsUiMessages.smsReceiptSuccess.message);
              $log.debug(BsUiMessages.smsReceiptSuccess.message);
            } else {
              Notification.error(response.ErrorMessage);
              $log.debug(response);
            }
          },
          function (response) {
            Notification.error(response.ErrorMessage);
            $log.debug(response.ErrorMessage);
          }
        );
      }
    };
    

    // send receipt as email
    vm.sendEmail = function (form) {

      // Trigger validation flag.
      vm.submittedEmail = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll()
        Notification.error(BsUiMessages.invalidForm.message);
        $log.debug(BsUiMessages.invalidForm.message);

      } else {
        Notification.clearAll()

        var receipt = vm.receipt;
        var email = vm.emailToSend;

        ConfirmationFactory.sendConfirmationEmail(receipt, email).then(
          function (response) {

            Notification.clearAll()
            vm.submittedEmail = false;

            if (response.Status === 200) {
              Notification.success(BsUiMessages.smsReceiptSuccess.message);
              $log.debug(BsUiMessages.smsReceiptSuccess.message);
            } else {
              Notification.error(response.ErrorMessage);
              $log.debug(response.ErrorMessage);
            }
          },
          function (response) {
            Notification.error(response.ErrorMessage);
            $log.debug(response.ErrorMessage);
          }
        );
      }
    };
  }
}());
