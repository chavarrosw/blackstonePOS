(function () {
    'use strict';

    angular
        .module('posClient')
        .controller('RequestPortingController', RequestPortingController);

    RequestPortingController.$inject = ['$log', 'SharedData'];

    function RequestPortingController($log, SharedData) {
        var vm = this;
        vm.activationForm = SharedData.getActivationForm();
        vm.message = 'My Porting Controller';


        activate();

        ////////////////

        function activate() {}
    }
})();