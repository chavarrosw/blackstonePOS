﻿(function () {
  'use strict';

  angular
    .module('posClient')
    .service('Black011ActivationService', Black011ActivationService);

  Black011ActivationService.inject = ['$log', '$rootScope', '$http', '$q', 'API_URL', 'localStorageService', 'AuthenticationFactory'];

  function Black011ActivationService($log, $rootScope, $http, $q, API_URL, localStorageService, AuthenticationFactory) {
    

    var service = {
      getPlansByGrouperId: getPlansByGrouperId,
      activateNewBlack011: activateNewBlack011,
      requestPortIn: requestPortIn,
      getPortInCarriersByProductMainCode: getPortInCarriersByProductMainCode
    };

    var url = API_URL;

    return service;
    ////////////////

    function activateNewBlack011(activationRequestObject) {
      // var deferred = $q.defer();

      decorateWithAuthenticationFields(activationRequestObject);

      return $http.post(url + 'v2/orders/addactivatesimorder', activationRequestObject)
        .then(function (response) {
          return excecuteOrder(response.data);
        }, function (error) {
          return error;
        });


        // return $http.post(url + 'activationcenter/activatesim', activationRequestObject)
        // .then(function (response) {
        //   return response.data;
        // }, function (error) {
        //   return error;
        // });

      // .success(function (response) {
      //   deferred.resolve(response);
      // }).error(function (data) {
      //   $log.error(data);
      //   deferred.reject(data);
      // });
    }

    function excecuteOrder (data){

      if (data.Status != 200) {
        return data;
      }

      var jsonBody = {
        // OrderNumber: "1406402",
        // ProcessingMode : false, 
        OrderNumber: data.Ticket       
      };

      decorateWithAuthenticationFields(jsonBody);

      return $http.post(url + 'v2/orders/executeorder', jsonBody)
        .then(function (response) {
          return response.data;
        }, function (error) {
          return error;
        });
    }

    function requestPortIn(portInRequestObject) {
      var deferred = $q.defer();

      decorateWithAuthenticationFields(portInRequestObject);

      return $http.post(url + 'activationcenter/portin', portInRequestObject)
        .success(function (response) {
          deferred.resolve(response);
        }).error(function (data) {
          $log.error(data);
          deferred.reject(data);
        });
    }

    function getPlansByGrouperId(grouperId) {
      var userInfo = AuthenticationFactory.getUserInfo();
      var jsonBody = {
        MerchantId: userInfo.MerchantId,
        MerchantPassword: userInfo.MerchantPassword,
        GroupId: grouperId
      };
      return $http.post(url + 'products/getGrouperProducts', jsonBody).then(function (response) {
          return response.data.Data;
        },
        function (error) {
          $log.error(error);
        });
    }

    function getPortInCarriersByProductMainCode(productMainCode) {
      var jsonBody = {
        ProductMainCode: productMainCode
      };

      decorateWithAuthenticationFields(jsonBody);

      return $http.post(url + 'activationcenter/getPortInCarriersByProductMainCode', jsonBody)
        .then(function (response) {
          return response.data;
        }).catch(function (error) {
          $log.error(error);
        });
    }

    function decorateWithAuthenticationFields(jsonObject) {
      var userInfo = AuthenticationFactory.getUserInfo();
      jsonObject.MerchantId = userInfo.MerchantId;
      jsonObject.MerchantPassword = userInfo.MerchantPassword;
    }

  }
})();
