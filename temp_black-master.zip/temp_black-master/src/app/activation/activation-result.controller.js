(function () {
    'use strict';

    angular
        .module('posClient')
        .controller('ActivationResultController', ActivationResultController);

    ActivationResultController.$inject = ['$log', '$location', 'SharedData'];

    function ActivationResultController($log, $location, SharedData) {
        var vm = this;

        activate();

        ////////////////

        function activate() {
            vm.activationRequestObject = SharedData.getActivationRequestObject();
            if (!vm.activationRequestObject) {
                $location.path('/');
            } else {
                vm.activationResponse = SharedData.getActivationResponse();
                if (vm.activationRequestObject.RequirePortIn) {
                    vm.portInRequestObject = SharedData.getPortInRequestObject();
                    vm.portInResponse = SharedData.getPortInResponse();
                }

                SharedData.clearSharedData();
            }

        }
    }
})();