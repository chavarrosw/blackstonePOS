(function () {
  'use strict';

  angular
    .module('posClient')
    .factory('SunpassService', SunpassService);

  SunpassService.$inject = ['$http', '$rootScope', 'API_URL', '$q', 'SharedFunctions', 'localStorageService', 'AuthenticationFactory'];

  function SunpassService($http, $rootScope, API_URL, $q, SharedFunctions, localStorageService, AuthenticationFactory) {
    var arr = [];

    return {
      // get BILLERS by categories
      getSunpassTransporderInfo: function (transponder, item) {

        var userInfo = AuthenticationFactory.getUserInfo();

        var queryObj = {
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword,
          TransporderNumber: transponder,
          ProductCode : item.InquiryId,
          CarrierName : item.CarrierName
        };
        // console.log(queryObj);

        var deferred = $q.defer();

        $http.post(API_URL + 'v2/tolls/inquiry/transponder/', queryObj)
          .then(
            function (response) {
              arr = response.data;
              // arr.Data.minimumReplenishmentAmountField = 5;
              deferred.resolve(arr);
            },
            function (response) {
              deferred.reject(response);
            }
          );
        return deferred.promise;
      },
      // get BILLERS by categories
      doSunpassReplenishment: function (obj) {
        var userInfo = AuthenticationFactory.getUserInfo();

        var queryObj = {
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword,
          TransporderNumber: obj.TransporderNumber,
          CarrierName : obj.CarrierName,
          ProductCode : obj.ProductCode,
          PurchaseId: obj.PurchaseId,
          Amount: obj.Amount
        };

        var deferred = $q.defer();

        $http.post(API_URL + 'v2/tolls/replenishment', queryObj)
          .then(
            function (response) {
              arr = response.data;
              deferred.resolve(arr);
            },
            function (response) {
              deferred.reject(response);
            }
          );
        return deferred.promise;
      },
      // get CATEGORIES
      getSunpassDocumentsInfo: function (obj) {
        var userInfo = AuthenticationFactory.getUserInfo();

        var queryObj = {
          LicensePlate: obj.LicensePlate,
          DocumentNumber: obj.DocumentNumber,
          ProductCode: obj.item.InquiryId,
          CarrierName : obj.item.CarrierName,
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword
        };

        var deferred = $q.defer();

        $http.post(API_URL + 'v2/tolls/inquiry/document/', queryObj)
          .then(
            function (response) {
              arr = response.data;
              // console.log(JSON.stringify(arr));
              deferred.resolve(arr);
            },
            function (response) {
              deferred.reject(response);
            }
          );
        return deferred.promise;
      },
      // get Biller
      doSunPassDocumentsPayment: function (obj) {

        var userInfo = AuthenticationFactory.getUserInfo();

        var queryObj = {
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword,
          PaymentType: obj.PaymentType,
          DocumentId: obj.DocumentId,
          LicensePlate: obj.LicencePlate,
          PurchaseId: obj.PurchaseId,
          CarrierName: obj.CarrierName,
          ProductCode: obj.ProductCode,
          Amount: obj.Amount,
          Fee: obj.Fee
        };

        var deferred = $q.defer();

        $http.post(API_URL + 'v2/tolls/paydocument', queryObj)
          .then(
            function (response) {
              arr = response.data;
              deferred.resolve(arr);
            },
            function (response) {
              deferred.reject(response);
            }
          );
        return deferred.promise;
      }
    };
  }
})();
