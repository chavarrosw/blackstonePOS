(function () {
  'use strict';

  angular
    .module('posClient')
    .controller('SunpassReplenishController', SunpassReplenishController);

  SunpassReplenishController.$inject = ['$scope', '$routeParams', '$uibModal', 'ProdsFactory', 'SunpassService', 'localStorageService', 'AuthenticationFactory', 'SharedFunctions', 'ConfirmationFactory', 'Notification', 'BsUiMessages', '$log'];

  function SunpassReplenishController($scope, $routeParams, $uibModal, ProdsFactory, SunpassService, localStorageService, AuthenticationFactory, SharedFunctions, ConfirmationFactory, Notification, BsUiMessages, $log) {
    var vm = this;
    // vm.item = {
    //   name: 'Activate or Replenish Sunpass Transponder',
    //   MaxAmount: 100
    // };

     // get productMainCode by $routeParams
     var productMainCode = $routeParams.id;

     // get userInfo stored on localStorageService
     var userInfo = AuthenticationFactory.getUserInfo();
 
     vm.getProduct = function () {
       ProdsFactory
         .getProduct(productMainCode, userInfo)
         .then(function (data) {
           vm.item = data;          
         }, function (error) {
           $log.error(error);
         });
     };
     vm.getProduct();     

     vm.openHelpModal = function () {     
      $scope.ruta1 = "/assets/images/tolls/" + vm.item.CarrierName + "_trans1.png";
      $scope.ruta2 = "/assets/images/tolls/" + vm.item.CarrierName + "_trans2.png";
      $scope.ruta3 = "/assets/images/tolls/" + vm.item.CarrierName + "_trans3.png";
      $uibModal.open({
        templateUrl: 'app/tolls/modal-transp-help.html',
        scope: $scope,
        size: 'lg',
        windowClass: 'product-modal'
      });
    };


    // interface elm visibility
    vm.hasKeyPad = true;
    vm.showKeypad = true;
    vm.showPaymentDetails = false;
    vm.showDoReplenishment = false;
    vm.showReceipt = false;
    vm.showToCategories = false;
    vm.showToReplenish = false;

    // init params
    vm.accountNumber = {
      value: null,
      isFocused: false
    };
    vm.accountMatch = {
      value: null,
      isFocused: false
    };
    vm.amount = {
      value: null,
      isFocused: false
    };
    vm.submitted = false;



    // undo function from keypad for account value
    function backKeyAccountNumber() {
      var length = vm.accountNumber.value.length;
      var value = vm.accountNumber.value;
      vm.accountNumber.value = value.substring(0, length - 1);
    }

    // undo function from keypad for confirm account value
    function backKeyAccountMatch() {
      var length = vm.accountMatch.value.length;
      var value = vm.accountMatch.value;
      void 0;
      void 0;
      vm.accountMatch.value = value.substring(0, length - 1);
    }

    // undo function from keypad for amount value
    function backKeyAmount() {
      var length = vm.amount.value.length;
      var value = vm.amount.value;
      void 0;
      void 0;
      vm.amount.value = value.substring(0, length - 1);
    }

    // set value for account input
    function setKeyAccountNumber(key) {
      vm.accountNumber.value = vm.accountNumber.value + key;
    }

    // set value for onfirm account input
    function setKeyConfirmAccountNumber(key) {
      void 0;
      vm.accountMatch.value = vm.accountMatch.value + key;
    }

    // set value for amount input
    function setKeyAmount(key) {
      vm.amount.value = vm.amount.value + key;
    }

    function initInputs() {
      if (!vm.accountNumber.value) {
        vm.accountNumber.value = '';
      }
      if (!vm.accountMatch.value) {
        vm.accountMatch.value = '';
      }
      if (!vm.amount.value) {
        vm.amount.value = '';
      }
    }

    function setAmount(keynum) {
      void 0;
      if (vm.amount.isFocused) {
        setKeyAmount(keynum);
      } else if (vm.accountNumber.isFocused) {
        setKeyAccountNumber(keynum);
      } else {
        setKeyConfirmAccountNumber(keynum);
      }
    }


    vm.editing = null;
    vm.editItem = function (item) {
      vm.editing = item;
      void 0;
    };

    // $scope.onInputClick = function ($event) {
    //   $event.target.select();
    // };

    // set input value from keypad
    vm.setKey = function (value) {
      initInputs();
      setAmount(value);
    };

    // clear input value from keypad
    vm.clearKey = function () {
      if (vm.accountNumber.isFocused) {
        vm.accountNumber.value = '';
      } else {
        vm.amount.value = '';
      }
    };


    vm.backKey = function () {
      initInputs();

      if (vm.accountNumber.isFocused) {
        backKeyAccountNumber();
      } else if (vm.amount.isFocused) {
        backKeyAmount();
      } else {
        backKeyAccountMatch();
      }
    };

    //
    vm.setFocusedInput = function (inputName) {
      if (inputName === 'amount') {
        vm.accountNumber.isFocused = false;
        vm.accountMatch.isFocused = false;
        vm.amount.isFocused = true;
        void 0;
      } else if (inputName === 'accountNumber') {
        vm.accountMatch.isFocused = false;
        vm.accountNumber.isFocused = true;
        vm.amount.isFocused = false;
        void 0;
      } else if (inputName === 'accountMatch') {
        vm.accountNumber.isFocused = false;
        vm.accountMatch.isFocused = true;
        vm.amount.isFocused = false;
        void 0;
      }
    };

    // set focus
    // $scope.leaveInputsFocus = function () {
    //   vm.accountNumber.isFocused = false;
    //   vm.accountMatch.isFocused = false;
    //   vm.amount.isFocused = false;
    // };

    // GET TRANSPONDER INFO
    vm.doGetInfo = function (form) {

      // Trigger validation flag.
      vm.submitted = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll()
        Notification.error(BsUiMessages.invalidForm.message);
        $log.debug(BsUiMessages.invalidForm.message);
      } else {

        var transporderNumber = vm.accountNumber.value;

        // console.log(account);

        SunpassService.getSunpassTransporderInfo(transporderNumber, vm.item).then(
          function (response) {

            if (response.ResponseCode === 0) {

              // vm.showKeypad = false;
              vm.isDisableInputs = true;
              vm.aditionalDataRequired = response.ResponseParameters;
              // console.log(response);

              // set form visibility
              vm.showPaymentDetails = true;
              vm.showDoReplenishment = true;
              vm.submitted = false;

            } else {
              Notification.clearAll();
              Notification.error(response.ResponseDescription + '\n' + response.ResponseParameters.MessageFromTollAuthority);
              $log.debug(response.ResponseDescription+ '\n' + response.ResponseParameters.MessageFromTollAuthority);
              vm.isDisableInputs = false;
            }

          },
          function (error) {
            $log.error(error);
          }
        );
      }
    };

    // DO TRANSPONDER REPLENISHMENT
    vm.doReplenishment = function (form) {

      // Trigger validation flag.
      vm.submitted = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll();
        Notification.error(BsUiMessages.invalidForm.message);
        $log.debug(BsUiMessages.invalidForm.message);
        return;
      } else {
        var obj = {
          TransporderNumber: vm.accountNumber.value,          
          CarrierName : vm.item.CarrierName,
          ProductCode : vm.item.Code,
          PurchaseId: vm.aditionalDataRequired.InquiryReferenceNumber,
          Amount: vm.amount.value
        };

        SunpassService.doSunpassReplenishment(obj).then(
          function (response) {

            if (response.ResponseCode === 200 || response.ResponseCode === 203) {

              // vmshowKeypad = false;
              vm.isDisableInputs = true;

              // console.log(data);
              vm.receipt = response.ResponseParameters;

              // set form visibility
              vm.showPaymentDetails = true;
              vm.showDoReplenishment = false;
              vm.showReceipt = true;
              vm.showToCategories = true;
              vm.showToReplenish = true;

            } else {
              Notification.clearAll();
              Notification.error(response.ResponseDescription);
              $log.debug(response.ResponseDescription);
              vm.isDisableInputs = false;
            }

          },
          function (error) {
            $log.debug(error);
          }
        );
      }
    };

    // print receipt
    vm.printInfo = function () {
       $window.print();
    };

    // send receipt as sms
    vm.sendSms = function (form) {

      // Trigger validation flag.
      vm.submittedSms = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll()
        Notification.error(BsUiMessages.invalidForm.message);
        $log.debug(BsUiMessages.invalidForm.message);

      } else {

        // remove any previous alert
        Notification.clearAll();

        var receipt = vm.receipt;
        var phone = vm.phoneToSend;

        ConfirmationFactory.sendConfirmationSms(receipt, phone).then(
          function (response) {

            Notification.clearAll();
            vm.submittedSms = false;

            if (response.Status === 200) {
              Notification.success(BsUiMessages.smsReceiptSuccess.message);
              $log.debug(BsUiMessages.smsReceiptSuccess.message);
            } else {
              Notification.error(response.ErrorMessage);
              $log.debug(response);
            }
          },
          function (response) {
            Notification.error(response.ErrorMessage);
            $log.debug(response.ErrorMessage);
          }
        );
      }
    };
    

    // send receipt as email
    vm.sendEmail = function (form) {

      // Trigger validation flag.
      vm.submittedEmail = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll()
        Notification.error(BsUiMessages.invalidForm.message);
        $log.debug(BsUiMessages.invalidForm.message);

      } else {
        Notification.clearAll()

        var receipt = vm.receipt;
        var email = vm.emailToSend;

        ConfirmationFactory.sendConfirmationEmail(receipt, email).then(
          function (response) {

            Notification.clearAll()
            vm.submittedEmail = false;

            if (response.Status === 200) {
              Notification.success(BsUiMessages.smsReceiptSuccess.message);
              $log.debug(BsUiMessages.smsReceiptSuccess.message);
            } else {
              Notification.error(response.ErrorMessage);
              $log.debug(response.ErrorMessage);
            }
          },
          function (response) {
            Notification.error(response.ErrorMessage);
            $log.debug(response.ErrorMessage);
          }
        );
      }
    };
  }
})();
