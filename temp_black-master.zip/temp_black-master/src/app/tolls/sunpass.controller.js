(function () {
  'use strict';

  angular
    .module('posClient')
    .controller('SunpassController', SunpassController);

  // SunpassController.$inject = [];

  function SunpassController() {
    var vm = this;
    vm.items = [{
        categoryName: 'sunpass',
        title: 'Activate or Replenish Sunpass',
        url: '#/sunpass/category/replenish',
        position: 0,
        icon: ''
      },
      {
        categoryName: 'sunpass',
        title: 'Pay Your Document',
        url: '#/sunpass/category/documents',
        position: 1,
        icon: ''
      }
    ];
  }
})();
