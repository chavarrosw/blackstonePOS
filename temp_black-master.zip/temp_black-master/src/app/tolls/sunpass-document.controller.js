(function () {
  'use strict';

  angular
    .module('posClient')
    .controller('SunpassDocumentController', SunpassDocumentController);

  SunpassDocumentController.$inject = [
    '$scope',
    '$uibModal',
    '$routeParams',
    'ProdsFactory',
    'SunpassService',
    'localStorageService',
    'AuthenticationFactory',
    'SharedFunctions',
    'ConfirmationFactory',
    'Notification',
    'BsUiMessages',
    '$log',
    '$window'
  ];

  function SunpassDocumentController($scope, $uibModal, $routeParams, ProdsFactory, SunpassService, localStorageService, AuthenticationFactory, SharedFunctions, ConfirmationFactory, Notification, BsUiMessages, $log, $window) {
    var vm = this;
    // vm.item = {
    //   name: 'Pay Your Documents'
    // };
    vm.paymentType = {
      Single: 'Single',
      All: 'All'
    };

    // get productMainCode by $routeParams
    var productMainCode = $routeParams.id;

    // get userInfo stored on localStorageService
    var userInfo = AuthenticationFactory.getUserInfo();

    vm.getProduct = function () {
      ProdsFactory
        .getProduct(productMainCode, userInfo)
        .then(function (data) {
          vm.item = data;
        }, function (error) {
          $log.error(error);
        });
    };
    vm.getProduct();

    vm.openHelpModal = function () {     
      $scope.ruta1 = "/assets/images/tolls/" + vm.item.CarrierName + "_docs1.png";
      $scope.ruta2 = "/assets/images/tolls/" + vm.item.CarrierName + "_docs2.png";
      $scope.ruta3 = "/assets/images/tolls/" + vm.item.CarrierName + "_docs3.png";
      $uibModal.open({
        templateUrl: 'app/tolls/modal-docs-help.html',
        scope: $scope,
        size: 'lg',
        windowClass: 'product-modal'
      });
    };

    // interface elm visibility
    vm.showCheck = true;
    vm.showPaymentDetails = false;
    vm.showFieldsDescription = true;
    vm.showDoDocumentsPayment = false;
    vm.showReceipt = false;
    // steps vars
    vm.submittedCheck = false;
    vm.submittedDoPayment = false;

    // init params
    vm.idnumber = null;
    vm.plate = null;
    vm.total = 0;
    vm.fee = 0;
    vm.totalAmount = 0;
    vm.submitted = false;
    vm.selectedDocuments = [];

    vm.parseFloat = function (value) {
      return parseFloat(value);
    };

    vm.setDocument = function (type) {

      vm.total = 0;
      vm.fee = vm.item.Fee;
      if (vm.paymentType.Single == type && vm.documents.RequestedDocument) {
        vm.selectedDocuments = [vm.documents.RequestedDocument];
        vm.total = vm.documents.RequestedDocument.Amount;
      } else if (vm.paymentType.All == type) {
        vm.selectedDocuments = vm.documents.UnpaidDocuments;
        vm.total = vm.documents.UnpaidDocumentsTotalAmount;
        if (vm.selectedDocuments) {
          vm.fee = vm.fee * vm.selectedDocuments.length;
        }
      }
      vm.totalAmount = vm.total + vm.fee;

      vm.selectedPaymentType = type;
    };

    // GET TRANSPONDER INFO
    vm.doGetInfo = function (form) {

      // Trigger validation flag.
      vm.submittedCheck = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll();
        Notification.error(BsUiMessages.invalidForm.message);
        $log.error('Invalid Form: ');
        $log.error(form);
      } else {
        var obj = {
          DocumentNumber: vm.idnumber,
          LicensePlate: vm.plate,
          item: vm.item
        };

        void 0;

        SunpassService
          .getSunpassDocumentsInfo(obj)
          .then(function (response) {
            if (response.ResponseCode === 0) {
              vm.documents = response.ResponseParameters;
              vm.setDocument(vm.paymentType.Single);

              // set form visibility
              vm.isDisableInputs = true;
              vm.showCheck = false;
              vm.showFieldsDescription = false;
              vm.showPaymentDetails = true;
              vm.showDoDocumentsPayment = true;
            } else {
              Notification.clearAll();
              Notification.error(response.ResponseDescription);
              $log.debug(response.ResponseDescription);
              vm.isDisableInputs = false;
              vm.showCheck = true;
            }
          }, function (error) {
            $log.error(error);
            void 0;
          });
      }
    };

    // DO TRANSPONDER REPLENISHMENT
    vm.doDocumentsPayment = function (form) {

      void 0;

      // Trigger validation flag.
      vm.submittedDoPayment = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll();
        Notification.error(BsUiMessages.invalidForm.message);
        $log.error('Invalid Form: ');
        $log.error(form);
      } else {
        // set query params
        var obj = {
          DocumentId: vm.idnumber,
          LicencePlate: vm.plate,
          PaymentType: vm.selectedPaymentType,
          PurchaseId: vm.documents.InquiryReferenceNumber,
          CarrierName: vm.item.CarrierName,
          ProductCode: vm.item.Code,
          Fee: vm.fee,
          Amount: vm.total
        };

        SunpassService
          .doSunPassDocumentsPayment(obj)
          .then(function (response) {
            if (response.ResponseCode === 200 || response.ResponseCode === 203) {
              vm.showReceipt = true;
              vm.receipt = response.ResponseParameters;
            } else {
              Notification.clearAll();
              Notification.error(response.ResponseDescription);
              $log.error(response.ResponseDescription);
              vm.isDisableInputs = false;
            }
          }, function (error) {
            $log.error(error);
          });
      }
    };

    // print receipt
    vm.printInfo = function () {
      $window.print();
    };

    // send receipt as sms
    vm.sendSms = function (form) {

      // Trigger validation flag.
      vm.submittedSms = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.clearAll();
        Notification.error(BsUiMessages.invalidForm.message);
        $log.error(BsUiMessages.invalidForm.message);
      } else {

        // remove any previous alert
        Notification.clearAll();

        var receipt = vm.receipt;
        var phone = vm.phoneToSend;

        ConfirmationFactory
          .sendConfirmationSms(receipt, phone)
          .then(function (response) {

            Notification.clearAll();
            vm.submittedSms = false;

            if (response.Status === 200) {
              Notification.success(BsUiMessages.smsReceiptSuccess.message);
            } else {
              Notification.error(response.ErrorMessage);
              $log.error(response.ErrorMessage);
            }
          }, function (response) {
            $log.error(response.ErrorMessage);
          });
      }
    };

    // send receipt as email
    vm.sendEmail = function (form) {

      // Trigger validation flag.
      vm.submittedEmail = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {

        Notification.clearAll();
        Notification.error(BsUiMessages.invalidForm.message);
        return;

      } else {
        Notification.clearAll();

        var receipt = vm.receipt;
        var email = vm.emailToSend;

        ConfirmationFactory
          .sendConfirmationEmail(receipt, email)
          .then(function (response) {

            Notification.clearAll();
            vm.submittedEmail = false;

            if (response.Status === 200) {
              Notification.success(BsUiMessages.smsReceiptSuccess);
            } else {
              Notification.error(response.ErrorMessage);
              $log.error(response.ErrorMessage);

            }
          }, function (response) {
            $log.error(response.ErrorMessage);
          });
      }
    };
  }
})();
