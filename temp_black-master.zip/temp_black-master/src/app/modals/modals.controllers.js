(function () {
    'use strict';
    angular.module('posClient')
      .controller('ModalAccountCtrl', ['$scope', '$uibModalInstance', 'item', '$location', 'localStorageService', function ($scope, $modalInstance, item, $location, localStorageService) {
  
        $scope.merchant = item;
        //console.log();
  
        $scope.openAdmin = function () {
          $modalInstance.close();
          $location.path('/admin');
        };
  
        $scope.logout = function () {
          $modalInstance.close();
          localStorageService.set('userInfo', '');
          localStorageService.clearAll();
        };
  
        $scope.close = function () {
          $modalInstance.close();
        };
  
        $scope.cancel = function () {
          $modalInstance.dismiss('cancel');
        };

        activate();

        function activate(){
          $scope.version = angular.element('meta[name=version]')[0].content;
        }
      }])
      .controller('ModalInstanceCtrl', ['$scope', '$uibModalInstance', 'item', function ($scope, $modalInstance, item) {
  
        $scope.items = item;
        //console.log();
  
        $scope.selected = {
          item: $scope.items
        };
  
        $scope.modalOptions = {
          closeButtonText: 'Close',
          actionButtonText: 'Save',
          headerText: $modalInstance.headerText
        };
  
        $scope.close = function () {
          $modalInstance.close($scope.selected.items);
        };
  
        $scope.cancel = function () {
          $modalInstance.dismiss('cancel');
        };
      }])
      .controller('ModalInstanceTermsCtrl', ['$scope', '$modalInstance', 'item', function ($scope, $modalInstance, item) {
        $scope.items = item;
        //console.log();
  
        $scope.selected = {
          item: $scope.items
        };
  
        $scope.modalOptions = {
          closeButtonText: 'Close',
          actionButtonText: 'Save',
          headerText: $modalInstance.headerText
        };
  
        $scope.close = function () {
          $modalInstance.close($scope.selected.items);
        };
  
        $scope.cancel = function () {
          $modalInstance.dismiss('cancel');
        };
      }]);
  }());