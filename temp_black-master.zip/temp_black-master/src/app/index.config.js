(function () {
  'use strict';

  angular
    .module('posClient')
    .config(config);

  /** @ngInject */
  function config($logProvider, $httpProvider, localStorageServiceProvider, cfpLoadingBarProvider, NotificationProvider, ANALYTICS) {
    // Enable log
    $logProvider.debugEnabled(true);
    $logProvider.logServerEndpoint = ANALYTICS.api + 'api/logs';
    $logProvider.logServerLevels = ['debug', 'error'];

    //TODO: Remove this configuration
    configureHttpProvider($httpProvider);

    // Set options third-party lib local storage
    localStorageServiceProvider.setPrefix('pos');

    //spinner
    cfpLoadingBarProvider.parentSelector = '#loading-bar-container';
    cfpLoadingBarProvider.includeSpinner = true;
    cfpLoadingBarProvider.spinnerTemplate = '<div class="overlay"><div id="loading-bar-spinner"><div class="spinner-icon"></d' +
        'iv></div></div>';

    //angular-ui-bootstrap
    NotificationProvider.setOptions({
      delay: 5000,
      startTop: 20,
      startRight: 10,
      verticalSpacing: 20,
      horizontalSpacing: 20,
      positionX: 'right',
      positionY: 'top'
    });
  }

  function configureHttpProvider($httpProvider) {
    // Use x-www-form-urlencoded Content-Type
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';

    // Override $http service's default transformRequest
    $httpProvider.defaults.transformRequest = [function (data) {
        /**
       * The workhorse; converts an object to x-www-form-urlencoded serialization.
       * @param {Object} obj
       * @return {String}
       */
        var param = function (obj) {
          var query = '';
          var name,
            value,
            fullSubName,
            subName,
            subValue,
            innerObj,
            i;
          for (name in obj) {
            value = obj[name];
            if (value instanceof Array) {
              for (i = 0; i < value.length; ++i) {
                subValue = value[i];
                fullSubName = name + '[' + i + ']';
                innerObj = {};
                innerObj[fullSubName] = subValue;
                query += param(innerObj) + '&';
              }
            } else if (value instanceof Object) {
              for (subName in value) {
                subValue = value[subName];
                fullSubName = name + '[' + subName + ']';
                innerObj = {};
                innerObj[fullSubName] = subValue;
                query += param(innerObj) + '&';
              }
            } else if (value !== undefined && value !== null) {
              query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
            }
          }
          return query.length
            ? query.substr(0, query.length - 1)
            : query;
        };
        return angular.isObject(data) && String(data) !== '[object File]'
          ? param(data)
          : data;
      }
    ];
  }

})();
