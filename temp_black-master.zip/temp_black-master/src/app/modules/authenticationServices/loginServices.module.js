(function () {
  'use strict';

  angular.module('loginServices', [])
  // might ngInject Return merchant account details
    .factory('AuthenticationFactory', [
    '$http',
    '$rootScope',
    'API_URL',
    '$q',
    'localStorageService',
    '$location',
    '$log',
    'SharedFunctions',
    'URL_BACKEND',
    function ($http, $rootScope, API_URL, $q, localStorageService, $location, $log, SharedFunctions, URL_BACKEND) {
      var arr;
      var userInfo;

      function loginWasMoreThanMaxAllowedTime() {
        return false;
        // var now = new Date();
        // var hours = Math.abs(now - loginTimestamp) / 36e5;
        // return hours >= 24;
      }

      return {
        // LOGIN (use GetMerchantDetails API method), save user details into storage
        // service
        login: function (merchantId, password) {
          var deferred = $q.defer();

          // var eAES = CryptoJS.AES.encrypt('selam world', 'julio').toString();
          // $log.log(eAES);
          // var dAES = CryptoJS.AES.decrypt(eAES, 'julio').toString(CryptoJS.enc.Utf8);
          // $log.log(dAES);
          // var passHash = CryptoJS.SHA512("M5494").toString();
          // $log.log(passHash);

          $http
            .post(API_URL + 'v2/merchant/pos/loginNew', {
              MerchantId: merchantId,
              MerchantPassword: CryptoJS.SHA512(password).toString()
            })
            .then(function (response) {        
      

              if (response.data.Data != null) {
                userInfo = response.data.Data;                
              }

              arr = {
                Status: response.data.Status,
                UserInfo: userInfo
              };

              deferred.resolve(arr);

            }, function (response) {
              deferred.reject(response);
            }); // .then()

          return deferred.promise;
        },
        logout: function () {
          // localStorageService.remove('userInfo','');
          // localStorageService.remove('selection','');
          // localStorageService.remove('adminLogged','');
          // localStorageService.remove('adminTab','');          
          // $location.path('/login');
          localStorage.removeItem('ath');
          SharedFunctions.logout();
        },
        isLoggedIn: function () {
          userInfo = localStorageService.get('userInfo');
          if (userInfo) {
            if (loginWasMoreThanMaxAllowedTime()) {
              this.logout();
            }

          }
          var result = (userInfo != null)
            ? userInfo
            : false;
          return result;
        },
        // GET USER INFO
        getUserInfo: function () {
          // if (localStorageService.get('userInfo')) {
          //   userInfo = localStorageService.get('userInfo');
          // }
          // // console.log(userInfo);
          // return userInfo;
          return SharedFunctions.getUserInfo();
        },
        // SUBMIT APPLICANT (apply today form on /login view)
        submitApplicant: function (applicant) {
          // console.log(applicant);
          var deferred = $q.defer();
          $http
            .post(API_URL + 'guest/submitapplication', applicant)
            .then(function (response) {
              arr = response.data;
              deferred.resolve(arr);
            }, function (response) {
              deferred.reject(response);
            });
          return deferred.promise;
        },
        // SUBMIT APPLICANT (apply today form on /login view)
        submitGuest: function (guest) {
          var deferred = $q.defer();
          $http
            .post(API_URL + 'guest/submitguest', guest)
            .then(function (response) {
              arr = response.data;
              deferred.resolve(arr);
            }, function (response) {
              deferred.reject(response);
            });
          return deferred.promise;
        },
        selectATH: function (merchantID) {
          var deferred = $q.defer();

          $http.post(URL_BACKEND + '/api/ath/find', {
              merchantID: merchantID
            })
            .then(
              function (response) {

                var data = response.data;
                void 0;
                console.log(data);
                deferred.resolve(data);

              },
              function (response) {

                deferred.reject(response);

              }
            );
          return deferred.promise;
        }
      };
    }
  ]);
}());