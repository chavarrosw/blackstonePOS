// Intercepting HTTP calls with AngularJS.
angular.module('posClient')
.config(function ($provide, $httpProvider) {
  
  // Intercept http calls.
  $provide.factory('MyHttpInterceptor', function ($q, $log, $location, API_URL, SharedFunctions) {
    return {
      // On request success
      request: function (config) {
        // console.log(config); // Contains the data about the request before it is sent.        
        if((config.url.indexOf(API_URL) >= 0) && (config.url.indexOf("loginNew") < 0)){
            var userInfo = SharedFunctions.getUserInfo();
            if (userInfo){
                config.data.SystemType = 4;
                config.data.MerchantId= userInfo.MerchantId;
                //config.data.MerchantPassword= userInfo.MerchantPassword;
                config.data.MerchantPassword= CryptoJS.SHA512(userInfo.MerchantPassword).toString();                
                //$log.log(JSON.stringify(config, null, 2));
            }else{
                SharedFunctions.logout();
            }
        }
        // Return the config or wrap it in a promise if blank.
        return config || $q.when(config);
      },

      // On request failure
    //   requestError: function (rejection) {
    //     // console.log(rejection); // Contains the data about the error on the request.
        
    //     // Return the promise rejection.
    //     return $q.reject(rejection);
    //   },

    //   // On response success
    //   response: function (response) {
    //     // console.log(response); // Contains the data from the response.
    //     //$log.log(JSON.stringify(response));
    //     // Return the response or promise.
    //     return response || $q.when(response);
    //   },

    //   // On response failture
    //   responseError: function (rejection) {
    //     // console.log(rejection); // Contains the data about the error.
    //     //$log.log(JSON.stringify(rejection));
    //     // Return the promise rejection.
    //     return $q.reject(rejection);
    //   }
    };
  });

  // Add the interceptor to the $httpProvider.
  $httpProvider.interceptors.push('MyHttpInterceptor');

});