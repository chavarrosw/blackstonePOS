(function () {
  'use strict';

  angular
    .module('customFunctions')
    .factory('SharedFunctions', SharedFunctions);

  SharedFunctions.$inject = ['localStorageService', '$location'];

  function SharedFunctions(localStorageService, $location) {   

    var service = {
      getUserInfo: getUserInfo,
      logout: logout,
      mapProductsURL: mapProductsURL,
      unique: unique,
      serialize: serialize,
      isobject: isobject,
      alpha: alpha,
      firstleter: firstleter,
      isMobile: isMobile      
    };

    var ProductType = {
      WirelessPortIn : 233,
      AccountInquiry : 238,
      Pin : 239,
      AccountReload : 240,
      TollAccountReload : 241,
      TollDocumentPayment : 242,
      TollOneTimePayment : 251,
      WirelessSimActivation : 243,
      GiftCardActivation : 244
    };

    return service;


    // GET USER INFO FROM LOCALSTORE
    function getUserInfo() {
      var dataUserInfo = localStorageService.get('userInfo');
      if (dataUserInfo) {
        var key = "bR0z5npc0u(3o7RH";
        var rawData = atob(dataUserInfo);
        var iv = btoa(rawData.substring(0,16));
        var crypttext = btoa(rawData.substring(16));
        var _key = btoa(key);

        // Decrypt...
        var plaintextArray = CryptoJS.AES.decrypt(
          {
            ciphertext: CryptoJS.enc.Base64.parse(crypttext),
            salt: ""
          },
          CryptoJS.enc.Base64.parse(_key),
          { iv: CryptoJS.enc.Base64.parse(iv) }
        );

         var userInfo = JSON.parse(plaintextArray.toString(CryptoJS.enc.Utf8));

      }
      // console.log(userInfo);
      return userInfo;
    }
    function logout() {
      localStorageService.remove('userInfo','');
      localStorageService.remove('selection','');
      localStorageService.remove('adminLogged','');
      localStorageService.remove('adminTab','');          
      $location.path('/login');
    }

    ////////////////
    function mapProductsURL(products) {
      return products.map(getProductURL);
    }

    function unique(arr) {
      var o = {},
        i, r = [];
      for (i = 0; i < arr.length; i++) {
        o[arr[i]] = arr[i];
      }
      for (i in o) {
        r.push(o[i]);
      }
      return r;
    }

    function serialize(obj) {
      var str = [];
      for (var p in obj)
        if (obj.hasOwnProperty(p)) {
          str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
        }
      return str.join('&');
    }

    function isobject(a) {
      return (!!a) && (a.constructor === Object);
    }

    function alpha() {
      return ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    }

    function firstleter(data) {
      var arr = [];
      for (var i = 0; i < data.length; i++) {
        arr.push(data[i].Name.charAt(0));
      }
      return arr;
    }

    function isMobile() {
      // return $window.document.width < 700 ? true : false;
      return navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) ? true : false;
      // other solution: http://detectmobilebrowsers.com/
      // other solution: https://github.com/kaimallea/isMobile
    }
    
    function getProductURL(product) {      
      if (product.Code != 'grouper') {
        switch(product.ProductType){
          case ProductType.WirelessSimActivation:
            product.url = '#/pos/activation/' + product.GrouperId + '/' + product.Code;
            break;
          case ProductType.TollDocumentPayment:
            product.url = '#/pos/category/' + product.MainCategory + '/documents/product/'+ product.Code;
            // product.url = '#/tolls/category/documents/' + product.Code;
            break;
          case ProductType.TollAccountReload:
            product.url = '#/pos/category/' + product.MainCategory + '/replenish/product/'+ product.Code;
            // product.url = '#/tolls/category/replenish/' + product.Code;
            break;
          default:
            product.url = '#/pos/category/' + product.MainCategory + '/product/' + product.Code;
        }
      } else {
        if (!product.InquiryId || product.InquiryId == '' || product.InquiryId == '0') {
          product.url = '#/pos/category/' + product.MainCategory + '/group/' + product.GrouperId;
        } else {
          product.url = '#/pos/inquiry/' + product.InquiryId;
          if (product.GrouperId)
            product.url = product.url + '?gid=' + product.GrouperId;
        }
      }
      return product;
    }
  }
}());


// (function () {
//   'use strict';
//   angular.module('customFunctions', [])
//     // might ngInject
//     .factory('SharedFunctions', [
//       function () {
//         return {
//           // make array unique
//           unique: function (arr) {
//             var o = {},
//               i, r = [];
//             for (i = 0; i < arr.length; i++) {
//               o[arr[i]] = arr[i];
//             }
//             for (i in o) {
//               r.push(o[i]);
//             }
//             return r;
//           },
//           serialize: function (obj) {
//             var str = [];
//             for (var p in obj)
//               if (obj.hasOwnProperty(p)) {
//                 str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
//               }
//             return str.join('&');
//           },
//           // check if
//           isobject: function (a) {
//             return (!!a) && (a.constructor === Object);
//           },
//           alpha: function () {
//             return ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
//           },
//           // merge: function(target, source){
//           // 	/* Merges two (or more) objects, giving the last one precedence */
//           // 	for (var p in source) {
//           // 		try {
//           // 			// Property in destination object set; update its value.
//           // 			if ( source[p].constructor === Object ) {
//           // 				target[p] = merge(target[p], source[p]);
//           // 			} else {
//           // 				target[p] = source[p];
//           // 			}
//           // 		} catch(e) {
//           // 			// Property in destination object not set; create it and set its value.
//           // 			target[p] = source[p];
//           // 		}
//           // 	}
//           // 	return target;
//           // },
//           firstleter: function (data) {
//             var arr = [];
//             for (var i = 0; i < data.length; i++) {
//               arr.push(data[i].Name.charAt(0));
//             }
//             return arr;
//           },
//           isMobile: function () {
//             // return $window.document.width < 700 ? true : false;
//             return navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) ? true : false;
//             // other solution: http://detectmobilebrowsers.com/
//             // other solution: https://github.com/kaimallea/isMobile
//           }
//         };
//       }
//     ]);
// }());
