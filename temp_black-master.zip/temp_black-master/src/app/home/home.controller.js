(function () {
  "use strict";

  angular.module("posClient").controller("HomeController", HomeController);

  HomeController.$inject = [
    "$scope",
    "$location",
    "$log",
    "ProdsFactory",
    "localStorageService",
    "AuthenticationFactory",
  ];

  function HomeController(
    $scope,
    $location,
    $log,
    ProdsFactory,
    localStorageService,
    AuthenticationFactory
  ) {
    var userInfo = AuthenticationFactory.getUserInfo();
    var homeItems = [
      {
        categoryName: "international",
        title: "Int'l Top Up",
        url: "#/pos/category/international/countries",
        img: "/assets/images/home/international.png",
        position: 1,
        icon: "",
      },
      {
        categoryName: "pinless",
        title: "Pinless Recharge",
        url: "#/pos/category/pinless",
        img: "/assets/images/home/pinless.png",
        position: 3,
        icon: "",
      },
      {
        categoryName: "longdistance",
        title: "Long Distance",
        url: "#/pos/category/longdistance",
        img: "/assets/images/home/longdistance.png",
        position: 2,
        icon: "",
      },
      {
        categoryName: "wireless",
        title: "Wireless Recharge",
        url: "#/pos/category/wireless/carriers",
        img: "/assets/images/home/wireless.png",
        position: 5,
        icon: "",
      },
      {
        categoryName: "sunPass",
        title: "Tolls",
        // url: '#/tolls',
        url: "#/pos/category/tolls",
        img: "/assets/images/home/sunPass.png",
        position: 4,
        icon: "",
      },
      {
        categoryName: "promotions",
        title: "Promotions",
        url: "#/pos/category/promotions",
        img: "/assets/images/home/promotions.png",
        position: 6,
        icon: "star",
      },/*
      {
        categoryName: "directtv",
        title: "Direct TV",
        url: "#/directtv/categories",
        img: "/assets/images/home/directtv.png",
        position: 9,
        icon: "",
      },*/
      {
        categoryName: "prepaidOthers",
        title: "Others",
        url: "#/pos/category/prepaidOthers",
        img: "/assets/images/home/prepaidOthers.png",
        position: 7,
        icon: "",
      },
      // {categoryName: 'MySmsCuba', title: 'MySmsCuba', url: '#/mysmscuba', position:
      // 10, icon: ''} {categoryName: 'activationShop', title: 'Activation Shop',
      // url: '#/activationshop', position: 11, icon: ''} {categoryName: 'Others',
      // url: '#/pos/others', position: 12},
    ];
    $scope.getMainProducts = function (itemsCollection) {
      $scope.items = [];

      var mainProducts = [];

      if (userInfo !== undefined) {
        ProdsFactory.getPosMainProducts(
          userInfo.MerchantId,
          userInfo.MerchantPassword
        ).then(
          function (data) {
            mainProducts = data;
  
            // console.log('main products: ' + mainProducts); console.log(data);
  
            for (var i = 0; i < itemsCollection.length; i++) {
              if (mainProducts.indexOf(itemsCollection[i].categoryName) >= 0) {
                $scope.items.push(itemsCollection[i]);
              }
            }
            //$scope.items.push(itemsCollection[5]);
          },
          function (error) {
            $log.error(error);
          }
        );
      }
      
    };

    $scope.getMainProducts(homeItems);

    
    if (localStorage.getItem('favorites') == null) {
      ProdsFactory.getMostSoldProducts(
        $scope.userInfo.MerchantId,
        $scope.userInfo.MerchantPassword
      ).then(
        function (respon) {
          $scope.items2 = JSON.parse(localStorage.getItem("topsold"));
          localStorage.setItem('favorites', localStorage.getItem("topsold"));
        }).catch(
        function (err) {
  
        });
    } else {
      $scope.items2 = JSON.parse(localStorage.getItem('favorites'));
    }

    // Traemos los productos que corresponden a los juegos
    ProdsFactory.getAllProducts('prepaidOthers', $scope.userInfo).then(
      function (resp) {
        $scope.items3 = resp;
      }
    ).catch(
      function (error) {
        console.log('Error trayendo los datos')
      });
    
    // Consultamos las promociones
    ProdsFactory.getPromotions().then(
      function (info) {
        $scope.promos = info;
      }
    ).catch(
      function (error) {
        console.log('Error trayendo los datos')
      });

    // select tag to filter products
    $scope.filterables = [
      {
        name: "Rate",
        value: "rate",
      },
      {
        name: "Country",
        value: "countryName",
      },
      {
        name: "Category",
        value: "category",
      },
    ];

    // $scope.items = $scope.filterables[0].value;

    $scope.selectProduct = function (item) {
      localStorageService.set("selection", item);
    };

    $scope.myInterval = 3000;

    $scope.slides = [
      {
        image: 'http://lorempixel.com/400/200/',
        position: 1,
      },
      {
        image: 'http://lorempixel.com/400/200/food',
        position: 2,
      },
      {
        image: 'http://lorempixel.com/400/200/sports',
        position: 3,
      },
      {
        image: 'http://lorempixel.com/400/200/people',
        position: 4,
      },
      {
        image: 'http://lorempixel.com/400/200/people',
        position: 5,
      }
    ];
    // var otslider = new OTSlider();

    // otslider.init({
    //   // or 'fade'
    //   transition: 'slide',
    //   // easing function
    //   transitionTiming: "ease",
    //   // duration in ms
    //   transitionDuration: 500
    // });


  }


})();
