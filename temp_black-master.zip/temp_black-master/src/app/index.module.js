(function () {
  'use strict';

  angular.module('posClient', [
    'ngRoute',
    'ngAnimate',
    'ngResource',
    'ui.bootstrap',
    'loginServices',
    'adminServices',
    'sharedServices',
    'prodsServices',
    'LocalStorageModule',
    'appFilters',
    'customFunctions',
    'promosServices',
    'billPaymentServices',
    'directTvServices',
    'flash',
    'ngMessages',
    'ui-notification',
    'angular-loading-bar',
    'cfp.loadingBar',
    'validation.match',
    'ngLogJS',
    'ngTable',
    'tooltips'
  ]);
}());