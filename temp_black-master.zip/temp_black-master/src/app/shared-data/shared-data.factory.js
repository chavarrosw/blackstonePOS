(function () {
    'use strict';

    angular
        .module('posClient')
        .factory('SharedData', SharedData);

    SharedData.$inject = [];

    function SharedData() {
        var data = {};
        var service = {
            setActivationRequestObject: setActivationRequestObject,
            getActivationRequestObject: getActivationRequestObject,
            setActivationResponse: setActivationResponse,
            getActivationResponse: getActivationResponse,
            setPortInRequestObject: setPortInRequestObject,
            getPortInRequestObject: getPortInRequestObject,
            setPortInResponse: setPortInResponse,
            getPortInResponse: getPortInResponse,
            clearSharedData: clearSharedData,
            setInquiryGlobalObject: setInquiryGlobalObject,
            getInquiryGlobalObject: getInquiryGlobalObject            
        };

        return service;

        ////////////////
        function setInquiryGlobalObject(InquiryGlobalObject) {
            data.InquiryGlobalObject = InquiryGlobalObject;
        }

        function getInquiryGlobalObject() {
            return data.InquiryGlobalObject;
        }

        function setActivationRequestObject(activationRequestObject) {
            data.activationRequestObject = activationRequestObject;
        }

        function getActivationRequestObject() {
            return data.activationRequestObject;
        }

        function setActivationResponse(activationResponse) {
            data.activationResponse = activationResponse;
        }

        function getActivationResponse() {
            return data.activationResponse;
        }

        function setPortInRequestObject(portInRequestObject) {
            data.portInRequestObject = portInRequestObject;
        }

        function getPortInRequestObject() {
            return data.portInRequestObject;
        }

        function setPortInResponse(portInResponse) {
            data.portInResponse = portInResponse;
        }

        function getPortInResponse() {
            return data.portInResponse;
        }

        function clearSharedData() {
            data = {};
        }

    }
})();