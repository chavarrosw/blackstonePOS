(function () {
  'use strict';

  angular
    .module('posClient')
    .controller('AdminController', AdminController);

  AdminController.$inject = ['$rootScope', 'NgTableParams', '$scope', '$location', '$log', 'localStorageService', 'AuthenticationFactory', 'AdminFactory', 'CashierFactory', 'PortInFactory', 'OrderFactory', 'SettingsFactory', '$uibModal', '$filter', '$document', '$timeout', 'Notification'];

  function AdminController($rootScope, NgTableParams, $scope, $location, $log, localStorageService, AuthenticationFactory, AdminFactory, CashierFactory, PortInFactory, OrderFactory, SettingsFactory, $uibModal, $filter, $document, $timeout, Notification) {
    var vm = this;
    
    var userInfo = AuthenticationFactory.getUserInfo();
    var MerchantId;
    var MerchantPassword;    

    vm.filename = '';
    vm.invalidSettingsForm = false;
    vm.dateOptions = {
      dateDisabled: false,
      formatYear: 'yy',
      maxDate: new Date(),
      minDate: new Date(2015, 1, 1),
      startingDay: 1
    };
    vm.datePickerStart = {
      opened: false
    };
    vm.datePickerEnd = {
      opened: false
    };

    // datepicker
    vm.initDates = function () {
      var startDate = new Date();
      vm.start = startDate.setMonth(startDate.getMonth() - 2);
      vm.end = new Date();
    };
    vm.initDates();

    vm.todayDates = function () {
      var startDate = new Date();
      vm.start = startDate.setDate(startDate.getDate() - 1);
      vm.end = new Date();
    };

    vm.tabs = [{
        title: 'Cashiers',
        active: false
      },
      {
        title: 'Settings',
        active: false
      },
      {
        title: 'Orders',
        active: false
      },
      {
        title: 'Port Ins',
        active: false
      },
      {
        title: 'ATH',
        active: false
      }
    ];

    // get previous active tab index
    vm.activeTab = parseInt(localStorageService.get('adminTab'));

    // if exist active it
    if (vm.activeTab && vm.activeTab != null) {
      vm.tabs[vm.activeTab].active = true;
    } else {
      vm.activeTab = 0;
      vm.tabs[0].active = true;
    }
    // save current tab index
    vm.saveState = function (tab) {
      localStorageService.set('adminTab', tab);
    };
    vm.editModeATH = false;
    MerchantId = userInfo.MerchantId;
    MerchantPassword = userInfo.MerchantPassword;
    vm.editModeATH = false;
    vm.ath = {
      id: null,
      merchantID: MerchantId,
      token: null
    };
    vm.selectATH = function (MerchantId) {
      AdminFactory.selectATH(MerchantId).then(
        function (response) {
          if (response.data[0][0] != undefined) {
            vm.editModeATH = true;
            vm.ath.id = response.data[0][0].id;
            vm.ath.token = response.data[0][0].token;
            localStorage.setItem('ath', response.data[0][0].token);
          } 
        }
      ).catch(
        function (error){
          console.log('Error', error);
        }
      );
    };
    vm.selectATH(MerchantId);

    function copySelectedCashierObj(selectedCashier) {
      vm.editcashier.id = selectedCashier.Id;
      vm.editcashier.name = selectedCashier.Name;
      vm.editcashier.password = selectedCashier.Password;
      vm.editcashier.userName = selectedCashier.UserName;
    }

    // payment fuctions
    var initPaymentsScope = function () {
      vm.payment = {
        Id: 0,
        AccountNumber: null,
        RoutingNumber: null,
        TypeChecking: true,
        SaveAccount: false,
        MerchantId: userInfo.MerchantId,
        Amount: 0
      };
    };

    var initOverSession = function () {
      var adminLogged = userInfo.IsMerchant;
      localStorageService.set('adminLogged', adminLogged);
      vm.adminLogged = adminLogged;
      vm.fullcargaLogged = userInfo.IsFullCarga;
    };

    // init settings scope
    var initSettingsScope = function () {
      vm.settings = {
        SmallReceipt: null,
        SmallReceipt2: null,
        Tax: null,
        ConfirmPhone: null,
        PaxTerminalAsPrinter: null
      };
    };

    // init cachiers scope
    var initCashiersScope = function () {
      vm.cashier = {
        id: null,
        name: null,
        userName: null,
        password: null
      };
      vm.editcashier = {
        id: null,
        name: null,
        userName: null,
        password: null
      };
    };

    // INIT $SCOPE
    initOverSession();
    initPaymentsScope();
    initCashiersScope();
    initSettingsScope();
    initOverSession();

    // select
    vm.setSelectedCashier = function (cashier) {
      copySelectedCashierObj(cashier);
      vm.editMode = true;
      // vm.selected = item;
    };
    // get cashier
    vm.getCashiers = function () {
      CashierFactory.getCashiers(MerchantId, MerchantPassword).then(
        function (data) {
          vm.cashiers = data;
        },
        function (error) {
          $log.error(error);
        }
      );
    };
    // delete cashier
    vm.deleteCashier = function (cashierId) {
      if (confirm('Are you sure you want to delete this cashier?')) {
        CashierFactory.deleteCashier(userInfo.MerchantId, userInfo.MerchantPassword, cashierId)
          .then(
            function (response) {
              $log.error(response.ErrorMessage)
              vm.getCashiers();
            },
            function (err) {
              $log.error(err.ErrorMessage);
            }
          );
      }
    };
    // save cashier
    vm.saveCashier = function () {
      CashierFactory.saveCashier(userInfo.MerchantId, userInfo.MerchantPassword, vm.cashier.name, vm.cashier.password, vm.cashier.userName)
        .then(
          function (response) {
            if (response.Status == 200) {
              Notification.success('Cashier Successfully Added!');
            } else {
              $log.error(response.ErrorMessage);
            }
            initCashiersScope();
            vm.getCashiers();
          },
          function (err) {
            $log.error(err.ErrorMessage);
          }
        );
    };
    // update
    vm.updateCashier = function () {
      CashierFactory.editCashier(userInfo.MerchantId, userInfo.MerchantPassword, vm.editcashier.id, vm.editcashier.name, vm.editcashier.password, vm.editcashier.userName)
        .then(
          function (response) {
            if (response.Status == 200) {
              Notification.success('Cashier Successfully Updated!');
            } else {
              $log.error(response.ErrorMessage);
            }
            initCashiersScope();
            vm.editMode = false;
            vm.getCashiers();
          },
          function (err) {
            $log.error(err.ErrorMessage);
          }
        );
    };

    vm.cancelEditCashier = function () {
      vm.editMode = false;
    };
    // ORDERS
    // pagination vars
    vm.currentPage = 1;
    vm.perPage = 10;
    vm.noOfPages = 15;
    vm.totalItems = 0;
    vm.maxSize = 5;

    // GET ORDERS
    vm.getOrders = function () {
      var start = $filter('date')(vm.start, 'shortDate', '-0500');

      var end = $filter('date')(vm.end, 'shortDate', '-0500');

      OrderFactory.getOrders(start, end, vm.currentPage, vm.perPage, userInfo).then(
        function (data) {
          
          vm.backupOrders = data.Data;
          if (vm.cashierSelect) { 
            vm.orders = data.Data.filter(function (order) {
              return order.OperatorName == vm.cashierSelect;
            }); 
          }else {
          vm.orders = data.Data; 
          }         
          vm.totalItems = vm.orders.length;
          vm.spin = false;         
        },
        function (err) {
          $log.error(err);
        }
      );      
    };
    
    vm.PortInsPending = 0;
    vm.PortInsActive = 0;
    vm.PortInsRejected = 0;
    

    vm.getPortIns = function () {     

      PortInFactory.getPortIns(userInfo).then(
        function (data) {
          vm.PortIns = data;
          for (var i=0; i<vm.PortIns.length; i++){
            switch(vm.PortIns[i].Status) {                        
              case 2:
                vm.PortInsActive++;
                break;
              case 5:
                vm.PortInsRejected++;
                break;
              case 4:
                vm.PortInsPending++;
                break;
            }
          }          
          vm.TotalPortIns = data.length;
          vm.spin = false;
          vm.tableParams = new NgTableParams({}, { dataset: vm.PortIns });
                   
        },
        function (err) {
          $log.error(err);
        }
      );      
    };
    
    vm.getDatasource = getDatasource; 
    function getDatasource($column){
      if ($column.title() === "Status") {
        return [{ id: 2, title: "Active"}, 
                { id: 4, title: "Pending"},
                { id: 5, title: "Rejected"}];
      }
    }

    vm.portInStatus = portInStatus; 
      function portInStatus(status){
        switch(status) {                 
          case 2:            
            return 'Active';
          case 5:            
            return 'Rejected';
          case 4:            
            return 'Pending';
        }      
      }

    vm.portInStatusColor = portInStatusColor; 
      function portInStatusColor(status){
        switch(status) {                     
          case 2:
            return 'success';
          case 5:
            return 'danger';
          case 4:
            return 'warning';
        }      
      }
    

    vm.getAllOrdersSummary = function () {

      var start = $filter('date')(vm.start, 'shortDate', '-0500');
      var end = $filter('date')(vm.end, 'shortDate', '-0500');

      OrderFactory.getAllOrdersSummary(start, end, userInfo).then(
        function (data) {
          vm.sumary = data.Data;
        },
        function (err) {
          $log.error(err);
        }
      );
    };

    // ON CURRENT PAGE CHANGE getOrders()
    vm.pageChanged = function (page) {
      vm.currentPage = page;
      vm.getOrders();
    };

    // Imprimir página actual
    vm.printTable = function() {
      // 2021-01-12 Se agrega suma de todos las transacciones
      var amountCashiers = 0;
      var a = window.open('', '', 'height=500, width=500');
      a.document.write('<html>');
      a.document.write('<body>');
      if (vm.settings.SmallReceipt) {
        a.document.write('<div id="myReceiptProduct" class="col-xs-12 col-sm-9 col-md-9"><h3>Report:</h3>');
        var tabla = "";
        for (var i=0; i< vm.orders.length; i++) {
            tabla += '<tr><td>Date:</td><td>' + vm.orders[i].TimeStamp.split('T')[0] + '</td></tr>';
            tabla += '<tr><td>Order number:</td><td>' + vm.orders[i].Id + '</td></tr>';
            tabla += '<tr><td>Account Number:</td><td>' + vm.orders[i].PhoneNumber+ '</td></tr>';
  
            tabla += '<tr><td>Product:</td><td>' + vm.orders[i].ProductName + '</td></tr>';
  
            tabla += '<tr><td>Cashier:</td><td>'+ vm.orders[i].OperatorName+ '</td></tr>';
  
            tabla += '<tr><td>Amount:</td><td>' + vm.orders[i].Amount + '</td></tr>';
            amountCashiers += vm.orders[i].Amount;
            tabla += '<tr><td colspan="2"><div class="divider">--------------------------------------</div></td></tr>';
        }
        var extraAmount = '<h4>Total: $ ' +  amountCashiers + '</h4>';
        a.document.write(extraAmount);
        a.document.write('<table class="table-condensed receipt"><tbody>');
        a.document.write(tabla);
        a.document.write('</tbody></table></div>');
      } else {
        var divContents = document.getElementById("table_report").outerHTML;
        a.document.write(divContents);
      }
      
      a.document.write('</body></html>');
      a.onafterprint = function (e) {
        a.close();
      };
      a.document.close();
      a.print();
    }

    // Sección para traer por hoy
    vm.getToday = function () {
      vm.orders = vm.backupOrders.filter(function (order) {
        return order.TimeStamp.split('T')[0] == new Date().toISOString().split('T')[0];
      });
    }

    vm.changePrinter = function () {
      vm.settings.SmallReceipt2 = !vm.settings.SmallReceipt;
    }
    vm.changePrinter2 = function () {
      vm.settings.SmallReceipt = !vm.settings.SmallReceipt2;
    }
    // SETTINGS
    // GET SETTINGS
    vm.getSettings = function () {
      SettingsFactory.getSettings().then(
        function (data) {
          var arr = data;
          localStorageService.set('settings', arr);
          vm.settings = arr;
          if (vm.settings.SmallReceipt) {
            vm.settings.SmallReceipt = true;
            vm.settings.SmallReceipt2 = false;
          } else {
            vm.settings.SmallReceipt2 = true;
            vm.settings.SmallReceipt = false;
          }
        },
        function (err) {
          $log.error(err);
        }
      );
    };
    // UPDATE SETTINGS
    vm.updateSettings = function (form) {

      // Trigger validation flag.
      vm.submitted = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        $log.error('Check errors below (in red color)');
        vm.invalidSettingsForm = true;
        return;
      }

      if (form.$valid) {
        SettingsFactory.updateSettings(userInfo.MerchantId, vm.settings.SmallReceipt, vm.settings.Tax, vm.settings.ConfirmPhone, vm.settings.PaxTerminalAsPrinter)
          .then(
            function (response) {
              if (response.Status === 200) {
                vm.updateSettingsResponse = response;
                localStorageService.set('settings', response.Data);
                Notification.success('Settings successfuly updated!');
              } else {
                $log.error(response.ErrorMessage);
              }
            },
            function (err) {
              $log.error(err.ErrorMessage);
            }
          );
      }
    };
    vm.loginOverSesion = function (password) {
      AuthenticationFactory.login(userInfo.MerchantId, password)
        .then(function (response) {
            if (response.Status === 200) {
              vm.adminLogged = response.UserInfo.IsMerchant;
            } else {
              $log.error('Invalid Admin Credentials');
            }
          },
          function (err) {
            $log.error(err);
          }
        );
    };

    // Form submit handler.
    vm.submit = function (form) {
      // Trigger validation flag.
      vm.submitted = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        return;
      }

      if (form.$valid) {
        // add founds to account
        AdminFactory.addAchFunds(vm.Id, vm.AccountNumber, vm.RoutingNumber, vm.MerchantId, vm.Amount, vm.SaveAccount, vm.TypeChecking)
          .then(
            function (response) {
              $log.debug(response);
            },
            function (err) {
              $log.error(err.ErrorMessage);
            }
          );
      }
    };

    // Update orders
    vm.updateOrders = function () {
      vm.spin = true;
      vm.getOrders();
    };

    // GET ADMIN DATA
    vm.getSettings();
    vm.getCashiers();
    vm.getOrders();
    vm.getAllOrdersSummary(); 
    vm.getPortIns();

    // set dates to today, from and to
    vm.today = function () {
      vm.todayDates();
      vm.getOrders();
      vm.getAllOrdersSummary();
    };
    // set dates to default, from 6 months to today
    vm.clear = function () {
      vm.initDates();
      vm.getOrders();
      vm.getAllOrdersSummary();
    };
    // let user ask for orders by custom dates
    vm.getOrdersByDate = function () {
      vm.getOrders();
      vm.getAllOrdersSummary();
    };

    vm.refundOrder = function (orderId) {
      OrderFactory.refundOrder(orderId, userInfo).then(
        function (response) {
          if (response.Status === 200) {
            $log.error(response.ErrorMessage);
            // update item refunded in scope, don't ask to server as
            // the Status was 200, success
            angular.forEach(vm.orders, function (item) {
              if (item.Id === orderId) {
                item.IsRefundable = false;
              }
            });
          } else {
            Notification.error('Refund rejected');
          }
        },
        function (err) {
          $log.error(err.ErrorMessage);
        }
      );
    };
    vm.reSendOrderConfirmation = function (orderId) {
      OrderFactory.reSendOrderConfirmation(orderId, userInfo).then(
        function (response) {
          if (response.Status === 200) {
            //Open modal with info about billing order...the obj response should have receipt
            $uibModal.open({
              templateUrl: 'app/admin/_modal-receipt.html',
              controller: 'ModalReceiptCtrl',
              size: 'lg',
              windowClass: 'product-modal',
              resolve: {
                receipt: function () {
                  response.Data.MerchantId = userInfo.MerchantId;
                  return response.Data;
                },
                item: function () {
                  return null;
                }
              }
            });


          } else {
            $log.error(response.ErrorMessage);
          }
        },
        function (err) {
          $log.error(err.ErrorMessage);
        }
      );
    };

    // download as CSV.
    vm.downloadAsCvs = function () {
      var start = $filter('date')(vm.start, 'MM/dd/yy', '-0500');
      var end = $filter('date')(vm.end, 'MM/dd/yy', '-0500');

      OrderFactory.downloadAsCvs(start, end, userInfo).then(
        function (response) {
          var csvHeader = [];
          var headers = '';
          var rows = '';
          var orders = '';
          // take header from object keys
          angular.forEach(response.Data[0], function (value, key) {
            csvHeader.push('"' + key + '"');
          });

          headers = csvHeader.toString();
          // take each object and make a row
          angular.forEach(response.Data, function (item) {
            var csvRow = [];

            angular.forEach(item, function (value) {
              csvRow.push('"' + value + '"');
            });

            rows = rows.concat(csvRow.toString());
            rows = rows.concat('\n');
          });
          // compose data
          orders = orders.concat(headers);
          orders = orders.concat('\n');
          orders = orders.concat(rows);
          // construc file name using dates
          vm.doFilename = function () {
            return 'orders-from-' + start.replace(/[^0-9\.]+/g, '') + '-to-' + end.replace(/[^0-9\.]+/g, '') + '.csv';
          };
          // start building csv file
          var charset = vm.charset || 'utf-8';
          var blob = new Blob([orders], {
            type: 'text/csv;charset=' + charset + ';'
          });
          // construc link & download it
          if (window.navigator.msSaveOrOpenBlob) {
            navigator.msSaveBlob(blob, vm.doFilename());
          } else {
            var downloadLink = angular.element('<a></a>');
            downloadLink.attr('href', window.URL.createObjectURL(blob));
            downloadLink.attr('download', vm.doFilename());
            downloadLink.attr('target', '_blank');

            $document.find('body').append(downloadLink);

            $timeout(function () {
              downloadLink[0].click();
              downloadLink.remove();
            }, null);
          }

        },
        function (err) {
          $log.error(err);
        }
      );
    };
    // send CSV via email
    vm.sendAsEmail = function () {
      // setup params
      var start = $filter('date')(vm.start, 'MM/dd/yy', '-0500');
      var end = $filter('date')(vm.end, 'MM/dd/yy', '-0500');
      var email = vm.email;

      OrderFactory.sendAsEmail(start, end, email, userInfo).then(
        function (response) {
          if (response.Status === 200) {
            Notification.success('Email Sent to ' + email);
          } else {
            Notification.error('Failed to send email');
          }
        },
        function (err) {
          $log.error(err.ErrorMessage);
        }
      );
    };

    // 2020-10-08 Save ath account in server
    vm.saveATH = function () {
      AdminFactory.saveATH(vm.ath.merchantID, vm.ath.token).then(
        function (response) {
          vm.ath.id = response.data.recordset[0].id;
          vm.editModeATH = true;
          if (response.data[0] && response.data[0][0]) {
            localStorage.setItem('ath', response.data[0][0].token);
          }
        }
      ).catch(
        function (error) {
          console.log('Error', error);
        }
      );
    };
    // 2020-10-08 delete actual ath account
    vm.deleteATH = function () {
      AdminFactory.deleteATH(vm.ath.id).then(
        function (response) {
          vm.ath.token = null;
          vm.editModeATH = false;
          localStorage.removeItem('ath');
        }
      ).catch(
        function (error) {
          console.log('Error', error);
        }
      );
    };

    vm.rePrintOrder = function (order) {
      var a = window.open('', '', 'height=500, width=500');
      a.document.write('<html>');
      a.document.write('<body>');
      a.document.write('<div id="myReceiptProduct" class="col-xs-12 col-sm-9 col-md-9"><h3>Report:</h3><table class="table-condensed receipt"><tbody>');
      var tabla = "";
      tabla += '<tr><td>Date:</td><td>' + order.TimeStamp.split('T')[0] + '</td></tr>';
      tabla += '<tr><td>Order number:</td><td>' + order.Id + '</td></tr>';
      tabla += '<tr><td>Account Number:</td><td>' + order.PhoneNumber+ '</td></tr>';
      tabla += '<tr><td>Product:</td><td>' + order.ProductName + '</td></tr>';
      tabla += '<tr><td>Cashier:</td><td>'+ order.OperatorName+ '</td></tr>';
      tabla += '<tr><td>Amount:</td><td>' + order.Amount + '</td></tr>';
      tabla += '<tr><td>MID:</td><td>' + userInfo.MerchantId + '</td></tr>';
      tabla += '<tr><td colspan="2"><div class="divider">-----------------------------------</div></td></tr>';
      a.document.write(tabla);
      a.document.write('</tbody></table></div>');
      a.document.write('</body></html>');
      a.onafterprint = function (e) {
        a.close();
      };
      a.document.close();
      a.print();
    }
  }
})();
