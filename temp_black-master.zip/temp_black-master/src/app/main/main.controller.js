(function() {
  "use strict";

  angular.module("posClient").controller("MainController", MainController);

  MainController.$inject = [
    "$rootScope",
    "$scope",
    "$location",
    "localStorageService",
    "AuthenticationFactory",
    "MerchantFactory",
    "AdminFactory",
    "$uibModal",
    "ProdsFactory",
  ];

  function MainController(
    $rootScope,
    $scope,
    $location,
    localStorageService,
    AuthenticationFactory,
    MerchantFactory,
    AdminFactory,
    $uibModal,
    ProdsFactory
  ) {
    var merchant = {};
    var latMenu;
    var lateralMenuProducts;
    merchant.userInfo = AuthenticationFactory.getUserInfo();
    // console.log(merchant.userInfo);
    merchant.salesDetails = null;
    merchant.balanceDetails = null;

    // alert
    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };

    // TOP NAV INFO
    var homeInfo = function() {
      var viewInfo = {
        show: true,
        title: "Payment portal",
        instruction: "Select category",
      };
      return viewInfo;
    };

    var navInfo = function() {
      var param1 = $location
        .path()
        .split("/")
        .splice(1, 1)
        .toString();
      var param2 = $location
        .path()
        .split("/")
        .splice(2, 1)
        .toString();
      var param3 = $location
        .path()
        .split("/")
        .splice(3, 1)
        .toString();
      var param4 = $location
        .path()
        .split("/")
        .splice(4, 1)
        .toString();

      var viewInfo = {
        show: true,
        title: param1,
        instruction: "Select" + param1.toUpperCase(),
      };

      function posViewInfo(category) {
        switch (category) {
          case "longdistance":
            viewInfo = {
              show: true,
              title: "Long Distance",
              instruction:
                param4 === "countries" ? "Select Country" : "Select Product",
            };
            break;
          case "international":
            viewInfo = {
              show: true,
              title: "International Top Up",
              instruction:
                param4 === "countries" ? "Select Country" : "Select Product",
            };
            break;
          case "pinless":
            viewInfo = {
              show: true,
              title: "Pinless",
              instruction: "Select Product",
            };
            break;
          case "wireless":
            viewInfo = {
              show: true,
              title: "Wireless",
              instruction:
                param4 === "carriers" ? "Select Carrier" : "Select Product",
            };
            break;
          case "promotions":
            viewInfo = {
              show: true,
              title: "Promotions",
              instruction: "Select Product",
            };
            break;
          default:
            viewInfo = {
              show: $location.path() === "/login" ? false : true,
              title: param1,
              instruction: "Select item",
            };
        }

        // console.log(category);
        return viewInfo;
      }

      switch (param1) {
        case "pos":
          posViewInfo(param3);
          break;
        case "sunpass":
          viewInfo = {
            show: true,
            title: param1,
            instruction: "Select " + param1.toUpperCase(),
          };
          break;
        case "billpayment":
          viewInfo = {
            show: true,
            title: "Bill Payment",
            instruction:
              param2 === "categories"
                ? "Select Category"
                : param2 === "category"
                ? "Select Biller"
                : "Complete the form",
          };
          break;
        case "others":
          viewInfo = {
            show: true,
            title: param1,
            instruction: "Select item",
          };
          break;
        case "directtv":
          viewInfo = {
            show: true,
            title: "Direct Tv",
            instruction:
              param2 === "categories"
                ? "Select Category"
                : param2 === "category"
                ? "Select Product"
                : "Complete the form",
          };
          break;
        default:
          viewInfo = {
            show: $location.path() === "/login" ? false : true,
            title: param1,
            instruction: "Select item",
          };
      }

      return viewInfo;
    };

    // show / hide HOME button
    var showHome = function() {
      return $location.path() === "/" ||
        $location.path() === "/login" ||
        $location.path() === "/metelelogin" ||
        $location.path() === "/tnblogin"
        ? false
        : true;
    };
    var showAccount = function() {
      return $location.path() === "/login" ||
        $location.path() === "/metelelogin" ||
        $location.path() === "/tnblogin"
        ? false
        : true;
    };
    var showNav = function() {
      return $location.path() === "/login" ||
        $location.path() === "/metelelogin" ||
        $location.path() === "/tnblogin"
        ? false
        : true;
    };

    var getUserInfo = function() {
      var userInfo = AuthenticationFactory.getUserInfo();
      return userInfo;
    };

    // view info
    if ($location.path() === "/") {
      $scope.viewInfo = homeInfo();
    } else {
      $scope.viewInfo = navInfo();
    }

    // GET SALES SUMMARY
    var getSalesSummary = function() {
      var userInfo = getUserInfo();

      MerchantFactory.getSalesSummary(
        userInfo.MerchantId,
        userInfo.MerchantPassword,
        userInfo.Role
      ).then(
        function(data) {
          merchant.salesDetails = data;
          //console.log(data);
        },
        function(error) {
          $scope.error = error;
          void 0;
        }
      );
    };

    // GET BALANCE DETAILS
    var getBalanceDetails = function() {
      var userInfo = getUserInfo();
      merchant.userInfo = userInfo;
      // console.log(userInfo);

      MerchantFactory.getBalanceDetails(
        userInfo.MerchantId,
        userInfo.MerchantPassword,
        userInfo.Role
      ).then(
        function(data) {
          merchant.balanceDetails = data;
          // getUserInfo();
          $scope.spin = false;
          // console.log(data);
        },
        function(error) {
          $scope.error = error;
          void 0;
        }
      );
    };

    // var getAppMainLogoUrl = function() { 	var userInfo = getUserInfo();
    // 	AdminFactory.getAppMainLogoUrl(userInfo.MerchantId,
    // userInfo.MerchantPassword).then( 		function(data){ 			$scope.logourl =
    // data.Data; 			localStorageService.set('logourl', data.Data); 		},
    // 		function(error){ 			console.log(error); 		} 	); }; My Account modal Modal
    // (ui.bootstrap.modal). In Docs (item) pass modal size, here pass the single
    // item object
    $scope.openAccountModal = function() {
      merchant.userInfo = AuthenticationFactory.getUserInfo();
      var modalInstance = $uibModal.open({
        templateUrl: "app/admin/modal-account-tpl.html",
        controller: "ModalAccountCtrl",
        size: "lg",
        windowClass: "product-modal",
        resolve: {
          item: function() {
            getSalesSummary();

            //getBalanceDetails(); console.log(merchantData);

            return merchant;
          },
        },
      });

      modalInstance.result.then(
        function(selectedItem) {
          $scope.selected = selectedItem;
        },
        function() {
          // $log.info('Modal dismissed at: ' + new Date());
        }
      );
    };

    // interface vars (show/hide) elements
    $scope.showHome = showHome();
    $scope.showAccount = showAccount();
    $scope.showNav = showNav();

    // var DEF = {title: 'Welcome', logo: '', favicon: 'favicon.png'};
    var BS = {
      title: "POS",
      logo: "https://mobile.blackstonepos.com/logos/pos-logo.png",
      favicon: "favicon.png",
    };
    var FCUSA = {
      title: "FCUSA",
      logo: "https://mobile.blackstonepos.com/logos/fullCarga.png",
      favicon: "favicon-fcusa.png",
    };

    if (merchant.userInfo && merchant.userInfo.IsFullCarga) {
      $scope.comInfo = FCUSA;
      $scope.isFullCarga = true;
    } else {
      $scope.comInfo = BS;
      $scope.isFullCarga = false;
    }

    $scope.userInfo = merchant.userInfo;

    // update showHome & showAccount & userInfo, to control buttons display
    $scope.$watch(
      function() {
        return $location.path();
      },
      function(newValue, oldValue) {
        if (newValue === oldValue) {
          return;
        }

        $scope.showHome = showHome();
        $scope.showAccount = showAccount();
        $scope.showNav = showNav();

        $scope.userInfo = AuthenticationFactory.getUserInfo();
        // $scope.getLateralMenuProducts(lateralMenuItems);
        $scope.isFullCarga =
          $scope.userInfo && $scope.userInfo.IsFullCarga === true
            ? true
            : false;
        $scope.comInfo =
          $scope.userInfo && $scope.userInfo.IsFullCarga === true ? FCUSA : BS;
        // console.log($scope.userInfo); set title in navigation from $location.path()
        // #/pos/category/pinless = 0/1/2/3
        if (newValue === "/") {
          $scope.viewInfo = homeInfo();
        } else {
          $scope.viewInfo = navInfo();
        }
        if (!latMenu && $scope.showNav) {
          latMenu = showNav();
          $scope.getLateralMenuProducts = function(itemsCollection) {
            $scope.itemsLateralMenu1 = [];
            $scope.itemsLateralMenu2 = [];
            lateralMenuProducts = [];

            if ($scope.userInfo !== undefined) {
              ProdsFactory.getPosMainProducts(
                $scope.userInfo.MerchantId,
                $scope.userInfo.MerchantPassword
              ).then(
                function(data) {
                  lateralMenuProducts = data;

                  for (var i = 0; i < itemsCollection.length / 2; i++) {
                    if (
                      lateralMenuProducts.indexOf(
                        itemsCollection[i].categoryName
                      ) >= 0
                    ) {
                      $scope.itemsLateralMenu1.push(itemsCollection[i]);
                      $scope.itemsLateralMenu2.push(
                        itemsCollection[itemsCollection.length / 2 + i]
                      );
                    }
                  }
                  //$scope.items.push(itemsCollection[5]);
                },
                function(error) {
                  $log.error(error);
                }
              );
              // Carga de productos más vendidos
    
            }
          };
          $scope.getLateralMenuProducts(lateralMenuItems);
        }
        // console.log(newValue);

        // $scope.getLateralMenuProducts = function(itemsCollection) {
        //   $scope.itemsLateralMenu = [];

        //   var lateralMenuProducts = [];

        //   ProdsFactory.getPosMainProducts(
        //     merchant.userInfo.MerchantId,
        //     merchant.userInfo.MerchantPassword
        //   ).then(
        //     function(data) {
        //       lateralMenuProducts = data;

        //       // console.log('main products: ' + mainProducts); console.log(data);

        //       for (var i = 0; i < itemsCollection.length; i++) {
        //         if (
        //           lateralMenuProducts.indexOf(
        //             itemsCollection[i].categoryName
        //           ) >= 0
        //         ) {
        //           $scope.itemsLateralMenu.push(itemsCollection[i]);
        //         }
        //       }
        //       //$scope.items.push(itemsCollection[5]);
        //     },
        //     function(error) {
        //       $log.error(error);
        //     }
        //   );
        // };

        // $scope.getLateralMenuProducts(lateralMenuItems);

        // select tag to filter products
        // $scope.filterables = [
        //   {
        //     name: "Rate",
        //     value: "rate",
        //   },
        //   {
        //     name: "Country",
        //     value: "countryName",
        //   },
        //   {
        //     name: "Category",
        //     value: "category",
        //   },
        // ];

        // $scope.items = $scope.filterables[0].value;

        // $scope.selectLateralMenuProduct = function(item) {
        //   localStorageService.set("selection", item);
        // };
      },
      true
    );

    //Logout user.
    $scope.logout = function() {
      latMenu = false;
      AuthenticationFactory.logout();
      // localStorageService.set('userInfo', ''); localStorageService.clearAll();
    };

    // Watch if user is logged in $scope.$watch(   AuthenticationFactory.isLoggedIn,
    //   function (value, oldValue) {     if (!value && oldValue) {       void 0;
    //    $location.path('/login');     }     if (value) {       void 0;     }   },
    // true);

    //LATERAL MENU

    var lateralMenuItems = [
      {
        categoryName: "billpayment",
        title: "Bill Payment",
        url: "#/billpayment/category" /**/,
        img: "/assets/images/home/billpayment.jpg",
        position: 10,
        icon: "",
      },
      {
        categoryName: "international",
        title: "Int'l Top Up",
        url: "#/pos/category/international/countries",
        img: "/assets/images/home/international.png",
        position: 1,
        icon: "",
      },
      {
        categoryName: "pinless",
        title: "Pinless Recharge",
        url: "#/pos/category/pinless",
        img: "/assets/images/home/pinless.png",
        position: 3,
        icon: "",
      },
      {
        categoryName: "longdistance",
        title: "Long Distance",
        url: "#/pos/category/longdistance",
        img: "/assets/images/home/longdistance.png",
        position: 2,
        icon: "",
      },
      {
        categoryName: "wireless",
        title: "Wireless Recharge",
        url: "#/pos/category/wireless/carriers",
        img: "/assets/images/home/wireless.png",
        position: 5,
        icon: "",
      },
      {
        categoryName: "sunPass",
        title: "Tolls",
        // url: '#/tolls',
        url: "#/pos/category/tolls",
        img: "/assets/images/home/sunPass.png",
        position: 4,
        icon: "",
      },
      {
        categoryName: "promotions",
        title: "Promotions",
        url: "#/pos/category/promotions",
        img: "/assets/images/home/promotions.png",
        position: 6,
        icon: "star",
      },
      {
        categoryName: "directtv",
        title: "Direct TV",
        url: "#/directtv/categories" /**/,
        img: "/assets/images/home/tv.svg",
        position: 9,
        icon: "",
      },
      {
        categoryName: "prepaidOthers",
        title: "Others",
        url: "#/pos/category/prepaidOthers",
        img: "/assets/images/home/prepaidOthers.png",
        position: 7,
        icon: "",
      },
      // {categoryName: 'MySmsCuba', title: 'MySmsCuba', url: '#/mysmscuba', position:
      // 10, icon: ''} {categoryName: 'activationShop', title: 'Activation Shop',
      // url: '#/activationshop', position: 11, icon: ''} {categoryName: 'Others',
      // url: '#/pos/others', position: 12},
    ];

    latMenu = showNav();
    if (latMenu === undefined || latMenu === false) {
    } else {
      $scope.getLateralMenuProducts = function(itemsCollection) {
        $scope.itemsLateralMenu1 = [];
        $scope.itemsLateralMenu2 = [];
        $scope.itemsLateralMenu3 = [];
        lateralMenuProducts = [];

        if (merchant.userInfo !== undefined) {
          ProdsFactory.getPosMainProducts(
            merchant.userInfo.MerchantId,
            merchant.userInfo.MerchantPassword
          ).then(
            function(data) {
              lateralMenuProducts = data;

              // console.log('main products: ' + mainProducts); console.log(data);

              $scope.itemsLateralMenu1.push(itemsCollection[0]);
              $scope.itemsLateralMenu1.push(itemsCollection[1]);
              $scope.itemsLateralMenu1.push(itemsCollection[2]);

              $scope.itemsLateralMenu2.push(itemsCollection[3]);
              $scope.itemsLateralMenu2.push(itemsCollection[4]);
              $scope.itemsLateralMenu2.push(itemsCollection[5]);

              $scope.itemsLateralMenu3.push(itemsCollection[6]);
              $scope.itemsLateralMenu3.push(itemsCollection[7]);
              $scope.itemsLateralMenu3.push(itemsCollection[8]);
              //$scope.items.push(itemsCollection[5]);
            },
            function(error) {
              $log.error(error);
            }
          );
        }
      };

      $scope.getLateralMenuProducts(lateralMenuItems);
    }

    // select tag to filter products
    $scope.filterables = [
      {
        name: "Rate",
        value: "rate",
      },
      {
        name: "Country",
        value: "countryName",
      },
      {
        name: "Category",
        value: "category",
      },
    ];

    // $scope.items = $scope.filterables[0].value;

    $scope.selectLateralMenuProduct = function(item) {
      localStorageService.set("selection", item);
    };

    
  }
})();
