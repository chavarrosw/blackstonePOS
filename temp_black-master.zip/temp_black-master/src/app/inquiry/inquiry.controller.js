(function () {
  'use strict';

  angular
    .module('posClient')
    .controller('InquiryController', InquiryController);

  InquiryController.$inject = ['$log', '$window', '$routeParams', 'ComcastService', 'BsUiMessages', 'InquiryMap', 'SharedData'];

  function InquiryController($log, $window, $routeParams, ComcastService, BsUiMessages, InquiryMap, SharedData) {
    var vm = this;

    vm.message = 'Check Availability for Xfinity Prepaid Products';
    vm.inquiryTemplateUrl = '';
    vm.showProducts = false;
    vm.showInquiry = true;

    vm.comcastInquiryModel = {
      phone: null,
      confirmedPhone: null,
      zipCode: null,
      purchaseId: null
    };   

    vm.inquiryId = $routeParams.inquiryId;
    vm.grouperId = $routeParams.gid;

    vm.products = [];

    vm.GetXXX = GetXXX;

    activate();

    function GetXXX() {
      ComcastService.GetComcastPlans(vm.comcastInquiryModel.phone, vm.comcastInquiryModel.zipCode, vm.inquiryId, vm.grouperId).then(onSuccess, onError);

      function onSuccess(data) {
        vm.comcastInquiryModel.purchaseId = data.PurchaseId;
        SharedData.setInquiryGlobalObject(vm.comcastInquiryModel);
        vm.products = data.ProductList;
        if (vm.products.length == 1) {
            //var url = '#/pos/category/' + $scope.category + '/product/' + $scope.items[0].Code;
            $window.location.href = vm.products[0].url;
        }
        switchToProductsView();
      }

      function onError() {
        Notification.error(BsUiMessages.serverError.message);
      }
    }

    ////////////////

    function activate() {
      vm.inquiryTemplateUrl = InquiryMap[vm.inquiryId];
    }

    function switchToProductsView() {
      vm.showProducts = true;
      vm.showInquiry = false;
    }
  }
})();
