(function () {
  'use strict';

  angular
    .module('posClient')
    .factory('ComcastService', ComcastService);

  ComcastService.$inject = ['$http', 'API_URL', 'localStorageService', 'AuthenticationFactory', 'SharedFunctions'];

  function ComcastService($http, API_URL, localStorageService, AuthenticationFactory, SharedFunctions) {
    var userInfo = AuthenticationFactory.getUserInfo();
    var service = {
      GetComcastPlans: GetComcastPlans
    };

    return service;

    ////////////////
    function GetComcastPlans(phone, zipCode, inquiryId, grouperId) {

      var myUrl = API_URL + "v2/products/grouper/inquiry";
      var data = {
        PhoneNumber: phone,
        ZipCode: zipCode,
        MerchantId: userInfo.MerchantId,
        MerchantPassword: userInfo.MerchantPassword,
        InquiryId: inquiryId,
        GrouperId: grouperId
      };

      return $http.post(myUrl, data).then(onSuccess);

      function onSuccess(response){
        response.data.ProductList = SharedFunctions.mapProductsURL(response.data.ProductList);
        return response.data;
      }
      
    }
  }
})();
