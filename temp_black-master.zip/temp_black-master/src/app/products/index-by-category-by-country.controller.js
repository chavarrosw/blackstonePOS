(function () {
    'use strict';

    angular
        .module('posClient')
        .controller('IndexByCategoryByCountryController', IndexByCategoryByCountryController);

    IndexByCategoryByCountryController.$inject = [
        '$scope',
        '$routeParams',
        'ProdsFactory',
        'Notification',
        'localStorageService',
        'AuthenticationFactory',
        'SharedFunctions',
        '$location'
    ];
    function IndexByCategoryByCountryController($scope, $routeParams, ProdsFactory, Notification, localStorageService, AuthenticationFactory, SharedFunctions, $location) {
        // get category and country by $routeParams
        var category = $routeParams.category;
        var CountryCode = $routeParams.country;
        
        // show button to wireless carriers
        $scope.useMostPopular = true;
        $scope.isMostPopular = false;
        $scope.useConfig = true;
        $scope.useAcronymFilter = true;
        $scope.showAcronymFilter = true;
        $scope.selectdisplay = 'country';
        $scope.configDisplay = 'Country';
        $scope.configPath = 'category/' + category + '/countries';
        $scope.viewsearch = 'countries';
        $scope.type = $location
            .path()
            .split('/')
            .splice(1, 1)
            .toString();
        $scope.category = category;
        $scope.mostpopular = 'category/' + category;

        // console.log($scope.country);
        var userInfo = AuthenticationFactory.getUserInfo();
        $scope.getCountryDetails = function () {
            ProdsFactory
                .getCountryDetails(category, CountryCode, userInfo)
                .then(function (data) {
                    $scope.details = data;
                }, function (error) {
                    void 0;
                });
        };
        $scope.getProductInitialsByCategoryByCountry = function () {
            ProdsFactory
                .getProductInitialsByCategoryByCountry(category, CountryCode, userInfo)
                .then(function (data) {
                    $scope.alpha = data;
                    // console.log(data);
                }, function (error) {
                    void 0;
                });
        };
        $scope.getProductsByCategoryByCountry = function () {
            ProdsFactory
                .getProductsByCategoryByCountry(category, CountryCode, userInfo)
                .then(function (data) {
                    $scope.items = data;
                }, function (error) {
                    void 0;
                });
        };
        //$scope.getCountryDetails(); $scope.getProductInitialsByCategoryByCountry();
        $scope.getProductsByCategoryByCountry();
    }
})();
