(function () {
  'use strict';

  // Usage:
  // 
  // Creates:
  // 

  angular
    .module('posClient')
    .component('productList', {
      templateUrl: 'app/products/product-list-component/product-list.html',
      controller: ProductListComponentController,
      controllerAs: 'vm',
      bindings: {
        products: '<',
      },
    });

  ProductListComponentController.$inject = ['$log'];

  function ProductListComponentController($log) {
    var vm = this;
    //$log.error("data");  
    vm.no_result = false;

    // console.log(vm.products)

    ////////////////

    vm.$onInit = function () { };
    vm.$onChanges = function (binding) { 
      vm.no_result = binding.products.currentValue && binding.products.currentValue.length < 1;
    };
    vm.$onDestroy = function () {};

    // Para favoritos
    vm.addFavorite = function (product) {
      // Se comenta esta funcionalidad ya que se puede consultar los productos mas vendidos
      // 2020-10-02 de octubre
      var products2 = [];
      if (localStorage.getItem('favorites') != null)  {
        products2 = JSON.parse(localStorage.getItem('favorites'));
      } else {
        products2 = []
      }
      var index = 0;
      if (products2 !== null && products2 !== undefined) {
        index = products2.findIndex(function(item) {
          return item ? item.Code === product.Code : false;
         });
         if (index === -1) {
          products2.unshift(product);
         }
         localStorage.setItem('favorites', JSON.stringify(products2.slice(0, 10)));
      }
    }
  }
})();
