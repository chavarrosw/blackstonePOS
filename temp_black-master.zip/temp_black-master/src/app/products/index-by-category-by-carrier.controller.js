(function () {
    'use strict';

    angular.module('posClient')
    // might ngInject list all products by category
        .controller('IndexByCategoryByCarrierCtrl', [
        '$scope',
        '$routeParams',
        'ProdsFactory',
        'Notification',
        'localStorageService',
        'AuthenticationFactory',
        '$location',
        function ($scope, $routeParams, ProdsFactory, Notification, localStorageService, AuthenticationFactory, $location) {
            
            // get category and country by $routeParams
            var carrier = $routeParams.carrier;

            $scope.useMostPopular = true;
            $scope.isMostPopular = false;
            $scope.useConfig = true;
            $scope.useAcronymFilter = true;
            $scope.showAcronymFilter = true;
            $scope.viewsearch = 'carriers';
            $scope.selectdisplay = 'carrier';
            $scope.type = $location
                .path()
                .split('/')
                .splice(1, 1)
                .toString();
            $scope.category = $routeParams.category;
            $scope.mostpopular = 'category/' + $scope.category;

            // console.log(category +' '+ carrier );
            var userInfo = AuthenticationFactory.getUserInfo();
            $scope.getWirelessCarrierDetails = function () {
                ProdsFactory
                    .getWirelessCarrierDetails(carrier, userInfo)
                    .then(function (data) {
                        $scope.details = data;
                    }, function (error) {
                        void 0;
                    });
            };
            $scope.getWirelessProductsByCarrier = function () {
                ProdsFactory
                    .getWirelessProductsByCarrier(carrier, userInfo)
                    .then(function (data) {
                        $scope.items = data;
                        // console.log(data);
                    }, function (error) {
                        void 0;
                    });
            };

            //$scope.getWirelessCarrierDetails();
            $scope.getWirelessProductsByCarrier();
        }
    ]);
}());