

(function () {
  'use strict';

  angular
    .module('posClient')
    .controller('ProductController', ProductController);

  ProductController.$inject = [
    '$log',
    '$routeParams',
    '$uibModal',
    'ProdsFactory',
    'localStorageService',
    'AuthenticationFactory',
    'SharedFunctions',
    'SharedData',
    'ConfirmationFactory',
    'SettingsFactory',
    'Notification',
    '$window'
  ];

  function ProductController($log, $routeParams, $modal, ProdsFactory, localStorageService, AuthenticationFactory, SharedFunctions, SharedData, ConfirmationFactory, SettingsFactory, Notification, $window) {
    var vm = this;
    vm.parseFloat = parseFloat;
    // vm.ATHM_Checkout = {};
    // get productMainCode by $routeParams
    var productMainCode = $routeParams.id;

    // get InquiryGlobalObject by SharedData
    vm.InquiryGlobalObject = SharedData.getInquiryGlobalObject();
    if (!vm.InquiryGlobalObject) {
      vm.zipCode = "";
      vm.purchaseId = "";
    } else {
      vm.zipCode = vm.InquiryGlobalObject.zipCode;
      vm.purchaseId = vm.InquiryGlobalObject.purchaseId;
    }

    SharedData.clearSharedData();

    // get userInfo stored on localStorageService
    var userInfo = AuthenticationFactory.getUserInfo();

    vm.nautaForm = {
      emailAddress: "",
      confirmEmailAddress: "",
      selectedDomain: ""
    };

    // Variable para el manejo 
    vm.OtherNautaForm;

    vm.nautaDomains = ["nauta.co.cu", "nauta.com.cu"];

    //vm.nautaSelectedDomain = {};

    vm.setNauta = function (form) {
      vm.OtherNautaForm = form;
    }

    vm.submitNauta = function (form) {
      // Trigger validation flag.
      vm.submitted = true;
      // If form is invalid, return and let AngularJS show validation errors.
      if (form && form.$invalid) {
        Notification.error('Check errors below (in red color)');
        return;
      } else {
        vm.isBlocked = true;

        if (vm.phoneNumber.value === vm.item.DialCountryCode)
          vm.phoneNumber.value = "";

        var order = {
          AdditionalPhones: null,
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword, // string
          OperatorName: userInfo.userName, // string
          ProfileId: userInfo.profileId, // int
          TerminalId: userInfo.terminalId, // int
          Amount: vm.amount.value,
          PhoneNumber: vm.phoneNumber.value,
          ProductMainCode: vm.item.Code,
          CountryCode: vm.item.DialCountryCode,
          AccountEmail: form.emailAddress + "@" + form.selectedDomain

        };

        /*change01*/
        /*to see the name from the cachier not sure the avobe property exist*/
        if (!order.OperatorName)
          order.OperatorName = userInfo.Name;

        /*change01*/

        if (vm.item.AcceptAdditionalPhones) {
          order.AdditionalPhones = [];
          var additionalPhoneQuantity = vm.additionalPhoneNumbersAmount();

          for (var i = 0; i < additionalPhoneQuantity; i++) {
            order
              .AdditionalPhones
              .push(vm.additionalPhones[i].value);
          }
        }

        // console.log(order); console.log(userInfo);

        ProdsFactory
          .doBlackstonePosOperation(order)
          .then(function (response) {

            //console.log(response);

            if (response.Status === 200 || response.Status === 203) {

              var orderResultText = response.Status === 200
                ? 'Order processed!'
                : 'Order placed. Pending for further Execution!';

              vm.showReceipt = true;

              void 0;

              vm.submitted = false;
              Notification.success(orderResultText);

              vm.receipt = response.Data;

              //console.log('from transaction:' + receipt);

            } else {
              Notification.error(response.ErrorMessage);
              // Trigger validation flag.
              vm.isBlocked = false;
            }
          }, function () {
            vm.isBlocked = false;
            Notification.error('Invalid Credentials');
          });

        vm.showReceipt = false;
      }
    };

    //vm.receipt = {"ProductMainCode":null,"ProductName":"10-17-007 (Order Pending for Pax Terminal Execution.)","ProductCountry":"UNITED STATES","CarrierName":"ADMA TELECOM INC","ProductInstructions":null,"EmailAccount":null,"PinNumber":null,"ControlNumber":null,"OrderNumber":2298289,"TransactionId":null,"LocalPhones":null,"ExpirationDate":null,"CustomerService":null,"AccessNumber":null,"UpdatedBalance":null,"AccountNumber":null,"LicensePlate":null,"MessageFromTollAuthority":null,"MerchantId":0,"MerchantName":"BLACKSTONE TEST MERCHANT DBA  (T & B)","MerchantPhoneNumber":"(305) 639-9590","CashierName":"MANAGER","MerchantAddress":"11600 NW 34TH ST","OrderDate":"2020-10-19T14:14:23.9967001-04:00","PhoneNumber":null,"Amount":3.0,"Fee":0.0,"Tax":0.3450,"Total":3.3450,"AuthorizationNumber":null,"ReferenceNumber":null,"PortInTransactionId":null,"SimActivated":null}
    // set form visibility
    vm.showReceipt = false;
    // detect if devise is mobile to set input to readonly
    vm.isMobile = SharedFunctions.isMobile();

    // product details accordion
    vm.oneAtATime = true;
    vm.status = {
      isFirstOpen: !SharedFunctions.isMobile(),
      isFirstDisabled: false
      // open = !vm.isMobile
    };

    // GET SETTINGS

    SettingsFactory
      .getSettings()
      .then(function (data) {
        var arr = data;
        localStorageService.set('settings', arr);
        vm.settings = arr;
      }, function (error) {
        $log.error(error);
      });
    // // get merchant settings (confirm phone) vm.settings =
    // localStorageService.get('settings'); console.log(vm.settings);

    function initInputs() {
      if (!vm.phoneNumber.value) {
        vm.phoneNumber.value = '';
      }
      if (!vm.amount.value) {
        vm.amount.value = '';
      }
      if (!vm.phoneMatch.value) {
        vm.phoneMatch.value = '';
      }
      if (!vm.topUpPin.value) {
        vm.topUpPin.value = '';
      }
    }

    // get product info
    vm.getProduct = function () {
      ProdsFactory
        .getProduct(productMainCode, userInfo)
        .then(function (data) {
          vm.item = data;
          if (!vm.InquiryGlobalObject) {
            vm.phoneNumber.value = vm.phoneMatch.value = data.DialCountryCode;
          } else {
            vm.phoneNumber.value = vm.phoneMatch.value = vm.InquiryGlobalObject.phone;
          }

          vm.hasKeyPad = !data.UseFixedDenominations || data.IsTopUp;
          if (vm.item.UseFixedDenominations) {
            vm.amount.value = vm.item.Denominations[0];
          }
          vm.payATH();
        }, function (error) {
          $log.error(error);
        });
    };
    vm.getProduct();

    // init inputs values and state
    vm.phoneNumber = {
      value: null,
      isFocused: true
    };
    vm.phoneMatch = {
      value: null,
      isFocused: false
    };
    vm.topUpPin = {
      value: null,
      isFocused: false
    };
    vm.amount = {
      value: null,
      isFocused: false
    };
    // 
    // vm.item = { UseFixedDenominations: true}; this statement need to be changed
    // when other merchant add additional phones to its product. Till now is ok cuz
    // there is only one, "Siempre Cerca" and the extention of the additional phones
    // is only 502 - Guatemala
    vm.additionalPhones = [
      {
        value: '502',
        isFocused: false
      }, {
        value: '502',
        isFocused: false
      }, {
        value: '502',
        isFocused: false
      }
    ];

    vm.additionalPhoneNumbersAmount = function () {
      if (vm.item && vm.item.AcceptAdditionalPhones && vm.amount.value && vm.item.DenominationsConfig) {
        var index = vm
          .item
          .DenominationsConfig
          .indexOf(vm.amount, 0, function (e, a) {
            return e.Denomination == a.value;
          });
        if (index < 0)
          return 0;
        return vm.item.DenominationsConfig[index].AdditionalPhonesQuantity;
      }
      return 0;
    };

    vm.timeRates = function (value) {
      var index = vm
        .item
        .TimeDenominations
        .indexOf(value, 0, function (e, a) {
          return e.Denomination == a;
        });
      return vm.item.TimeDenominations[index].Time;
    };

    // Modal (ui.bootstrap.modal). In Docs (item) pass modal size, here pass the
    // single item object
    vm.open = function (items) {
      var info = {
        firstItem: vm.item.Name,
        secondItem: vm.item.CountryName,
        thirdItem: vm.item.CarrierName
      };

      // angular.extend(dst, src);
      items = angular.extend(items, info);
      void 0;

      // console.log(JSON.stringify(items));

      var modalInstance = $modal.open({
        templateUrl: 'app/products/_modal-product-tpl.html',
        controller: 'ModalInstanceCtrl',
        size: 'lg',
        windowClass: 'product-modal',
        resolve: {
          item: function () {
            return items;
          }
        }
      });

      modalInstance
        .result
        .then(function (selectedItem) {
          vm.selected = selectedItem;
        }, function () {
          // $log.info('Modal dismissed at: ' + new Date());
        });
    };

    // PRODUCT RATES get product rates
    function getProductRates(maincode) {
      var myResult = ProdsFactory
        .getProductRates(maincode, userInfo)
        .then(function (data) {
          var info = {
            Name: vm.item.Name,
            CountryName: vm.item.CountryName,
            CarrierName: vm.item.CarrierName
          };

          var itemsMerged = angular.extend(data, info);
          return itemsMerged;
        }, function (error) {
          $log.error(error);
        });
      return myResult;
    }

    // call get product rates and show it into modal window
    vm.openRates = function (obj) {
      var mydata = getProductRates(obj);

      var modalInstance = $modal.open({
        templateUrl: 'app/products/_modal-product-tpl.html',
        controller: 'ModalInstanceCtrl',
        size: 'lg',
        windowClass: 'product-modal',
        resolve: {
          item: function () {
            return mydata;
          }
        }
      });

      modalInstance
        .result
        .then(function (selectedItem) {
          vm.selected = selectedItem;
        }, function () {
          // $log.info('Modal dismissed at: ' + new Date());
        });
    };

    // ACCESS NUMBERS get product access numbers
    function getProductAccessNumbers(maincode) {
      var myResult = ProdsFactory
        .getProductAccessNumbers(maincode, userInfo)
        .then(function (data) {

          var info = {
            Name: vm.item.Name,
            CountryName: vm.item.CountryName,
            CarrierName: vm.item.CarrierName
          };

          return angular.extend(data, info);
        }, function (error) {
          $log.error(error);
        });
      // console.log(myResult);
      return myResult;
    }
    // call get product access numbers and show it into modal window
    vm.openAccessNumbers = function (maincode) {

      var mydata = getProductAccessNumbers(maincode);

      // var accessData = data.Data;
      for (var i = 0; i < mydata.length; i++) {
        delete mydata.languageField;
      }

      var modalInstance = $modal.open({
        templateUrl: 'app/products/_modal-product-tpl.html',
        controller: 'ModalInstanceCtrl',
        size: 'lg',
        windowClass: 'product-modal',
        resolve: {
          item: function () {
            return mydata;
          }
        }
      });

      modalInstance
        .result
        .then(function (selectedItem) {
          vm.selected = selectedItem;
        }, function () {
          // $log.info('Modal dismissed at: ' + new Date());
        });
    };

    // Modal (ui.bootstrap.modal).
    vm.openTerms = function (items) {

      var modalInstance = $modal.open({
        templateUrl: 'app/shared/_modal-product-terms-tpl.html',
        controller: 'ModalInstanceTermsCtrl',
        size: 'lg',
        windowClass: 'product-modal',
        resolve: {
          item: function () {
            return items;
          }
        }
      });

      modalInstance
        .result
        .then(function (selectedItem) {
          vm.selected = selectedItem;
        }, function () {
          // $log.info('Modal dismissed at: ' + new Date());
        });
    };

    function focused() {
      if (vm.amount.isFocused)
        return vm.amount;
      else if (vm.phoneNumber.isFocused)
        return vm.phoneNumber;
      else if (vm.phoneMatch.isFocused)
        return vm.phoneMatch;
      else if (vm.topUpPin.isFocused)
        return vm.topUpPin;
      else {
        for (var i = 0; i < vm.additionalPhones.length; i++) {
          var phone = vm.additionalPhones[i];
          if (phone.isFocused)
            return phone;
        }
      }
      return null;
    }

    vm.setKey = function (value) {
      initInputs();
      void 0;
      var obj = focused();
      if (!obj.val)
        obj.val = '';
      obj.value += value;
      
      vm.payATH();
    };

    vm.backKey = function () {
      initInputs();
      var obj = focused();

      var length = obj.value.length;
      var value = obj.value;

      void 0;
      void 0;

      obj.value = value.substring(0, length - 1);
    };

    vm.clearKey = function () {
      var obj = focused();
      obj.value = '';

    };

    vm.setFocusedInput = function (inputName, additionalPhoneIndex) {
      vm.phoneNumber.isFocused = false;
      vm.phoneMatch.isFocused = false;
      vm.topUpPin.isFocused = false;
      vm.amount.isFocused = false;
      for (var i = 0; i < vm.additionalPhones.length; i++) {
        vm.additionalPhones[i].isFocused = false;
      }

      var obj = (additionalPhoneIndex != null
        ? vm[inputName][additionalPhoneIndex]
        : vm[inputName]);
      obj.isFocused = true;
      void 0;
    };

    vm.editing = null;
    vm.editItem = function (item) {
      vm.editing = item;
      void 0;
    };

    vm.onInputClick = function ($event) {
      $event
        .target
        .select();
    };
    vm.selectAmount = function () {
      vm.payATH();
    }

    vm.leaveInputsFocus = function () {
      vm.amount.isFocused = false;
      vm.phoneNumber.isFocused = false;
      vm.phoneMatch.isFocused = false;
      vm.topUpPin.isFocused = false;
    };

    vm.setAmount = function (value) {
      void 0;
      if (vm.amount === value) {
        vm.amount = undefined;
      } else {
        vm.amount = value;
      }
    };

    // FORM SUBMIT HANDLER
    vm.submit = function (form, optional) {

      // Trigger validation flag.
      vm.submitted = true;
      // If form is invalid, return and let AngularJS show validation errors.
      if (optional && form.$invalid) {
        Notification.error('Check errors below (in red color)');
        return;
      } else {
        vm.isBlocked = true;

        var order = {
          AdditionalPhones: null,
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword, // string
          OperatorName: userInfo.userName, // string
          ProfileId: userInfo.profileId, // int
          TerminalId: userInfo.terminalId, // int
          Amount: vm.amount.value,
          PhoneNumber: vm.phoneNumber.value,
          ProductMainCode: vm.item.Code,
          CountryCode: vm.item.DialCountryCode,
          ZipCode: vm.zipCode,
          AccountPin: vm.topUpPin.value,
          PurchaseId: vm.purchaseId
        };

        /*change01*/
        /*to see the name from the cachier not sure the avobe property exist*/
        if (!order.OperatorName)
          order.OperatorName = userInfo.Name;

        /*change01*/

        if (vm.item.AcceptAdditionalPhones) {
          order.AdditionalPhones = [];
          var additionalPhoneQuantity = vm.additionalPhoneNumbersAmount();

          for (var i = 0; i < additionalPhoneQuantity; i++) {
            order
              .AdditionalPhones
              .push(vm.additionalPhones[i].value);
          }
        }
        ProdsFactory
          .doBlackstonePosOperation(order, vm.item.MainCategory)
          .then(function (response) {

            //console.log(response);

            if (response.Status === 200 || response.Status === 203) {

              var orderResultText = response.Status === 200
                ? 'Order processed!'
                : 'Order placed. Pending for further Execution!';

              vm.showReceipt = true;

              void 0;

              vm.submitted = false;
              Notification.success(orderResultText);

              vm.receipt = response.Data;
              // Si el MID es distinto de 834 - Pruebas entonces si registramos la respuesta
              if (userInfo.MerchantId + '' !== '834') {
                const ruta = window.location.href;
                const category = ruta.split("category/")[1].split("/")[0];
                ProdsFactory.logTransaction(userInfo.MerchantId, category, vm.item.Code, response.Data.ProductName, response.Data.MerchantName, JSON.stringify(order), JSON.stringify(response.Data)).then(
                  function (res) {
                    vm.logID =  res.id;
                  }
                ).catch(function (err) {
                    console.log(err);
                  });
              }
              
            } else {
              Notification.error(response.ErrorMessage);
              // Trigger validation flag.
              vm.isBlocked = false;
            }

          }, function () {
            vm.isBlocked = false;
            Notification.error('Invalid Credentials');
          });
        vm.showReceipt = false;
      }
    };

    vm.payATH = function () {
      if (vm.item.ProductExtraDetails==51) {
        // Formulario de Nauta
        if (vm.OtherNautaForm && vm.OtherNautaForm.$invalid) {
          Notification.error('Check errors below (in red color)');
          return;
        }
      } else {
        // Formulario normal
        if (!vm.amount.value || !vm.phoneNumber.value) {
          return;
        }
      }
      vm.ath = localStorage.getItem('ath');
      if (!vm.ath) {
        return;
      }
      const codigo = vm.item ? vm.item.Code : 0
      const numero = vm.phoneNumber.value ? vm.phoneNumber.value : 0;
      const cantidad = vm.amount.value ? vm.amount.value : 0;
      const body2 = document.body;
      const script = document.createElement('script');
      script.innerHTML = '<script src="https://www.athmovil.com/api/js/v2/athmovilV2.js"></script>';
      script.src = 'url';
      script.src = 'https://www.athmovil.com/api/js/v2/athmovilV2.js';
      script.type = 'text/javascript';
      script.async = true;
      script.defer = true;
      const script2 = document.createElement('script');
      script2.type = 'text/javascript';
      script2.async = true;
      script2.defer = true;
      script2.text = "ATHM_Checkout = {env: 'production',publicToken: '"+ vm.ath + "',timeout: 600,theme: 'btn',lang: 'en',total:";
      script2.text = script2.text + cantidad + ",tax: 0.00,subtotal: 0.00,metadata1:'" + codigo;
      script2.text = script2.text + "',items: [{name:'" + codigo + "',description:'" + numero + "',quantity: '1',price:" + cantidad + ",tax: '0.00',metadata : 'User:'}]}";
      body2.appendChild(script2);
      body2.appendChild(script);

      $window.ATHM_Checkout.onCompletedPayment = function (response) {
         if (vm.item.ProductExtraDetails==51) {
           // Formulario de Nautica
          vm.submitNauta(vm.OtherNautaForm);
         } else {
           // Formulario normal
          vm.submit(null, false);
         }
      }
      $window.ATHM_Checkout.onCancelledPayment = function (response) {
        Notification.error('Payment with ATH canceled');
      }
      $window.ATHM_Checkout.onExpiredPayment = function (response) {
        console.log('expirado', response);
        Notification.error('Payment with ATH expired');
      }
    }

    vm.goBackFinish = function () {
      const ruta = window.location.origin;
      const completa = window.location.href;
      const ruta_2 = ruta + "/#/pos/category/";
      const y = completa.replace(ruta_2, "");
      const segmentos = y.split("/");
      const ruta_previa = ruta_2 + segmentos[0]; // Función para retornar a la categoria del producto comprado
      window.location.href = ruta_previa;
    }
    // PRINT RECEIPT
    vm.printInfo = function () {
      var divContents = document.getElementById("myReceiptProduct").outerHTML;
      var a = window.open('', '', 'height=500, width=500');
      a.document.write('<html>');
      a.document.write('<body>');
      a.document.write(divContents);
      a.document.write('</body></html>');
      a.onafterprint = function (e) {
        a.close();
      };
      a.document.close();
      a.print();
    };

    // SEND RECEIPT AS SMS
    vm.sendSms = function (form) {

      // Trigger validation flag.
      vm.submittedSms = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.error('Check form errors');
        return false;

      } else {
        var receipt = vm.receipt;
        var phone = vm.phoneToSend;
        receipt.logID = vm.logID;
        ConfirmationFactory
          .sendConfirmationSms(receipt, phone)
          .then(function (response) {
            vm.submittedSms = false;

            if (response.Status === 200) {
              Notification.success('The Receipt has been sent as sms successfully!');
            } else {
              Notification.error('Sorry, an error has happened. Please, try again.');
            }
            void 0;
          }, function (response) {
            Notification.error(response.ErrorMessage ? response.ErrorMessage : 'Sorry, an error has happened. Please, try again.');
          });
      }
    };

    vm.onlyNumber = function (event) {
      if (event.keyCode <= 47 || event.keyCode >= 58) { return event.preventDefault(); }
    };

    // SEND RECEIPT AS EMAIL
    vm.sendEmail = function (form) {

      // Trigger validation flag.
      vm.submittedEmail = true;

      // If form is invalid, return and let AngularJS show validation errors.
      if (form.$invalid) {
        Notification.error('Check form errors');
        return false;

      } else {
        var receipt = vm.receipt;
        var email = vm.emailToSend;
        const ruta = window.location.origin;
        const completa = window.location.href;
        const ruta_2 = ruta + "/#/pos/category/";
        receipt.Route = completa.replace(ruta_2, "");
        ConfirmationFactory
          .sendConfirmationEmail(receipt, email)
          .then(function (response) {
            vm.submittedEmail = false;

            if (response.Status === 200) {
              Notification.success('The Receipt has been sent as email successfully!');
            } else {
              Notification.error('Sorry, an error has happened. Please, try again.');
            }
            void 0;
          }, function (response) {
            Notification.error(response.ErrorMessage ? response.ErrorMessage : 'Sorry, an error has happened. Please, try again.');
          });
      }
    };

  }
})();
