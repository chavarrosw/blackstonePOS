(function () {
  'use strict';

  angular.module('posClient')
    // might ngInject list all products by category
    .controller('IndexByCategoryCtrl', [
      '$scope',
      '$window',
      '$routeParams',
      'ProdsFactory',
      'SharedFunctions',
      '$location',
      'localStorageService',
      'AuthenticationFactory',
      function ($scope, $window, $routeParams, ProdsFactory, SharedFunctions, $location, localStorageService, AuthenticationFactory) {
        $scope.useMostPopular = true;
        $scope.isMostPopular = true;
        $scope.showAcronym = false;
        $scope.useAcronym = true;
        $scope.useConfig = ($routeParams.category === 'pinless') ?
          false :
          true;
        var category = $routeParams.category;
        var configParam = (category === 'longdistance' || category === 'international') ?
          'countries' :
          'carriers';
        $scope.configDisplay = (category === 'longdistance' || category === 'international') ?
          'country' :
          'carrier';
        $scope.configPath = 'category/' + category + '/' + configParam;
        $scope.type = $location
          .path()
          .split('/')
          .splice(1, 1)
          .toString();
        $scope.mostpopular = 'category/' + category;

        var userInfo = AuthenticationFactory.getUserInfo();
        $scope.viewsearch = (category === 'wireless') ?
          'carriers' :
          'countries';

        $scope.activeClass = function (page) {
          return page === $scope.letter ?
            ' active' :
            'cosa';
        };

        $scope.getProductInitialsByCategory = function () {
          ProdsFactory
            .getProductInitialsByCategory(category, userInfo)
            .then(function (data) {
              $scope.alpha = data;
              // console.log(data);
            }, function (error) {
              void 0;
            });
        };
        $scope.getAllProducts = function () {
          ProdsFactory
            .getAllProducts(category, userInfo)
            .then(function (data) {                     
              $scope.items = data;
              if ($scope.items.length == 1) {
                  $window.location.href = $scope.items[0].url;
              }
            }, function (error) {
              void 0;
            });
        };
        $scope.getProductInitialsByCategory();
        $scope.getAllProducts();
      }
    ]);
}());
