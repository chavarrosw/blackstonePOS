(function () {
  'use strict';

  angular
    .module('posClient')
    .run(runBlock);

  runBlock.$inject = [
    '$log',
    '$rootScope',
    '$location',
    '$window',
    'AuthenticationFactory',
    'localStorageService',
    'POSGlobalConfig'
  ];

  function runBlock($log, $rootScope, $location, $window, AuthenticationFactory, localStorageService, POSGlobalConfig) {
    var history = [];

    var d = localStorageService.get('xtime');

    if (!d || d === '') {
      localStorageService.clearAll();
      localStorageService.set('xtime', new Date());
    } else {
      var xtime = new Date(d);
      var elapsedTimeMin = (new Date() - xtime) / 60000;
      if (elapsedTimeMin > POSGlobalConfig.localStorageExpirationInMinutes) {
        localStorageService.clearAll();
        localStorageService.set('xtime', new Date());
      }
    }

    $rootScope
      .$on('$routeChangeSuccess', function () {
        redirectToPrimaryHostName($location);
        notifyGoogleTagManager($location, $window);
        checkRoute($location, AuthenticationFactory, history);
      });

    // $rootScope.$on('$destroy', function () {   routeChangeSuccess.$destroy(); });

    $rootScope.back = function () {
      var prevUrl = history.length > 1
        ? history.splice(-2)[0]
        : '/';
      $location.path(prevUrl);
    };

    $log.debug('runBlock end');
  }

  function redirectToPrimaryHostName() {}

  function notifyGoogleTagManager($location, $window) {
    var dataLayer = $window.dataLayer = $window.dataLayer || [];
    dataLayer.push({
      event: 'ngRouteChange',
      attributes: {
        route: $location.path()
      }
    });
  }

  function checkRoute($location, AuthenticationFactory, history) {
    if ($location.path() != "/metelelogin" && $location.path() != "/tnblogin" && !AuthenticationFactory.isLoggedIn()) {
      $location.path('/login');
    } else {
      history.push($location.path());
    }
  }

})();
