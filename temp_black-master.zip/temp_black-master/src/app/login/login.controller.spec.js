describe('LoginController', function () {

    var vm;
    var POSGlobalConfig;

    beforeEach(function () {
        angular
            .mock
            .module('posClient');
        angular
            .mock
            .inject(function (_$controller_, _POSGlobalConfig_) {
                POSGlobalConfig = _POSGlobalConfig_
                vm = _$controller_('LoginController');
            });
    });

    describe('when activate is executed', function () {
        it('vm.host should not be undefined', function () {
            chai
                .assert
                .isDefined(vm.host, 'vm.host has been set')
        })
    });

    describe('when buildViewModel is executed', function () {
        describe('and host is mobile.blackstonepos.com', function () {
            it('customer service number should be blackstone\'s', function () {
                vm.host = 'mobile.blackstonepos.com';
                vm.buildViewModel();
                chai
                    .assert
                    .equal(vm.customerServicePhone, POSGlobalConfig.blackstone.customerServicePhone);
            });
        });

        describe('and host is mobile.fcusa.us', function () {
            it('customer service number should be fullcarga\'s', function () {
                vm.host = 'mobile.fcusa.us';
                vm.buildViewModel();
                chai
                    .assert
                    .equal(vm.customerServicePhone, POSGlobalConfig.fullcarga.customerServicePhone);
            });
        });
    });

})