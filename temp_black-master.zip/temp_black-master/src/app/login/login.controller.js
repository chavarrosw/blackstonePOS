(function () {
  'use strict';

  angular
    .module('posClient')
    .controller('LoginController', LoginController);

  LoginController.$inject = [
    '$log',
    '$location',
    'AuthenticationFactory',
    'localStorageService',
    'Notification',
    'BsUiMessages',
    'POSGlobalConfig'
  ];

  function LoginController($log, $location, AuthenticationFactory, localStorageService, Notification, BsUiMessages, POSGlobalConfig) {
    var vm = this;
    vm.setHostname = setHostname;
    vm.buildViewModel = buildViewModel;

    vm.loginData = {
      username: '',
      password: ''
    };

    activate();

    function activate() {
      setHostname();
      buildViewModel();
    }

    function setHostname() {
      vm.host = $location.host();
    }

    function buildViewModel() {
      if (vm.host === 'mobile.fcusa.us') {
        vm.customerServicePhone = POSGlobalConfig.fullcarga.customerServicePhone;
        vm.logoUrl = POSGlobalConfig.fullcarga.logoUrl;
        vm.internationalTopUpImageUrl = POSGlobalConfig.fullcarga.internationalTopUpImageUrl;
        vm.wirelessImageUrl = POSGlobalConfig.fullcarga.wirelessImageUrl;
        vm.longDistanceImageUrl = POSGlobalConfig.fullcarga.longDistanceImageUrl;
        vm.pinlessImageUrl = POSGlobalConfig.fullcarga.pinlessImageUrl;
      } else {
        vm.customerServicePhone = POSGlobalConfig.blackstone.customerServicePhone;
        vm.logoUrl = POSGlobalConfig.blackstone.logoUrl;
        vm.internationalTopUpImageUrl = POSGlobalConfig.blackstone.internationalTopUpImageUrl;
        vm.wirelessImageUrl = POSGlobalConfig.blackstone.wirelessImageUrl;
        vm.longDistanceImageUrl = POSGlobalConfig.blackstone.longDistanceImageUrl;
        vm.pinlessImageUrl = POSGlobalConfig.blackstone.pinlessImageUrl;
      }
    }

    vm.submitLogin = function (loginForm) {
      if (loginForm.$valid) {
        vm.loginBtnIsDisable = true;
        AuthenticationFactory
          .login(vm.loginData.username, vm.loginData.password)
          .then(function (response) {
            if (response.Status == 200) {
              Notification.clearAll();
              localStorageService.set('userInfo', response.UserInfo);
              $location.path('/');
              //location.reload();
              vm.loginBtnIsDisable = false;
              AuthenticationFactory.selectATH(vm.loginData.username).then(
                function (res) {
                  if (res.data[0][0] != undefined) {
                    localStorage.setItem('ath', res.data[0][0].token);
                  }
                }
              ).catch( function (err) {
                console.log('Error con ath consulta');
              });
            } else {
              vm.loginData.password = '';

              loginForm.$setPristine();
              loginForm.$setUntouched();

              Notification.error({message: 'Invalid Credentials', delay: 2000});
              Notification.warning({
                message: 'If you have trouble to log in, please contact Customer Support at: ' + vm.customerServicePhone
              });
              vm.loginBtnIsDisable = false;
            }
          }, function (response) {
            vm.loginData.password = '';

            loginForm.$setPristine();
            loginForm.$setUntouched();

            $log.debug('Something went wrong');
            $log.info(response);
            if (response.data && response.data.ErrorMessage == BsUiMessages.unauthorizedLocation) {
              Notification.error({message: BsUiMessages.unauthorizedLogin, delay: 1000});
            } else {
              Notification.error({message: BsUiMessages.serverError.message, delay: 1000});
            }

            vm.loginBtnIsDisable = false;
          });
      }
    };
  }
})();
