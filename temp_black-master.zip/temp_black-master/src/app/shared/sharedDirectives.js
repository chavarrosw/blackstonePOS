(function () {
  'use strict';
  // module
  angular.module('posClient')
    
}());
