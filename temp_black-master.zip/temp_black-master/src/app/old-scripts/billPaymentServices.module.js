(function () {
    'use strict';
    // might ngInject
  
    /* services & factories */
    angular.module('billPaymentServices', [])
      // Return products collection
      .factory('BillPaymentFactory', ['$http', '$rootScope', 'API_URL', '$q', 'SharedFunctions', 'localStorageService', 'AuthenticationFactory',
        function ($http, $rootScope, API_URL, $q, SharedFunctions, localStorageService, AuthenticationFactory) {
          var arr;
  
          return {
  
            // get BILLERS by categories
            getBillersByCategory: function (category) {
  
              var userInfo = AuthenticationFactory.getUserInfo();
  
              var queryObj = {
                Username: userInfo.Username,
                Password: userInfo.Password,
                CategoryId: category
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'BillPayment/newGetBillersByCategory', queryObj)
                .then(
                  function (response) {
                    arr = response.data.Data;
                    // $rootScope.BillersByCategory = response.data.Data;
                    deferred.resolve(arr);
                  },
                  function (response) {
                    void 0;
                    deferred.reject(response);
                  }
                );
              return deferred.promise;
            },
            // get BILLERS by categories
            getBillersInitials: function (category) {
  
              var userInfo = AuthenticationFactory.getUserInfo();
  
              var queryObj = {
                Username: userInfo.Username,
                Password: userInfo.Password,
                CategoryId: category
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'BillPayment/newGetBillersInitials', queryObj)
                .then(
                  function (response) {
                    arr = response.data.Data;
                    // console.log(arr);
                    deferred.resolve(arr);
                  },
                  function (response) {
                    void 0;
                    deferred.reject(response);
                  }
                );
              return deferred.promise;
            },
            // get CATEGORIES
            getBillPaymentCategories: function () {
  
              var userInfo = AuthenticationFactory.getUserInfo();
  
              var queryObj = {
                Username: userInfo.Username,
                Password: userInfo.Password
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'BillPayment/newGetBillPaymentCategories', queryObj)
                .then(
                  function (response) {
                    arr = response.data.Data;
                    void 0;
                    // console.log(JSON.stringify(response.data));
                    deferred.resolve(arr);
                  },
                  function (response) {
                    void 0;
                    deferred.reject(response);
                  }
                );
              return deferred.promise;
            },
            // get Biller
            getMasterBiller: function (billerId) {
  
              var userInfo = AuthenticationFactory.getUserInfo();
  
              var queryObj = {
                MerchantId: userInfo.MerchantId,
                MerchantPassword: userInfo.MerchantPassword,
                CategoryId: '',
                BillerId: billerId
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'BillPayment/getMasterBiller', queryObj)
                .then(
                  function (response) {
                    arr = response.data;
                    // console.log(JSON.stringify(arr));
                    // console.log(arr);
                    deferred.resolve(arr);
                  },
                  function (response) {
                    void 0;
                    deferred.reject(response);
                  }
                );
              return deferred.promise;
            },
            // get biller PAYMENT OPTIONS
            getBillerPaymentOptions: function (biller) {
  
              var userInfo = AuthenticationFactory.getUserInfo();
  
              var queryObj = {
                Username: userInfo.Username,
                Password: userInfo.Password,
                BillerId: biller
              };
  
              // console.log(queryObj);
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'BillPayment/newGetBillerPaymentOptions', queryObj)
                .then(
                  function (response) {
                    arr = response.data;
                    // console.log(JSON.stringify(arr));
                    // console.log(arr);
                    deferred.resolve(arr);
                  },
                  function (response) {
                    void 0;
                    deferred.reject(response);
                  }
                );
              return deferred.promise;
            },
            // do Bill Payment NEXT STEP
            doBillPaymentNextStep: function (obj) {
  
              var userInfo = AuthenticationFactory.getUserInfo();
  
              var queryObj = obj;
              queryObj.MerchantId = userInfo.MerchantId;
              queryObj.MerchantPassword = userInfo.MerchantPassword;
              void 0;
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'BillPayment/DoBillPaymentNextStep', queryObj)
                .then(
                  function (response) {
                    arr = response.data;
                    // console.log(JSON.stringify(arr));
                    // console.log(arr);
                    deferred.resolve(arr);
                  },
                  function (response) {
                    void 0;
                    deferred.reject(response);
                  }
                );
              return deferred.promise;
            },
            // do Bill Payment NEXT STEP
            doBillPayment: function (obj) {
  
              var userInfo = AuthenticationFactory.getUserInfo();
  
              var queryObj = obj;
              queryObj.MerchantId = userInfo.MerchantId;
              queryObj.MerchantPassword = userInfo.MerchantPassword;
              //queryObj.SenderAddress = $scope.senderAddress.addressLineOne + "," + $scope.senderAddress.addressLineTwo + "," + $scope.senderAddress.addressCity + "," + $scope.senderAddress.addressState + "," + $scope.senderAddress.addressZipcode;
              // console.log(queryObj);
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'BillPayment/DoBillPayment', queryObj)
                .then(
                  function (response) {
                    arr = response.data;
                    // console.log(JSON.stringify(arr));
                    // console.log(arr);
                    deferred.resolve(arr);
                  },
                  function (response) {
                    void 0;
                    deferred.reject(response);
                  }
                );
              return deferred.promise;
            }
          };
        }
      ]);
  }());
  