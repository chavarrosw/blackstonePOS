(function () {
    'use strict';
  
    angular.module('posClient')
      // might ngInject
      .controller('PromosCtrl', ['$scope', '$routeParams', 'PromosFactory', 'Notification', 'BsUiMessages',
        function ($scope, $routeParams, PromosFactory) {
          $scope.getPromotions = function () {
            PromosFactory.getPromotions().then(
              function (data) {
                $scope.items = data;
                // console.log(data);
              },
              function (error) {
                Notification.error(BsUiMessages.serverError.message)
                $log.error(error);
              }
            );
          };
          $scope.getPromotions();
        }
      ]);
  }());