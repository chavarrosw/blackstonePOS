(function () {
    'use strict';

    angular.module('posClient')
    // might ngInject list all products by carrier
        .controller('IndexByCarriersCtrl', [
        '$scope',
        '$routeParams',
        'ProdsFactory',
        'localStorageService',
        'AuthenticationFactory',
        'SharedFunctions',
        '$location',
        function ($scope, $routeParams, ProdsFactory, localStorageService, AuthenticationFactory, SharedFunctions, $location) {
            $scope.letter = '';
            $scope.useMostPopular = true;
            $scope.isMostPopular = false;
            $scope.useConfig = false;
            $scope.useAcronym = true;
            $scope.showAcronym = true;
            $scope.viewsearch = 'carriers';
            $scope.selectdisplay = 'carrier';
            $scope.type = $location
                .path()
                .split('/')
                .splice(1, 1)
                .toString();
            var category = $routeParams.category;
            $scope.mostpopular = 'category/' + category;

            var countryCode = 'USA';
            var userInfo = AuthenticationFactory.getUserInfo();
            $scope.activeClass = function (page) {
                return page === $scope.letter
                    ? ' active'
                    : 'cosa';
            };
            $scope.getWirelessCarrierInitials = function () {
                ProdsFactory
                    .getWirelessCarrierInitials(countryCode, userInfo)
                    .then(function (data) {
                        $scope.alpha = data;
                    }, function (error) {
                        void 0;
                    });
            };
            $scope.getWirelessCarriers = function () {
                ProdsFactory
                    .getWirelessCarriers(countryCode, userInfo)
                    .then(function (data) {
                        $scope.items = data;
                    }, function (error) {
                        void 0;
                    });
            };
            $scope.getWirelessCarrierInitials();
            $scope.getWirelessCarriers();
        }
    ]);
}());