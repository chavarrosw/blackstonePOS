(function () {
  'use strict';

  // might ngInject
  // products services (internationals, wireless, long distance, )
  angular.module('prodsServices', [])
    // Return products collection
    // .factory('ProdsFactory', ['$http', '$rootScope', 'API_URL', '$q', 'SharedFunctions', 'localStorageService',
    .factory('ProdsFactory', ['$http', '$rootScope', 'API_URL', '$q', 'SharedFunctions', 'URL_BACKEND',
      // function ($http, $rootScope, API_URL, $q, SharedFunctions, localStorageService) {
      function ($http, $rootScope, API_URL, $q, SharedFunctions, URL_BACKEND) {
        var arr;
        var product;
        var products;
        var countries;

        return {
          // get PRODUCTS by category & country
          getProductsByCategoryByCountry: function (category, countryCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category,
              CountryCode: countryCode
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetProductsByCategoryByCountry', queryObj)
              .then(
                function (response) {
                  products = response.data.Data;
                  // console.log(JSON.stringify(products));
                  deferred.resolve(SharedFunctions.mapProductsURL(products));
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get PRODUCT
          getProduct: function (productMainCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              ProductMainCode: productMainCode
            };
            // console.log(queryObj);
            var deferred = $q.defer();


            $http.post(API_URL + 'Products/GetProduct', queryObj)
              .then(
                function (response) {
                  product = response.data.Data;
                  // console.log(response);
                  deferred.resolve(product);
                },
                function (response) {
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get PRODUCT TERMS
          getProductTerms: function (productMainCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              ProductMainCode: productMainCode
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetProduct', queryObj)
              .then(
                function (response) {
                  product = response.data.Data;
                  // console.log(response);
                  deferred.resolve(product);
                },
                function (response) {
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get product RATES
          getProductRates: function (productMainCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              ProductMainCode: productMainCode
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetProductRates', queryObj)
              .then(
                function (response) {
                  var rates = response.data.Data;
                  // console.log(rates);
                  deferred.resolve(rates);
                },
                function (response) {
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get product ACCESS NUMBERS
          getProductAccessNumbers: function (productMainCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              ProductMainCode: productMainCode
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetProductAccessNumbers', queryObj)
              .then(
                function (response) {
                  var accessnumbers = response.data.Data;
                  // console.log(accessPhones);
                  deferred.resolve(accessnumbers);
                },
                function (response) {
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get all PRODUCTS by category
          getAllProducts: function (category, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category
            };
            // console.log(queryObj);
            var deferred = $q.defer();
            // Función para consultar una vez por día
            const infoSaved = JSON.parse(localStorage.getItem('Products/GetAllProducts/' + category));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_' + category), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }
            $http.post(API_URL + 'Products/GetAllProducts', queryObj)
              .then(
                function (response) {
                  products = response.data.Data;
                  localStorage.setItem('Products/GetAllProducts/' + category, JSON.stringify(SharedFunctions.mapProductsURL(products)));
                  localStorage.setItem('day_' + category, new Date().getDate() + '');
                  deferred.resolve(SharedFunctions.mapProductsURL(products));
                },
                function (response) {
                  deferred.reject(response);
                  void 0;
                }
              );
            return deferred.promise;
          },
          // get all PRODUCTS of Grouper
          getAllProductsOfGrouper: function (grouperId, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              GroupId: grouperId
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'products/getGrouperProducts', queryObj)
              .then(
                function (response) {
                  products = response.data.Data;
                  // console.log(products);                    
                  deferred.resolve(SharedFunctions.mapProductsURL(products));
                },
                function (response) {
                  deferred.reject(response);
                  void 0;
                }
              );
            return deferred.promise;
          },
          // get PRODUCTS INITIALS by category
          getProductInitialsByCategory: function (category, user) {

            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            // Función para consultar una vez por día
            const infoSaved = JSON.parse(localStorage.getItem('Products/GetProductInitialsByCategory/' + category));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_' + category), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }

            $http.post(API_URL + 'Products/GetProductInitialsByCategory', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  // console.log(arr);
                  localStorage.setItem('Products/GetProductInitialsByCategory/' + category, JSON.stringify(arr));
                  localStorage.setItem('day_' + category, new Date().getDate() + '');
                  deferred.resolve(arr);
                },
                function (response) {
                  deferred.reject(response);
                  void 0;
                }
              );
            return deferred.promise;
          },
          // get PRODUCTS INITIALS by category
          getProductInitialsByCategoryByCountry: function (category, country, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category,
              CountryCode: country
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetProductInitialsByCategoryByCountry', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  // console.log(arr);
                  deferred.resolve(arr);
                },
                function (response) {
                  deferred.reject(response);
                  void 0;
                }
              );
            return deferred.promise;
          },
          // get CARRIERS by category
          getCarriers: function (category, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetCarriers', queryObj)
              .then(function (response) {
                arr = response.data.Data;
                void 0;
                deferred.resolve(arr);
              }, function (response) {
                void 0;
                deferred.reject(response);
              });
            return deferred.promise;
          },
          // get COUNTRIES by category
          getCountriesByCategory: function (category, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category
            };
            // console.log(queryObj);
            var deferred = $q.defer();
            // Función para consultar una vez por día
            const infoSaved = JSON.parse(localStorage.getItem('Products/GetCountriesByCategory/' + category));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_' + category), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }
            $http.post(API_URL + 'Products/GetCountriesByCategory', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  localStorage.setItem('Products/GetCountriesByCategory/' + category, JSON.stringify(arr));
                  localStorage.setItem('day_' + category, new Date().getDate() + '');
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get COUNTRIES INITIALS by category
          getCountryInitialsByCategory: function (category, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category
            };
            // console.log(queryObj);
            var deferred = $q.defer();
            // Función para consultar una vez por día
            const infoSaved = JSON.parse(localStorage.getItem('Products/GetCountryInitialsByCategory/' + category));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_' + category), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }
            $http.post(API_URL + 'Products/GetCountryInitialsByCategory', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  localStorage.setItem('Products/GetCountryInitialsByCategory/' + category, JSON.stringify(arr));
                  localStorage.setItem('day_' + category, new Date().getDate() + '');
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get RATES by country
          getRates: function (maincode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              ProductMainCode: maincode
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetProductRates', queryObj)
              .then(
                function (response) {
                  arr = response.data;
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );

            return deferred.promise;
          },
          // get LONGDISTANCE countries
          getLongDistanceCountries: function (user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetLongDistanceCountries', queryObj)
              .then(function (response) {
                countries = response.data.Data;
                // console.log(JSON.stringify(countries));
                deferred.resolve(countries);
              }, function (response) {
                deferred.reject(response);
              });
            return deferred.promise;
          },
          // get LONGDISTANCE products by country
          getLongDistanceProductsByCountry: function (countryName, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              CountryName: countryName
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetLongDistanceProductsByCountry', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  // console.log(arr);
                  deferred.resolve(arr);
                },
                function (response) {
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // get LONGDISTANCE country details
          getCountryDetails: function (category, countryCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              Category: category,
              CountryCode: countryCode
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetCountryDetailsByCategory', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  // console.log(arr);
                  deferred.resolve(arr);
                },
                function (response) {
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // GET WIRELESS CARRIERS
          getWirelessCarriers: function (countryCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              CountryCode: countryCode
            };
            // console.log(queryObj);
            var deferred = $q.defer();
            // Función para consultar una vez por día
            const infoSaved = JSON.parse(localStorage.getItem('Products/GetWirelessCarriers/' + countryCode));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_' + countryCode), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }

            $http.post(API_URL + 'Products/GetWirelessCarriers', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  localStorage.setItem('Products/GetWirelessCarriers/' + countryCode, JSON.stringify(arr));
                  localStorage.setItem('day_' + countryCode, new Date().getDate() + '');
                  deferred.resolve(arr);
                  // console.log(arr);
                },
                function (response) {
                  void 0;
                  deferred.resolve(response);
                }
              );
            return deferred.promise;
          },
          // GET WIRELESS PRODUCTS BY CARRIER
          getWirelessProductsByCarrier: function (carrierId, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              CarrierId: carrierId
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetWirelessProductsByCarrier', queryObj)
              .then(function (response) {
                arr = response.data.Data;

                deferred.resolve(SharedFunctions.mapProductsURL(arr));
              }, function (response) {
                void 0;
                deferred.reject(response);
              });
            return deferred.promise;
          },
          // GET WIRELESS CARRIER DETAILS
          getWirelessCarrierDetails: function (carrierId, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              CarrierId: carrierId
            };
            // console.log(queryObj);
            var deferred = $q.defer();

            $http.post(API_URL + 'Products/GetWirelessCarrierDetails', queryObj)
              .then(function (response) {
                arr = response.data.Data;
                deferred.resolve(arr);
              }, function (response) {
                void 0;
                deferred.reject(response);
              });
            return deferred.promise;
          },
          // GET WIRELESS CARRIER INITIALS
          getWirelessCarrierInitials: function (countryCode, user) {
            var queryObj = {
              MerchantId: user.MerchantId,
              MerchantPassword: user.MerchantPassword,
              CountryCode: countryCode
            };

            // console.log(queryObj);
            var deferred = $q.defer();
            // Función para consultar una vez por día
            const infoSaved = JSON.parse(localStorage.getItem('products/GetWirelessCarrierInitials/' + countryCode));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_' + countryCode), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }
            $http.post(API_URL + 'products/GetWirelessCarrierInitials', queryObj)
              .then(
                function (response) {
                  arr = response.data.Data;
                  void 0;

                  localStorage.setItem('products/GetWirelessCarrierInitials/' + countryCode, JSON.stringify(arr));
                  localStorage.setItem('day_' + countryCode, new Date().getDate() + '');
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
          // DO BLACKSTONE POS OPERATION
          doBlackstonePosOperation: function (order, category) {
            void 0;
            var deferred = $q.defer();

            // Con mucho cuidado se hace una modificación a este llamado
            // si viene de la categoría de otherprepaids se manda al servidor
            var URL_TOTAL = API_URL + 'Products/DoBlackstonePosOperation';
            if (category === 'prepaidOther' || category === 'prepaidOthers') {
              URL_TOTAL = URL_BACKEND + '/api/paymentValidation/';
              order.MerchantPassword = CryptoJS.SHA512(order.MerchantPassword).toString();
            }

            $http.post(URL_TOTAL, order)
              .then(
                function (response) {
                  var brokerResponse = response.data;
                  // console.log(brokerResponse);
                  deferred.resolve(brokerResponse);
                },
                function (error) {
                  void 0;
                  deferred.reject(error);
                }
              );
            return deferred.promise;
          },
          // POS MAIN PRODUCTS
          getPosMainProducts: function (user, pass) {

            user = {
              MerchantId: user,
              MerchantPassword: pass
            };
            var deferred = $q.defer();
            const infoSaved = JSON.parse(localStorage.getItem('mymainproducts'));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_mainproducts'), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }

            $http.post(API_URL + 'Products/GetPosMainProducts', user)
              .then(
                function (response) {

                  var mainProductsResponse = response.data.Data;

                  localStorage.setItem('mymainproducts', JSON.stringify(mainProductsResponse));
                  localStorage.setItem('day_mainproducts', new Date().getDate() + '');
                  deferred.resolve(mainProductsResponse);
                },
                function (error) {
                  void 0;
                  deferred.reject(error);
                }
              );
            return deferred.promise;
          },

          getPromotions: function () {

            var deferred = $q.defer();
            const infoSaved = JSON.parse(localStorage.getItem('mypromotions'));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('day_promotion'), 10);
            // Si existe se retorna el valor almacenado
            if (infoSaved && registered_day === new Date().getDate()) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }
            $http.get(URL_BACKEND + '/api/ads')
              .then(
                function (response) {

                  var mainProductsResponse = response.data.data;
                  localStorage.setItem('mypromotions', JSON.stringify(mainProductsResponse));
                  localStorage.setItem('day_promotion', new Date().getDate() + '');
                  deferred.resolve(mainProductsResponse);
                },
                function (error) {
                  void 0;
                  deferred.reject(error);
                }
              );
            return deferred.promise;
          },
          getMostSoldProducts: function (user, pass) {
            // Vamos a consultar los mas vendidos por las categorias mencionadas
            // se almacena la informacion por el tiempo de 6 horas
            user = {
              MerchantId: user,
              MerchantPassword: pass
            };
            var deferred = $q.defer();
            const infoSaved = JSON.parse(localStorage.getItem('topsold'));
            // Fecha de última actualización de los datos locales
            const registered_day = parseInt(localStorage.getItem('hour_topsold'), 10);
            // Si existe se retorna el valor almacenado
            const my_date = new Date();
            const valor = (my_date.getHours() + my_date.getMonth() + my_date.getFullYear());
            if (infoSaved && registered_day > valor) {
              deferred.resolve(infoSaved);
              return deferred.promise;
            }
            var requests = [];
            requests.push($http.post(API_URL + 'products/getMostSoldProducts', {
              "MerchantId": user,
              "MerchantPassword": pass,
              "Category": "international",
              "Amount": "2"
            }));
            requests.push($http.post(API_URL + 'products/getMostSoldProducts', {
              "MerchantId": user,
              "MerchantPassword": pass,
              "Category": "pinless",
              "Amount": "2"
            }));
            requests.push($http.post(API_URL + 'products/getMostSoldProducts', {
              "MerchantId": user,
              "MerchantPassword": pass,
              "Category": "longdistance",
              "Amount": "2"
            }));
            requests.push($http.post(API_URL + 'products/getMostSoldProducts', {
              "MerchantId": user,
              "MerchantPassword": pass,
              "Category": "wireless",
              "Amount": "2"
            }));
            $q.all(requests).then(function (responses) {
              var values = [];
              for (var x in responses) {
                for (var y in responses[x].data.Data) {
                  responses[x].data.Data[y].url = "#/pos/category/" + responses[x].data.Data[y].MainCategory + "/product/" + responses[x].data.Data[y].Code; 
                }
                values = values.concat(responses[x].data.Data);
              }
              localStorage.setItem('topsold', JSON.stringify(values));
              // Se suman seis horas, es decir es valido por 6 horas
              localStorage.setItem('hour_topsold', (valor + 6) + '');
              deferred.resolve(values);
            });
            return deferred.promise;
          },
          logTransaction: function (merchant, category, code, name, merchantName, extra, answer) {
            var queryObj = {
              merchantID: merchant,
              category: category,
              productCode: code,
              productName: name,
              merchantName: merchantName,
              logData: extra,
              logResponse: answer
            };
            // console.log(queryObj);
            var deferred = $q.defer();


            $http.post(URL_BACKEND + '/api/saveLogTransaction', queryObj)
              .then(
                function (response) {
                  product = response.data;
                  deferred.resolve(product);
                },
                function (response) {
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          },
        };
      }
    ]);
}());
