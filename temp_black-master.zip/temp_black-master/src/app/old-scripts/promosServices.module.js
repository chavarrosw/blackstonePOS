(function () {
    'use strict';
    angular.module('promosServices', [])
        // might ngInject
        .factory('PromosFactory', [
            '$http',
            '$rootScope',
            'API_URL',
            '$q',
            'SharedFunctions',
            'localStorageService',
            'AuthenticationFactory',
            function ($http, $rootScope, API_URL, $q, SharedFunctions, localStorageService, AuthenticationFactory) {
                var userInfo = AuthenticationFactory.getUserInfo();
                var merchant = {
                    MerchantId: userInfo.MerchantId,
                    MerchantPassword: userInfo.MerchantPassword
                };

                var arr = [];
                // console.log(merchant);

                return {
                    getPromotions: function () {

                        var deferred = $q.defer();
                        // Función para consultar una vez por día
                        const infoSaved = JSON.parse(localStorage.getItem('Promotions/GetAllPromotions'));
                        // Fecha de última actualización de los datos locales
                        const registered_day = parseInt(localStorage.getItem('day'), 10);
                        // Si existe se retorna el valor almacenado
                        if (infoSaved && registered_day === new Date().getDay()) {
                            deferred.resolve(infoSaved);
                            return deferred.promise;
                        }
                        $http
                            .post(API_URL + 'Promotions/GetAllPromotions', merchant)
                            .then(function (response) {
                                arr = response.data.Data;
                                // console.log(arr);
                                localStorage.setItem('Promotions/GetAllPromotions', JSON.stringify(arr));
                                localStorage.setItem('day', new Date().getDay() + '');
                                deferred.resolve(arr);
                            }, function (error) {
                                // console.log(error);
                                deferred.reject(error);
                            });
                        return deferred.promise;
                    }
                };
            }
        ]);
}());
