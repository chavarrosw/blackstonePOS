(function () {
    'use strict';

    angular.module('posClient')
    // might ngInject list all products by category
        .controller('IndexCountriesByCategoryCtrl', [
        '$scope',
        '$routeParams',
        'ProdsFactory',
        'localStorageService',
        'AuthenticationFactory',
        'SharedFunctions',
        '$location',
        function ($scope, $routeParams, ProdsFactory, localStorageService, AuthenticationFactory, SharedFunctions, $location) {

            var category = $routeParams.category;

            $scope.useMostPopular = true;
            $scope.isMostPopular = false;
            $scope.useAcronym = true;
            $scope.showAcronym = true;
            $scope.useConfig = false;
            $scope.type = $location
                .path()
                .split('/')
                .splice(1, 1)
                .toString();
            $scope.category = category;
            $scope.mostpopular = 'category/' + category;

            var userInfo = AuthenticationFactory.getUserInfo();
            $scope.activeClass = function (page) {
                return page === $scope.letter
                    ? ' active'
                    : 'cosa';
            };
            $scope.getCountryInitialsByCategory = function () {
                ProdsFactory
                    .getCountryInitialsByCategory(category, userInfo)
                    .then(function (data) {
                        $scope.alpha = data;
                        // console.log(data);
                    }, function (error) {
                        void 0;
                    });
            };
            $scope.getCountriesByCategory = function () {
                ProdsFactory
                    .getCountriesByCategory(category, userInfo)
                    .then(function (data) {
                        $scope.items = data;
                        // console.log(data);
                    }, function (error) {
                        void 0;
                    });
            };
            $scope.getCountryInitialsByCategory();
            $scope.getCountriesByCategory();
        }
    ]);
}());