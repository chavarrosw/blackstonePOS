(function () {
    'use strict';

    angular.module('posClient')
    // might ngInject list all products by category
        .controller('IndexByGroupCtrl', [
        '$rootScope',
        '$scope',
        'ProdsFactory',
        '$routeParams',
        '$window',
        'API_URL',
        '$http',
        'localStorageService',
        'AuthenticationFactory',
        function ($rootScope, $scope, ProdsFactory, $routeParams, $window, API_URL, $http, localStorageService, AuthenticationFactory) {
            $scope.title = "Grouper View";
            $scope.items = false;
            $scope.category = $routeParams.category;
            $scope.groupId = $routeParams.groupId;

            activate();

            function activate() {
                var userInfo = AuthenticationFactory.getUserInfo();

                // $http
                //     .post(API_URL + 'products/getGrouperProducts', {
                //         MerchantId: userInfo.MerchantId,
                //         MerchantPassword: userInfo.MerchantPassword,
                //         GroupId: $routeParams.groupId
                //     })
                //     .then(function (response) {
                //         $scope.items = SharedFunctions.mapProductsURL(response.data.Data);
                //         if ($scope.items.length == 1) {
                //             //var url = '#/pos/category/' + $scope.category + '/product/' + $scope.items[0].Code;
                //             $window.location.href = $scope.items[0].url;

                //         }
                //     })
                ProdsFactory
                .getAllProductsOfGrouper($scope.groupId, userInfo)
                .then(function (data) {                     
                  $scope.items = data;
                  if ($scope.items.length == 1) {
                      $window.location.href = $scope.items[0].url;
                  }
                }, function (error) {
                  void 0;
                });
            }
        }
    ]);
}());