(function () {
    'use strict';
    /* MODAL INSTANCE */
    angular
        .module('posClient')
        .controller('ShowTermsCtrl', [
            '$scope',
            '$routeParams',
            'ProdsFactory',
            'Notification',
            'localStorageService',
            'AuthenticationFactory',
            function ($scope, $routeParams, ProdsFactory, Notification, localStorageService, AuthenticationFactory) {
                // get productMainCode by $routeParams
                var productMainCode = $routeParams.id;

                void 0;
                var userInfo = AuthenticationFactory.getUserInfo();
                // get product info
                $scope.getProductTerms = function () {
                    ProdsFactory
                        .getProductTerms(productMainCode, userInfo)
                        .then(function (data) {
                            $scope.item = data;
                            void 0;
                        }, function (error) {
                            void 0;
                        });
                };
                $scope.getProductTerms();

                // PRINT RECEIPT
                $scope.printInfo = function () {
                    window.print();
                };

            }
        ])
        .filter('range', function () {
            return function (val, range) {
                range = parseInt(range);
                for (var i = 0; i < range; i++) 
                    val.push(i);
                return val;
            };
        });
}());
