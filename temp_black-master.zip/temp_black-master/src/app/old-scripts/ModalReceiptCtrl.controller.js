(function () {
    'use strict';
    angular.module('posClient')
      .controller('ModalReceiptCtrl', ['$scope', '$uibModalInstance', 'receipt', 'item', '$location', 'localStorageService', 'ProdsFactory', 'Notification', 'ConfirmationFactory', 
      function ($scope, $modalInstance, receipt, item, $location, localStorageService, ProdsFactory, Notification, ConfirmationFactory) {
        $scope.showReceipt = true;
        $scope.receipt = receipt;
        $scope.item = item;
  
  
        $scope.sendSms = function (form) {
  
          // Trigger validation flag.
          $scope.submittedSms = true;
  
          // If form is invalid, return and let AngularJS show validation errors.
          if (form.$invalid) {
            Notification.error('Check form errors');
            return false;
          } else {
            var phone = $scope.phoneToSend;
  
            ConfirmationFactory.sendConfirmationSms(receipt, phone).then(
              function (response) {
                $scope.submittedSms = false;
  
                if (response.Status === 200) {
                  Notification.success('The Receipt has been sent as sms successfully!');
  
                } else {
                  Notification.error('Sorry, an error has happened. Please, try again.');
                }
                void 0;
              },
              function (response) {
                Notification.error(response.ErrorMessage);
              }
            );
          }
        };
  
        // SEND RECEIPT AS EMAIL
        $scope.sendEmail = function (form) {
  
          // Trigger validation flag.
          $scope.submittedEmail = true;
  
          // If form is invalid, return and let AngularJS show validation errors.
          if (form.$invalid) {
            Notification.error('Check form errors');
            return false;
  
          } else {
            var email = $scope.emailToSend;
  
            ConfirmationFactory.sendConfirmationEmail(receipt, email).then(
              function (response) {
                $scope.submittedEmail = false;
  
                if (response.Status === 200) {
                  Notification.success('The Receipt has been sent as email successfully!');
                } else {
                  Notification.error('Sorry, an error has happened. Please, try again.');
                }
                void 0;
              },
              function (response) {
                Notification.error(response.ErrorMessage);
              }
            );
          }
        };
  
        $scope.close = function () {
          $modalInstance.close();
        };
      }]);
  }());