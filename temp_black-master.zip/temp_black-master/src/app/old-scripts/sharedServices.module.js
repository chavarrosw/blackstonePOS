(function () {
  "use strict";
  angular
    .module("sharedServices", [])
    // Service for interchange data between views and controllers via service.
    .factory("ItemFactory", [
      function () {
        var objSelected = [];

        return {
          /* Methods to pass an Object from one view to another via service */
          selectObject: function (newObj) {
            objSelected = newObj;
          },

          // RETURN PRODUC (get last object stored in select)
          returnObject: function () {
            return objSelected;
          }
        };
      }
    ])
    // Service to send confirmation messages via SMS or email.
    .factory("ConfirmationFactory", [
      "$http",
      "$rootScope",
      "API_URL",
      "$q",
      "localStorageService",
      "AuthenticationFactory",
      'URL_BACKEND',
      function (
        $http,
        $rootScope,
        API_URL,
        $q,
        localStorageService,
        AuthenticationFactory,
        URL_BACKEND 
      ) {
        var arr = [];
        var userInfo = AuthenticationFactory.getUserInfo();
        var merchant = {
          MerchantId: userInfo.MerchantId,
          MerchantPassword: userInfo.MerchantPassword
        };


        return {
          /* Methods to pass an Object from one view to another via service */
          sendConfirmationSms: function (receipt, phone) {
            var queryObj = {
              PhoneNumber: phone,
              URL: URL_BACKEND,
              ID: receipt.logID ? receipt.logID : -1,
              Receipt: {
                ProductName: receipt.ProductName,
                ProductCountry: receipt.ProductCountry,
                CarrierName: receipt.CarrierName,
                ProductInstructions: receipt.ProductInstructions,
                PhoneNumber: receipt.PhoneNumber,
                PinNumber: receipt.PinNumber,
                ControlNumber: receipt.ControlNumber,
                OrderNumber: receipt.OrderNumber,
                TransactionId: receipt.TransactionId,
                UpdatedBalance: receipt.UpdatedBalance,
                MerchantName: receipt.MerchantName,
                MerchantPhoneNumber: receipt.MerchantPhoneNumber,
                CashierName: receipt.CashierName,
                MerchantAddress: receipt.MerchantAddress,
                OrderDate: receipt.OrderDate,
                Amount: receipt.Amount,
                Fee: receipt.Fee,
                Tax: receipt.Tax,
                Total: receipt.Total,
                Route: window.location.href
              },
              MerchantId: merchant.MerchantId,
              //MerchantPassword: merchant.MerchantPassword
            };
            void 0;

            var deferred = $q.defer();

            $http.post(URL_BACKEND + "/api/sendSMS", queryObj).then(
              function (response) {
                arr = response.data;
                // console.log(arr);
                deferred.resolve(arr);
              },
              function (response) {
                void 0;
                deferred.reject(response);
              }
            );
            return deferred.promise;
          },
          //
          sendConfirmationEmail: function (receipt, email) {
            var queryObj = {
              Email: email,
              Receipt: {
                ProductName: receipt.ProductName,
                ProductCountry: receipt.ProductCountry,
                CarrierName: receipt.CarrierName,
                ProductInstructions: receipt.ProductInstructions,
                PhoneNumber: receipt.PhoneNumber,
                PinNumber: receipt.PinNumber,
                ControlNumber: receipt.ControlNumber,
                OrderNumber: receipt.OrderNumber,
                TransactionId: receipt.TransactionId,
                UpdatedBalance: receipt.UpdatedBalance,
                MerchantName: receipt.MerchantName,
                MerchantPhoneNumber: receipt.MerchantPhoneNumber,
                CashierName: receipt.CashierName,
                MerchantAddress: receipt.MerchantAddress,
                OrderDate: receipt.OrderDate,
                Amount: receipt.Amount,
                Fee: receipt.Fee,
                Tax: receipt.Tax,
                Total: receipt.Total,
                Route: receipt.Route ? receipt.Route : '/category/general'
              },
              MerchantId: merchant.MerchantId,
              //MerchantPassword: merchant.MerchantPassword
            };
            // console.log(queryObj);

            var deferred = $q.defer();

            $http
              .post(URL_BACKEND + "/api/sendEmail", queryObj)
              .then(
                function (response) {
                  arr = response.data;
                  // console.log(arr);
                  deferred.resolve(arr);
                },
                function (response) {
                  void 0;
                  deferred.reject(response);
                }
              );
            return deferred.promise;
          }
        };
      }
    ]);
})();
