(function () {
    'use strict';
    angular.module('adminServices', [])
      .factory('MerchantFactory', ['$http', '$rootScope', 'API_URL', '$q',
        function ($http, $rootScope, API_URL, $q) {
          // Return merchant account details
          var merchant;
  
          return {
            // get merchant sales details
            getSalesSummary: function (MerchantId, MerchantPassword, Role) {
              var deferred = $q.defer();
  
              merchant = {
                MerchantId: MerchantId,
                MerchantPassword: MerchantPassword,
                Role: Role
              };
  
              $http.post(API_URL + 'Merchant/newGetSalesSummary', merchant)
                .then(
                  function (response) {
                    var merchantSales = {
                      todaySales: null,
                      creditLimit: null,
                      dailyCreditLimit: null,
                      currentBalance: null,
                      available: null
                    };
  
                    if (response.data.Status === 200) {
  
                      if (merchant.Role == 2) {
                        merchantSales = {
                          todaySales: response.data.Data.TodaySales,
                          creditLimit: response.data.Data.CreditLimit,
                          dailyCreditLimit: response.data.Data.DailyLimit,
                          currentBalance: response.data.Data.CurrentBalance,
                          available: response.data.Data.Available
                        };
                      } else {
                        merchantSales = {
                          todaySales: response.data.Data.TodaySales,
                          available: response.data.Data.Available
                        };
                      }
  
                    } else {
                      void 0;
                    }
                    deferred.resolve(merchantSales);
  
                  },
                  function (response) {
                    deferred.reject(response);
                    void 0;
                  }
                );
  
              return deferred.promise;
            },
            // get merchant balance details
            getBalanceDetails: function (MerchantId, MerchantPassword, Role) {
              var deferred = $q.defer();
  
              merchant = {
                'MerchantId': MerchantId,
                'MerchantPassword': MerchantPassword,
                'Role': Role
              };
  
              $http.post(API_URL + 'Merchant/GetBalanceDetails', merchant)
                .then(
                  function (response) {
  
                    if (response.data.Status === 200) {
                      var merchantBalance = {
                        current: response.data.Data.Current,
                        nextAch: response.data.Data.NextAch,
                        nextAchDate: response.data.Data.NextAchDate
                      };
                    } else {
                      void 0;
                    }
  
                    deferred.resolve(merchantBalance);
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
                  });
  
              return deferred.promise;
            }
          };
        }
      ])
      .factory('AchPaymentFactory', ['$http', '$rootScope', 'API_URL', '$q', 'localStorageService', 'AuthenticationFactory',
        function ($http, $rootScope, API_URL, $q, localStorageService, AuthenticationFactory) {
  
          var merchant;
          var userInfo = AuthenticationFactory.getUserInfo();
  
          if (userInfo != null) {
            merchant = {
              MerchantId: userInfo.MerchantId,
              MerchantPassword: userInfo.password
            };
          }
  
          return {
            // get merchant balance details
            getSavedPayments: function () {
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/GetSavedAchPayment', merchant)
                .then(
                  function (response) {
  
                    var results = response.data.Data;
                    deferred.resolve(results);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
  
                  });
              return deferred.promise;
            }
          };
        }
      ])
      // Get cachiers of merchant.
      .factory('CashierFactory', ['$http', '$rootScope', 'API_URL', '$q', 'localStorageService', 'AuthenticationFactory',
        function ($http, $rootScope, API_URL, $q, localStorageService, AuthenticationFactory) {
  
          // get user info from localStorageService
          var userInfo = AuthenticationFactory.getUserInfo();
  
          return {
            // get merchant sales details
            getCashiers: function (MerchantId, MerchantPassword) {
              var deferred = $q.defer();
              $http.post(API_URL + 'admin/getallcashiers', {
                  MerchantId: MerchantId,
                  MerchantPassword: MerchantPassword
                })
                .then(
                  function (response) {
  
                    var cashiers = response.data.Data;
                    deferred.resolve(cashiers);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
  
                  }
                );
              return deferred.promise;
            },
            // save CASHIER
            saveCashier: function (MerchantId, merchantPassword, cashierName, cashierPassword, userName) {
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/addcashier', {
                  MerchantId: MerchantId,
                  MerchantPassword: merchantPassword,
                  Name: cashierName,
                  Password: cashierPassword,
                  UserName: userName
                })
                .then(
                  function (response) {
  
                    var result = response.data;
                    // console.log(result);
                    deferred.resolve(result);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    // console.log(response);
                    void 0;
  
                  });
              return deferred.promise;
            },
            // delete CASHIER
            deleteCashier: function (merchantId, merchantPassword, cashierId) {
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/deletecashier', {
                  MerchantId: merchantId,
                  MerchantPassword: merchantPassword,
                  Id: cashierId
                })
                .then(
                  function (response) {
  
                    var result = response.data;
                    void 0;
                    deferred.resolve(result);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
  
                  });
              return deferred.promise;
            },
            // edit CASHIER
            editCashier: function (MerchantId, merchantPassword, cashierId, cashierName, cashierPassword, userName) {
              var deferred = $q.defer();
              // console.log(cashierPassword);
  
              $http.post(API_URL + 'admin/updatecashier', {
                  MerchantId: MerchantId,
                  MerchantPassword: merchantPassword,
                  Id: cashierId,
                  Name: cashierName,
                  password: cashierPassword,
                  UserName: userName
                })
                .then(
                  function (response) {
  
                    var result = response.data;
                    // console.log(response.data);
                    deferred.resolve(result);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
  
                  });
              return deferred.promise;
            }
          };
        }
      ])
      // Get account settings for a merchant.
      .factory('SettingsFactory', ['$http', '$rootScope', 'API_URL', '$q', 'localStorageService', 'AuthenticationFactory', 'SharedFunctions',
        function ($http, $rootScope, API_URL, $q, localStorageService, AuthenticationFactory, SharedFunctions) {
          var merchant;
  
          // get user info from localStorageService
          var userInfo = AuthenticationFactory.getUserInfo();
  
          if (userInfo != null || SharedFunctions.isobject(userInfo)) {
            merchant = {
              MerchantId: userInfo.MerchantId,
              MerchantPassword: userInfo.MerchantPassword,
              PageNumber: null,
              PageSize: null
            };
          } 
          // else {
          //   merchant = {
          //     MerchantId: '834',
          //     MerchantPassword: 'm5494'
          //   };
          // }
          // console.log(merchant);
  
          return {
            // get SETTINGS
            getSettings: function () {
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/getSettings', merchant)
                .then(
                  function (response) {
  
                    var settings = response.data.Data;
                    deferred.resolve(settings);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
  
                  });
              return deferred.promise;
            },
            // update SETTINGS
            updateSettings: function (MerchantId, smallReceipt, salesTax, confirmPhone, paxTerminalAsPrinter) {
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/updateSettings', {
                  MerchantId: MerchantId,
                  MerchantPassword: merchant.MerchantPassword,
                  SmallReceipt: smallReceipt,
                  Tax: salesTax,
                  ConfirmPhone: confirmPhone,
                  PaxTerminalAsPrinter: paxTerminalAsPrinter
                })
                .then(
                  function (response) {
  
                    var updateSettingsResponse = response.data;
                    // console.log(updateSettingsResponse);
                    deferred.resolve(updateSettingsResponse);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
  
                  });
              return deferred.promise;
            }
          };
        }
      ])
      // get merchant orders
      .factory('OrderFactory', ['$http', '$rootScope', 'API_URL', '$q',
        function ($http, $rootScope, API_URL, $q) {
          var params = {};
  
          return {
            // get ORDERS
            getOrders: function (StartDate, EndDate, PageNumber, PageSize, MerchantInfo) {
  
              params = {
                StartDate: StartDate,
                EndDate: EndDate,
                PageNumber: PageNumber,
                PageSize: PageSize,
                MerchantId: MerchantInfo.MerchantId,
                MerchantPassword: MerchantInfo.MerchantPassword
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/getallorders', params).then(
                function (response) {
                  var orders = response.data;
                  // console.log(response.data.Data)
                  deferred.resolve(orders);
                },
                function (err) {
                  deferred.reject(err);
                  void 0;
                }
              );
              return deferred.promise;
            },
            getAllOrdersSummary: function (StartDate, EndDate, MerchantInfo) {
  
              params = {
                StartDate: StartDate,
                EndDate: EndDate,
                MerchantId: MerchantInfo.MerchantId,
                MerchantPassword: MerchantInfo.MerchantPassword
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/GetAllOrdersSummary', params).then(
                function (response) {
                  var orders = response.data;
                  // console.log(response.data.Data)
                  deferred.resolve(orders);
                },
                function (err) {
                  deferred.reject(err);
                  void 0;
                }
              );
              return deferred.promise;
            },
            refundOrder: function (orderId, MerchantInfo) {
  
              var deferred = $q.defer();
  
              params = {
                MerchantId: MerchantInfo.MerchantId,
                MerchantPassword: MerchantInfo.MerchantPassword,
                OrderId: orderId
              };
  
              $http.post(API_URL + 'admin/RefundOrder', params).then(
                function (response) {
                  var orders = response.data;
                  // console.log(response.data.Data)
                  deferred.resolve(orders);
                },
                function (response) {
                  deferred.reject(response);
                  void 0;
                }
              );
              return deferred.promise;
            },
            reSendOrderConfirmation: function (orderId, MerchantInfo) {
  
              var deferred = $q.defer();
  
              params = {
                MerchantId: MerchantInfo.MerchantId,
                MerchantPassword: MerchantInfo.MerchantPassword,
                OrderId: orderId
              };
  
              //this function actually return the receipt from the order, the logic after this is display that info
              //dont resend anything, just return receipt info
              $http.post(API_URL + 'admin/ReSendOrderConfirmation', params).then(
                function (response) {
                  var orders = response.data;
                  // console.log(response.data.Data)
                  deferred.resolve(orders);
                },
                function (response) {
                  deferred.reject(response);
                  void 0;
                }
              );
              return deferred.promise;
            },
            downloadAsCvs: function (Start, End, MerchantInfo) {
              params = {
                StartDate: Start,
                EndDate: End,
                MerchantId: MerchantInfo.MerchantId,
                MerchantPassword: MerchantInfo.MerchantPassword
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/GetAllOrdersToExport', params).then(
                function (response) {
                  var orders = response.data;
                  // console.log(response.data.Data)
                  deferred.resolve(orders);
                },
                function (err) {
                  deferred.reject(err);
                  void 0;
                }
              );
              return deferred.promise;
            },
            sendAsEmail: function (Start, End, Email, MerchantInfo) {
  
              var deferred = $q.defer();
  
              params = {
                StartDate: Start,
                EndDate: End,
                Email: Email,
                MerchantId: MerchantInfo.MerchantId,
                MerchantPassword: MerchantInfo.MerchantPassword
              };
  
              $http.post(API_URL + 'ReceiptServices/SendOrdersByEmail', params).then(
                function (response) {
                  var orders = response.data;
                  // console.log(response.data.Data)
                  deferred.resolve(orders);
                },
                function (response) {
                  deferred.reject(response);
                  void 0;
                }
              );
              return deferred.promise;
            }
          };
        }
      ])

      // get merchant PortIns
      .factory('PortInFactory', ['$http', '$rootScope', 'API_URL', '$q',
        function ($http, $rootScope, API_URL, $q) {
          var params = {};
  
          return {
            // get PortIns
            getPortIns: function (MerchantInfo) {
  
              params = {                
                MerchantId: MerchantInfo.MerchantId,
                MerchantPassword: MerchantInfo.MerchantPassword
              };
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'v2/orders/getportinorders', params).then(
                function (response) {
                  var portIns = response.data;
                  // console.log(response.data.Data)
                  deferred.resolve(portIns);
                },
                function (err) {
                  deferred.reject(err);
                  void 0;
                }
              );
              return deferred.promise;
            }            
          };
        }
      ])

      // get saved payments, add arch funds (admin)
      .factory('AdminFactory', ['$http', '$rootScope', 'API_URL', '$q', 'localStorageService', 'AuthenticationFactory', 'SharedFunctions','URL_BACKEND',
        function ($http, $rootScope, API_URL, $q, localStorageService, AuthenticationFactory, SharedFunctions, URL_BACKEND) {
          var merchant;
  
          // get user info from localStorageService
          var userInfo = AuthenticationFactory.getUserInfo();
  
          if (userInfo != null || SharedFunctions.isobject(userInfo)) {
            merchant = {
              MerchantId: userInfo.MerchantId,
              MerchantPassword: userInfo.MerchantPassword
            };
          } 
          /////////// check in future that was a error ///////////////
          // else {
          //   merchant = {
          //     MerchantId: '834',
          //     MerchantPassword: 'm5494'
          //   };
          // }
          // console.log(merchant);
  
          return {
            getSavedAchPayments: function () {
              var deferred = $q.defer();
  
              var ordersUrl = API_URL + 'Admin/GetSavedAchPayments';
  
              $http.post(ordersUrl, merchant)
                .then(
                  function (response) {
  
                    var achs = response.data.Data;
                    deferred.resolve(achs);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
                    void 0;
                  }
                );
              return deferred.promise;
            },
            // Add funds and/or to account
            addAchFunds: function (id, accountNumber, routingNumber, MerchantId, amount, saveAccount, typeChecking) {
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'Admin/AddAchFunds', {
                  Id: id,
                  AccountNumber: accountNumber,
                  RoutingNumber: routingNumber,
                  MerchantId: MerchantId,
                  MerchantPassword: merchant.MerchantPassword,
                  Amount: amount,
                  SaveAccount: saveAccount,
                  TypeChecking: typeChecking
                })
                .then(
                  function (response) {
  
                    var arr = response.data;
                    // console.log(response);
                    deferred.resolve(arr);
  
                  },
                  function (response) {
  
                    void 0;
                    deferred.reject(response);
  
                  }
                );
              return deferred.promise;
            },
            getAppMainLogoUrl: function (MerchantId, Password) {
  
              var deferred = $q.defer();
  
              $http.post(API_URL + 'admin/GetAppMainLogoUrl', {
                  MerchantId: MerchantId,
                  MerchantPassword: Password
                })
                .then(
                  function (response) {
  
                    var data = response.data;
                    void 0;
                    deferred.resolve(data);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
  
                  }
                );
              return deferred.promise;
            },
            saveATH: function (merchantId, token) {
              var deferred = $q.defer();
  
              $http.post(URL_BACKEND + '/api/ath/create', {
                  merchantID: merchantId,
                  token: token
                })
                .then(
                  function (response) {
  
                    var data = response.data;
                    void 0;
                    console.log(data);
                    deferred.resolve(data);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
  
                  }
                );
              return deferred.promise;
            },
            selectATH: function (merchantID) {
              var deferred = $q.defer();
  
              $http.post(URL_BACKEND + '/api/ath/find', {
                  merchantID: merchantID
                })
                .then(
                  function (response) {
  
                    var data = response.data;
                    void 0;
                    console.log(data);
                    deferred.resolve(data);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
  
                  }
                );
              return deferred.promise;
            },
            deleteATH: function (idath) {
              var deferred = $q.defer();
  
              $http.delete(URL_BACKEND + '/api/ath/delete/' + idath)
                .then(
                  function (response) {
  
                    var data = response.data;
                    void 0;
                    console.log(data);
                    deferred.resolve(data);
  
                  },
                  function (response) {
  
                    deferred.reject(response);
  
                  }
                );
              return deferred.promise;
            }
          };
        }
      ]);
  }());