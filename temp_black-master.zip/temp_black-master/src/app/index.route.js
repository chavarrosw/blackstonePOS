(function () {
  'use strict';

  angular
    .module('posClient')
    .config(routerConfig);

  /** @ngInject */
  function routerConfig($routeProvider) {
    // var dynamicInquiryId;
    $routeProvider
      .when('/pos/inquiry/:inquiryId', {
        controller: 'InquiryController',
        controllerAs: 'vm',
        templateUrl: 'app/inquiry/inquiry.html'
        // resolve: {
        //   inquiryId: function ($q, $route) {
        //     dynamicInquiryId = $route.current.params.inquiryId;
           
        //     var deferred = $q.defer();            

        //     deferred.resolve(dynamicInquiryId);

        //     return deferred;
        //   }
        // },
        // templateUrl: function () {          
        //   return InquiryMap[dynamicInquiryId];
        // }
      })
      .when('/login', {
        controller: 'LoginController',
        controllerAs: 'vm',
        templateUrl: 'app/login/login-default.html'
      })
      .when('/', {
        controller: 'HomeController',
        templateUrl: 'app/home/home.html'
      })
      .when('/admin', {
        controller: 'AdminController',
        controllerAs: 'vm',
        templateUrl: 'app/admin/admin.html'
      })
      //ACTIVATION
      .when('/pos/activation/result', {
        controller: 'ActivationResultController',
        controllerAs: 'vm',
        templateUrl: 'app/activation/activation-result.html'
      })
      .when('/pos/activation/:groupId/:code?', {
        controller: 'ActivationController',
        controllerAs: 'vm',
        templateUrl: 'app/activation/activation-index.html'
      })
      .when('/pos/requestPorting/:orderId?', {
        controller: 'RequestPortingController',
        controllerAs: 'vm',
        templateUrl: 'app/activation/request-porting.html'
      })
      // PROMOTIONS
      .when('/pos/category/promotions', {//
        controller: 'PromosCtrl',
        templateUrl: 'app/promotions/_index-promos.html'
      })
      // categories
      .when('/pos/category/:category', {
        controller: 'IndexByCategoryCtrl',
        templateUrl: 'app/products/_index-products.html'
      })
      .when('/pos/category/:category/amount/:amount', {
        controller: 'IndexByCategoryCtrl',
        templateUrl: 'app/products/_index-products.html'
      })
      // countries
      .when('/pos/category/:category/countries', {
        controller: 'IndexCountriesByCategoryCtrl',
        templateUrl: 'app/products/_index-countries.html'
      })
      .when('/pos/category/:category/group/:groupId', {
        controller: 'IndexByGroupCtrl',
        templateUrl: 'app/products/_index-group.html'
      })
      .when('/pos/category/:category/country/:country', {
        controller: 'IndexByCategoryByCountryController',
        templateUrl: 'app/products/_index-products.html'
      })
      // carriers
      .when('/pos/category/:category/carriers', {
        controller: 'IndexByCarriersCtrl',
        templateUrl: 'app/products/_index-carriers.html'
      })
      .when('/pos/category/:category/carrier/:carrier', {
        controller: 'IndexByCategoryByCarrierCtrl',
        templateUrl: 'app/products/_index-products.html'
      })
      .when('/pos/category/:category/product/:id', {
        controller: 'ProductController',
        controllerAs: 'vm',
        templateUrl: 'app/products/show-product.html'
      })
      // BILL PAYMENT
      .when('/billpayment/category', {
        controller: 'IndexCategoriesController',
        templateUrl: 'app/billpayment/_index-categories.html'
      })
      .when('/billpayment/category/:category', {
        controller: 'IndexByCategoryController',
        templateUrl: 'app/billpayment/_index-billers.html'
      })
      .when('/billpayment/popular', {
        controller: 'BillPaymentByPopularController',
        templateUrl: 'app/billpayment/_index-categories.html'
      })
      .when('/billpayment/biller/:biller', {
        controller: 'ShowBillPaymentController',
        templateUrl: 'app/billpayment/_show-biller.html'
      })
      // sunpass
      .when('/pos/category/tolls/documents/product/:id', {
        controller: 'SunpassDocumentController',
        controllerAs: 'vm',
        templateUrl: 'app/tolls/documents-tolls.html'
      })
      .when('/pos/category/tolls/replenish/product/:id', {
        controller: 'SunpassReplenishController',
        controllerAs: 'vm',
        templateUrl: 'app/tolls/replenish-tolls.html'
      })
      .when('/tolls', {//
        controller: 'SunpassController',
        controllerAs: 'vm',
        templateUrl: 'app/tolls/index-tolls.html'
      })
      // DIRECT TV
      .when('/directtv/categories', {
        controller: 'IndexDirectTvCategoriesCtrl',
        templateUrl: 'app/directtv/_index-categories-dtv.html'
      })
      .when('/directtv/category/:category', {
        controller: 'IndexDirectTvByCategoryCtrl',
        templateUrl: 'app/directtv/_index-dtv.html'
      })
      .when('/directtv/product/:product', {
        controller: 'showDirectTvCtrl',
        templateUrl: 'app/directtv/_show-dtv.html'
      })
      .when('/terms/:id', {
        controller: 'ShowTermsCtrl',
        templateUrl: 'app/products/_show-terms.html'
      })
      // others
      .when('/others', {
        controller: 'directTvCtrl',
        templateUrl: 'app/directtv/_index-directtv.html'
      })
      .when('/billpayment/biller/:billerOne/:billerTwo', {
        controller: 'ShowBillPaymentController',
        templateUrl: 'app/billpayment/_show-biller.html'
      })
      .otherwise({
        redirectTo: '/login'
      });

    // function getTemplateUrl(hostname) {
    //   var templateUrl;

    //   switch (hostname) {
    //     case 'localhost':
    //       templateUrl = 'app/login/login-default.html';
    //       break;
    //     case 'mobile.fcusa.us':
    //       templateUrl = 'app/login/login-fcusa.html';
    //       break;
    //     case 'mobile.touch-n-buy.com':
    //       templateUrl = 'app/login/login-touch-n-buy.html';
    //       break;
    //     default:
    //       templateUrl = 'app/login/login-default.html';
    //   }

    //   return templateUrl;
    // }
  }

})();
