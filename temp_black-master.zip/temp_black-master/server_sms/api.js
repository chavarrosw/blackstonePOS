const express = require('express');
const app = express.Router();

const cors = require('cors');
//#region Rutas
require('./routes/sms')(app, cors);
require('./routes/ath')(app);
require('./routes/logs')(app);
require('./routes/ads')(app);
require('./routes/mail')(app);
require('./routes/rapidito')(app);
//#endregion
module.exports = app;