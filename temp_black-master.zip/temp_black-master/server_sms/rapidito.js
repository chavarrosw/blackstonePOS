const db = require('./../db/dbconnection');
var axios = require("axios");

async function validateUser(userId) {
    const q = `SELECT * FROM UserRapidito WHERE IdRapidito = '${userId}' and Active=1`
    const result = await db.query(q);
    return (result.recordsets[0][0]);
}

async function extractMerchant(idMerchant) {
    const q = `SELECT * FROM Merchant WHERE MerchantId = '${idMerchant}' and Active=1`;
    const result = await db.query(q);
    return (result.recordsets[0][0]);
}

async function extractProductByCode(productCode) {
    //data = req.body
    const q = `SELECT * FROM Product WHERE Code = '${productCode}' and Active=1`
    const result = await db.query(q);
    //res.json({ data: result.recordsets });

    return (result.recordsets)
}

async function extractProductByName(productName) {
    //data = req.body
    const q = `SELECT * FROM Product WHERE Name = '${productName}' and Active=1`
    const result = await db.query(q);
    //res.json({ data: result.recordsets });

    return (result.recordsets[0][0])
}

/** Guardar respuesta del servicio de Rapidito-Blackstone */
async function saveLogResponse(merchantID, category, productCode, logData, logResponse) {
    const q = `INSERT INTO log_transaction(merchantID,category,productCode,logData,logResponse) VALUES ('${merchantID}','${category}','${productCode}','${JSON.stringify(logData)}','${JSON.stringify(logResponse)}');`
    const result = await db.query(q);
    return (result.recordsets);
}

module.exports = {

    payClaro: async (req, res) => {
        const data = req.body;
        // console.log("req.body: ", JSON.stringify(req.body));
        // console.log("number: ", data.phoneNumber);
        // console.log("ammount: ", data.ammount);
        // console.log("userId derapidito: ", data.idUserRapidito);

        //Validar usuario
        var user = await validateUser(data.idUserRapidito)

        if (user != null) {
            //Extraer merchantId y MerchantPassword
            var merchant = await extractMerchant(user.IdMerchant);
            // console.log('Merchant Data: ', merchant);
            if (merchant != null) {
                const productName = "claro_prepago"
                product = await extractProductByName(productName)

                // order = {
                //     MerchantId: 834,
                //     MerchantPassword: "93e53ae1767a8b22e3a633545fa5326f53996c4b5c3bdb4fc6a841e2d6bba514a511875f5097bbcf8136eb386c551a31556da7441bf6fef837d69aadf3171044",
                //     AdditionalPhones: null,
                //     OperatorName: "MANAGER", // string
                //     ProfileId: 123, // int
                //     TerminalId: 123, // int
                //     Amount: 10,
                //     PhoneNumber: 12312312312,
                //     ProductMainCode: 301073,//CLARO
                //     CountryCode: 1,
                //     ZipCode: 1
                // }

                const order = {
                    MerchantId: merchant.MerchantId,
                    MerchantPassword: merchant.MerchantPassword,
                    AdditionalPhones: null,
                    OperatorName: "MANAGER", // string
                    ProfileId: 1, // int
                    TerminalId: 1, // int
                    Amount: data.ammount,
                    PhoneNumber: data.number,
                    ProductMainCode: product.Code,//301073 CLARO
                    CountryCode: 1,
                    ZipCode: 1
                }

                if (product !== null) {
                    config = {
                        method: "POST",
                        url:
                            "http://bsapi.pinserve.com/api/Products/DoBlackstonePosOperation",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        //data: JSON.stringify(order),
                        data: order,
                    }

                    return axios(config)
                        .then(async function (response) {
                            //TODO --> GUARDAR EN LOG LOS DATOS DE TRANSACCION
                            await saveLogResponse(merchant.MerchantId, 'rapidito', product.Code, order, response.data);
                            res.status(200).send({ "Status": 200, "ErrorMessage": "", "UpdateNeeded": null });
                        })
                        .catch(function (error) {
                            res.status(400).send({ "Status": 400, "ErrorMessage": "Not sent!", "UpdateNeeded": true });
                        });

                }

            }
            else {
                res.status(400).send({ "Status": 400, "ErrorMessage": "Error en merchant", "UpdateNeeded": true });
            }

        }
        else {
            res.status(400).send({ "Status": 400, "ErrorMessage": "User not registered", "UpdateNeeded": true });
        }

        return mensajeGo4clients(telephone, sms, res);
    },


    payClaroPrPlanRTR: async (req, res) => {
        const data = req.body;

        //Validar usuario
        var user = await validateUser(data.idUserRapidito)

        if (user != null) {
            //Extraer merchantId y MerchantPassword
            var merchant = await extractMerchant(user.IdMerchant);
            console.log('Merchant Data: ', merchant);
            if (merchant != null) {
                const productName = "claro_pr_plan_rtr"
                product = await extractProductByName(productName)

                const order = {
                    MerchantId: merchant.MerchantId,
                    MerchantPassword: merchant.MerchantPassword,
                    OperatorName: "MANAGER", // string
                    Amount: data.ammount,
                    PhoneNumber: data.number,
                    ProductMainCode: product.Code,//320166 claro_pr_plan_rtr
                    CountryCode: 1,
                    ZipCode: 1,
                    PurchaseId: "", // int
                    SystemType: 4, // int
                }

                if (product !== null) {
                    config = {
                        method: "POST",
                        url:
                            "http://bsapi.pinserve.com/api/Products/DoBlackstonePosOperation",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        //data: JSON.stringify(order),
                        data: order,
                    }

                    return axios(config)
                        .then(async function (response) {
                            //TODO --> GUARDAR EN LOG LOS DATOS DE TRANSACCION
                            await saveLogResponse(merchant.MerchantId, 'payClaroPrPlanRTR', product.Code, order, response.data);
                            res.status(200).send({ "Status": 200, "ErrorMessage": "", "UpdateNeeded": null });
                        })
                        .catch(function (error) {
                            console.log("mal", error);
                            res.status(400).send({ "Status": 400, "ErrorMessage": "Not sent!", "UpdateNeeded": true });
                        });
                }
            }
            else {
                res.status(400).send({ "Status": 400, "ErrorMessage": "Error en merchant", "UpdateNeeded": true });
            }
        }
        else {
            res.status(400).send({ "Status": 400, "ErrorMessage": "User not registered", "UpdateNeeded": true });
        }

        return mensajeGo4clients(telephone, sms, res);
    },

    payAttPrepaidRtrPr: async (req, res) => {
        const data = req.body;

        //Validar usuario
        var user = await validateUser(data.idUserRapidito)

        if (user != null) {
            //Extraer merchantId y MerchantPassword
            var merchant = await extractMerchant(user.IdMerchant);
            console.log('Merchant Data: ', merchant);
            if (merchant != null) {
                const productName = "att_prepaid_rtr_pr"
                product = await extractProductByName(productName)

                const order = {
                    MerchantId: merchant.MerchantId,
                    MerchantPassword: merchant.MerchantPassword,
                    OperatorName: "MANAGER", // string
                    Amount: data.ammount,
                    PhoneNumber: data.number,
                    ProductMainCode: product.Code,//320167 att_prepaid_rtr_pr
                    CountryCode: 1,
                    ZipCode: 1,
                    PurchaseId: "", // int
                    SystemType: 4, // int
                }

                if (product !== null) {
                    config = {
                        method: "POST",
                        url:
                            "http://bsapi.pinserve.com/api/Products/DoBlackstonePosOperation",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        //data: JSON.stringify(order),
                        data: order,
                    }

                    return axios(config)
                        .then(async function (response) {
                            //TODO --> GUARDAR EN LOG LOS DATOS DE TRANSACCION
                            await saveLogResponse(merchant.MerchantId, 'payAttPrepaidRtrPr', product.Code, order, response.data);
                            res.status(200).send({ "Status": 200, "ErrorMessage": "", "UpdateNeeded": null });
                        })
                        .catch(function (error) {
                            console.log("mal", error);
                            res.status(400).send({ "Status": 400, "ErrorMessage": "Not sent!", "UpdateNeeded": true });
                        });
                }
            }
            else {
                res.status(400).send({ "Status": 400, "ErrorMessage": "Error en merchant", "UpdateNeeded": true });
            }
        }
        else {
            res.status(400).send({ "Status": 400, "ErrorMessage": "User not registered", "UpdateNeeded": true });
        }

        return mensajeGo4clients(telephone, sms, res);
    },


}
