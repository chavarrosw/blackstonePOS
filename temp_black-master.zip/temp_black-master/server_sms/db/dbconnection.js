
const config = {
    user: 'sa',
    password: 'StoneBlack@601',
    server: 'localhost\\PREPAID', // You can use 'localhost\\instance' to connect to named instance
    database: 'bs',
    port: 1433,
    options: {
        enableArithAbort: false
    }
}
/*
const config = {
    user: 'sa',
    password: '@@SQLSERVER2020',
    server: 'localhost', // You can use 'localhost\\instance' to connect to named instance
    database: 'bs',
    port: 1433,
    options: {
        enableArithAbort: false
    }
}*/
const sql = require('mssql')
var pool;

module.exports = {
    connect: async (app, port) => {
        try {
            pool = await sql.connect(config);
            console.log('DB connected!');
            app.listen(port, () => {
                console.log(`App listening at http://localhost:${port}`);
            });
        } catch (err) {
            console.log(err);
        }
    },
    query: async (q) => {
        try {
            return await pool.request().query(q)
        } catch (err) {
            // Todo: manejo del error
            return null;
        }
    }

}