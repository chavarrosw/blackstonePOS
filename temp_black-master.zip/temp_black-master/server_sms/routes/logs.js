const controller = require('./../controllers/logs');
module.exports = (app) => {
    app.post('/log', controller.insertLog);
}