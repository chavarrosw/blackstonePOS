const controller = require('./../controllers/mail');

module.exports = (app, cors) => {

    app.post("/email", controller.sendMail);
}