const controller = require('./../controllers/ath');
module.exports = (app) => {
    app.post("/ath_account", controller.getAccount);
    app.post("/ath_account/insert", controller.insertAccount);
    app.post("/ath_account/selectOne", controller.selectOneAccount);
    app.delete("/ath_account/delete/:id", controller.deleteOneAccount);
}