const controller = require("./../controllers/ads");

module.exports = (app) => {
    app.get("/promo", controller.getAds);
}