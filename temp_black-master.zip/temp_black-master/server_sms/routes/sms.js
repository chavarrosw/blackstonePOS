const controller = require('./../controllers/sms');
const corsOptions = {
    origin: '*',
    optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
  }
module.exports = (app, cors) => {
  app.post("/smsgo4clients", cors(corsOptions), controller.goTwillio);
  app.post("/smstwilio", cors(corsOptions), controller.goTwillio);
}