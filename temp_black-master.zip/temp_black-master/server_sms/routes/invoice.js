const controller = require('./../controllers/invoice');
module.exports = (app) => {
    app.get('/invoice/:id', controller.getInvoice);
}