const controller = require('./../controllers/rapidito');
module.exports = (app) => {
    //app.post("/gateway/pay_claro", controller.payClaro);
    app.post("/gateway/pay_claro_pr_plan_rtr", controller.payClaroPrPlanRTR);
    app.post("/gateway/pay_att_prepaid_rtr_pr", controller.payAttPrepaidRtrPr);
    app.post("/gateway/create_user", controller.createUser)
    app.post("/test/", controller.setConfiguration)
}