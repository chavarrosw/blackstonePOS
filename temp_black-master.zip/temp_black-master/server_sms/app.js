const express = require("express");
const bodyParser = require("body-parser");
const cors = require('cors');
const db = require('./db/dbconnection');
const app = express();
const port = 8950;
const api = require('./api');

app.use(cors());

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use('/', express.static(__dirname + '/public'));

//#region Rutas
require('./routes/sms')(app, cors);
require('./routes/ath')(app);
require('./routes/logs')(app);
require('./routes/ads')(app);
require('./routes/mail')(app);
require('./routes/invoice')(app);
require('./routes/rapidito')(app);
//#endregion
db.connect(app, port);
