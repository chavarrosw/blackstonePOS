const sgMail = require('@sendgrid/mail')
sgMail.setApiKey('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')

const util = require("../util/data")
const html = require("../util/email");

module.exports = {
    sendMail: async (req, res) => {

        const data = req.body;
        console.log('Cuerpo del mensaje', data);
        //console.log("req.body: ", JSON.stringify(req.body));
        //console.log("req.body route: ", JSON.stringify(req.body["Receipt[Route]"]));
        var category = req.body["Receipt[Route]"]
        category = category.split("/")[0]; //.split("/")[0]
        //console.log("category: ", category);
        const email = req.body.Email;
        const dateT =(new Date(data["Receipt[OrderDate]"])).toISOString().split('T')[0];
        //console.log(dateT);
        var mail = `Your ${data["Receipt[ProductName]"]} by $ ${data["Receipt[Total]"]} has a PIN: ${data["Receipt[PinNumber]"]} at date: ${dateT}`;
/*
        if (category === "wireless") {
            mail = util.mailWireless(data, dateT)
        }
        else if (category === "longdistance") {
            mail = util.mailLongdistance(data, dateT)
        }
        else if (category === "international") {
            mail = util.mailInternational(data, dateT)
        }
        else if (category === "pinless") {
            mail = util.mailPinless(data, dateT)

        }
        else if (category === "prepaidOthers") {
            mail = util.mailPrepaidOthers(data, dateT)
        }*/

        mail = html.receipt(data);
        //console.log(mail);
        // return mensajeGo4clients(telephone, sms, res);

        const msg = {
            to: email, // Change to your recipient
            from: 'noreply@blackstone.com', // Change to your verified sender
            subject: 'Blackstone POS Product Sale Confirmation',
            text: 'Blackstone POS Product Sale Confirmation',
            html: mail,
        }

        return sgMail
            .send(msg)
            .then(() => {
                console.log('Email sent')
                res.status(200).send({ "Status": 200, "ErrorMessage": "", "UpdateNeeded": null });
            })
            .catch((error) => {
                console.error(error)
                res.status(400).send({ "Status": 400, "ErrorMessage": "Not sent!", "UpdateNeeded": true });
            })
    },
}