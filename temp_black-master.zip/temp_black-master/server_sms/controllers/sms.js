
//Twilio - Gabriel credentials
//const accountSid = "AC6fe58ab45bc845107b501fda8be1130f";
//const authToken = "9b711c75544f10c025163f0b305cc60a";
//const from = "+12065945258";

//Twilio - Julian credentials
//Twilio - Production credentials
const accountSid = "ACd4dfa15c2f459024bfad0e07c10d6268";
const authToken = "0b6a63b4be88865504777e4431a7c781";
const from = "+17867675584";


var axios = require("axios");
const client = require("twilio")(accountSid, authToken);
const util = require("../util/data")


//Go4Client - Gabriel credentials
const apyKeyGo4Client = "2ba2c6d86e184f9f8a4fcb75595fbe79";
const apiSecretGo4Client = "5068319362360057";
const smsCampaignId = "5f56b6896662b70008f167f5";

//Twilio - Gabriel credentials
// const accountSid = "AC642bac254a5f80015f7b4cdea2e14630";
// const authToken = "39f3c57930c162a113ff68b588ac6b7e";
// const from = "+14704315891";

function mensajeTwilio(number, sms, res) {
    return client.messages
        .create({
            body: sms,
            from: from,
            to: number,
        })
        .then(function (resp) {
            res.status(200).send({ "Status": 200, "ErrorMessage": "", "UpdateNeeded": null });
        })
        .catch((e) => {
            console.log("error", e);
            res.status(400).send({ "Status": 400, "ErrorMessage": "Not sent!", "UpdateNeeded": true });
        });
}

function mensajeGo4clients(number, sms, res) {
    (mensaje = {
        message: sms,
        priority: "HIGH",
        destinationsList: [number],
        landingCustomFields: {
            573212786301: {
                name: "test",
            },
        },
    }),
        (config = {
            method: "POST",
            url:
                "https://cloud.go4clients.com:8580/api/campaigns/sms/v1.0/" +
                smsCampaignId,
            headers: {
                apiKey: apyKeyGo4Client,
                apiSecret: apiSecretGo4Client,
                "Content-Type": "application/json",
            },
            data: JSON.stringify(mensaje),
        });
    return axios(config)
        .then(function (response) {
            console.log("Bien", JSON.stringify(response.data));
            res.status(200).send({ "Status": 200, "ErrorMessage": "", "UpdateNeeded": null });
        })
        .catch(function (error) {
            console.log("mal", error);
            res.status(400).send({ "Status": 400, "ErrorMessage": "Not sent!", "UpdateNeeded": true });
        });
}

module.exports = {
    goClient: async (req, res) => {
        const data = req.body;
        console.log("req.body: ", JSON.stringify(req.body));
        console.log("req.body route: ", JSON.stringify(req.body["Receipt[Route]"]));
        var category = req.body["Receipt[Route]"]
        category = category.split("category/")[1].split("/")[0]
        console.log("category: ", category);
        const telephone = "1" + req.body.PhoneNumber;
        const dateT = (new Date(data["Receipt[OrderDate]"])).toISOString().split('T')[0];
        var sms = `Your ${data["Receipt[ProductName]"]} by $ ${data["Receipt[Total]"]} has a PIN: ${data["Receipt[PinNumber]"]} at date: ${dateT}`;

        if (category === "wireless") {
            sms = util.smsWireless(data)
        }
        else if (category === "longdistance") {
            sms = util.smsLongdistance(data)
        }
        else if (category === "international") {
            sms = util.smsInternational(data)
        }
        else if (category === "pinless") {
            sms = util.smsPinless(data)
        }
        else if (category === "prepaidOthers") {
            sms = util.smsPrepaidOthers(data)
        }

        // console.log(sms);
        return mensajeGo4clients(telephone, sms, res);
    },
    goTwillio: async (req, res) => {
        const data = req.body;
        //console.log("req.body: ", JSON.stringify(req.body));
        //console.log("req.body route: ", JSON.stringify(req.body["Receipt[Route]"]));
        var category = req.body["Receipt[Route]"]
        category = category.split("category/")[1].split("/")[0]
        //console.log("category: ", category);
        const telephone = "+1" + req.body.PhoneNumber;
        const dateT = (new Date(data["Receipt[OrderDate]"])).toISOString().split('T')[0];
        // var sms = `Your ${data["Receipt[ProductName]"]} by $ ${data["Receipt[Total]"]} has a PIN: ${data["Receipt[PinNumber]"]} at date: ${dateT}`;
        var sms = `You can view your invoice at this http://196.42.15.247:8950/invoice/${Buffer.from(data.ID).toString('base64')}`;
        /*
        if (category === "wireless") {
            sms = util.smsWireless(data)
        }
        else if (category === "longdistance") {
            sms = util.smsLongdistance(data)
        }
        else if (category === "international") {
            sms = util.smsInternational(data)
        }
        else if (category === "pinless") {
            sms = util.smsPinless(data)
        }
        else if (category === "prepaidOthers") {
            sms = util.smsPrepaidOthers(data)
        }*/
        // console.log(sms);
        // return mensajeGo4clients(telephone, sms, res);
        return mensajeTwilio(telephone, sms, res);
    },
    goTwillio2: async (req, res) => {
        return mensajeTwilio(req.body.number, req.body.sms, res);
    }

}