const db = require('./../db/dbconnection');

module.exports = {
    insertLog: async (req, res) => {
        data = req.body;
        let infoPay = { amount: -1, phoneNumber: -1 };
        try {
            let aux = JSON.parse(data.logData);
            infoPay.amount = aux.Amount;
            infoPay.phoneNumber = aux.PhoneNumber;
        } catch(err) {
            console.log('Error leyendo información del pago!!');
        }
        const q = `INSERT INTO log_transaction(merchantID, phoneNumber, amount,category,productCode,logData,logResponse) OUTPUT Inserted.ID VALUES ('${data.merchantID}', '${infoPay.phoneNumber}', ${infoPay.amount}, '${data.category}','${data.productCode}','${JSON.stringify(data.logData)}','${JSON.stringify(data.logResponse)}');`
        const result = await db.query(q);
        res.json({ id: result.recordsets[0][0].ID });
    },
}