const db = require('./../db/dbconnection');
var axios = require("axios");
const configApi = require('../util/configuration');
const validationCode = require('../util/validationCode');

async function validateUser(userId) {
    const q = `SELECT * FROM UserRapidito WHERE IdRapidito = '${userId}' and Active=1`
    const result = await db.query(q);
    return (result.recordsets[0][0]);
}

async function extractMerchant(idMerchant) {
    const q = `SELECT * FROM Merchant WHERE MerchantId = '${idMerchant}' and Active=1`;
    const result = await db.query(q);
    return (result.recordsets[0][0]);
}

async function extractProductByCode(productCode) {
    //data = req.body
    const q = `SELECT * FROM Product WHERE Code = '${productCode}' and Active=1`
    const result = await db.query(q);
    //res.json({ data: result.recordsets });

    return (result.recordsets)
}

async function extractProductByName(productName) {
    //data = req.body
    const q = `SELECT * FROM Product WHERE Name = '${productName}' and Active=1`
    const result = await db.query(q);
    //res.json({ data: result.recordsets });

    return (result.recordsets[0][0])
}

/** Guardar respuesta del servicio de Rapidito-Blackstone */
async function saveLogResponse(merchantID, category, productCode, logData, logResponse) {
    const q = `INSERT INTO log_transaction(merchantID,category,productCode,logData,logResponse) VALUES ('${merchantID}','${category}','${productCode}','${JSON.stringify(logData)}','${JSON.stringify(logResponse)}');`
    const result = await db.query(q);
    return (result.recordsets);
}


async function saveUser(idRapidito, name, idMerchant){
    const active = true;
    const q = `INSERT INTO UserRapidito(idRapidito, name, idMerchant, active) VALUES ('${idRapidito}','${name}','${idMerchant}','${active}');`
    const result = await db.query(q);
    return (result.recordsets);
}

/** Función para validar transacción según monto por trans, por día, y número de trans */
async function checkTransaction(Amount, PhoneNumber, MerchantId, MaxT, MaxAmByT, MaxAmByD) {
    const myDay = new Date();
    const result = await configApi.getTransactionsByDay(MerchantId, myDay.toISOString().split('T')[0]);
    // Se proceden a realizar las validaciones del caso
    // 1. Validar monto máximo por transacción
    if (Amount > MaxAmByT) {
        return { Code: 4040, Msg: 'Maximum amount per transaction exceeded'}
    }
    // 2. Validar transacciones por día
    if (result.TotalTransactions >= MaxT) {
        return { Code: 5040, Msg: 'Maximum number of transactions exceeded'}
    }
    // 3. Validar max cantidad por día
    if (result.TotalAmountByDay >= MaxAmByD) {
        return { Code: 6030, Msg: 'Maximum amount per day exceeded'}
    }
    // 4. Validar que no se haya usado ese mismo día el número de teléfono
    if (result.phones.includes('' + PhoneNumber)) {
        return { Code: 3030, Msg: 'Only two phone transactions a day'}
    }
    return null;
}

module.exports = {

    createUser: async(req,res) =>{
        const data = req.body;
        var userDuplicate = await validateUser(data.userName)
        if (userDuplicate === null) {
            var user = await saveUser(data.userName, data.name, data.idMerchant)
            if (user === null) {
                res.status(200).send({ "Status": 200, "Message": "User created" });
            }
            res.status(400).send({ "Status": 400, "Message": "Error: User not created" });
        }
        res.status(400).send({ "Status": 400, "Message": "Error: duplicated Username"});
    },
    /** Establecer configuración de un merchant */
    setConfiguration: async (req, res) => {
        try {
            const result = await configApi.setConfiguration(req.body.Merchant, req.body.MaxT, req.body.MAByT, req.body.MAByD);            
            if (result && result.rowsAffected.length === 1 && result.rowsAffected[0] === 1) {
                res.status(200).json({ Code: 200, Msg: 'Configuration updated!'});
            } else {
                res.status(200).json({ Code: 400, Msg: 'Configuration not updated!, please check request data', Error: result});
            }
        } catch(e) {
            res.status(500).json({Code: 500, Msg: 'Error Proccesing Request!', Error: e});
        }
    },

    payClaro: async (req, res) => {
        const data = req.body;
        // console.log("req.body: ", JSON.stringify(req.body));
        // console.log("number: ", data.phoneNumber);
        // console.log("ammount: ", data.ammount);
        // console.log("userId derapidito: ", data.idUserRapidito);

        //Validar usuario
        var user = await validateUser(data.idUserRapidito)

        if (user != null) {
            //Extraer merchantId y MerchantPassword
            var merchant = await extractMerchant(user.IdMerchant);
            // console.log('Merchant Data: ', merchant);
            if (merchant != null) {
                const productName = "claro_prepago"
                product = await extractProductByName(productName)

                // order = {
                //     MerchantId: 834,
                //     MerchantPassword: "93e53ae1767a8b22e3a633545fa5326f53996c4b5c3bdb4fc6a841e2d6bba514a511875f5097bbcf8136eb386c551a31556da7441bf6fef837d69aadf3171044",
                //     AdditionalPhones: null,
                //     OperatorName: "MANAGER", // string
                //     ProfileId: 123, // int
                //     TerminalId: 123, // int
                //     Amount: 10,
                //     PhoneNumber: 12312312312,
                //     ProductMainCode: 301073,//CLARO
                //     CountryCode: 1,
                //     ZipCode: 1
                // }

                const order = {
                    MerchantId: merchant.MerchantId,
                    MerchantPassword: merchant.MerchantPassword,
                    AdditionalPhones: null,
                    OperatorName: "MANAGER", // string
                    ProfileId: 1, // int
                    TerminalId: 1, // int
                    Amount: data.ammount,
                    PhoneNumber: data.number,
                    ProductMainCode: product.Code,//301073 CLARO
                    CountryCode: 1,
                    ZipCode: 1
                }
                
                if (product !== null) {
                    config = {
                        method: "POST",
                        url:
                            "http://bsapi.pinserve.com/api/Products/DoBlackstonePosOperation",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        //data: JSON.stringify(order),
                        data: order,
                    }

                    return axios(config)
                        .then(async function (response) {
                            //TODO --> GUARDAR EN LOG LOS DATOS DE TRANSACCION
                            await saveLogResponse(merchant.MerchantId, 'rapidito', product.Code, order, response.data);
                            res.status(200).send({ "Status": 200, "Message": "Complete transaction - Pay correct"});
                        })
                        .catch(function (error) {
                            res.status(400).send({ "Status": 400, "Message": "Error: Incomplete transaction - Not sent!"});
                        });

                }

            }
            else {
                res.status(400).send({ "Status": 400, "Message": "Error: Error in merchant"});
            }

        }
        else {
            res.status(400).send({ "Status": 400, "Message": "Error: User not registered"});
        }

        return mensajeGo4clients(telephone, sms, res);
    },

    payClaroPrPlanRTR: async (req, res) => {
        const data = req.body;

        //Validar usuario
        var user = await validateUser(data.idUserRapidito)

        if (user != null) {
            //Extraer merchantId y MerchantPassword
            var merchant = await extractMerchant(user.IdMerchant);
            if (merchant != null) {
                // Validar código
                const resControl = validationCode.validateCode(merchant.MerchantId, data.number, data.ValidationCode);

                if (!resControl) {
                    res.status(500).json({ "Status": 401, "Message": "Error - Validation Code"});
                    return;
                }

                const productName = "claro_pr_plan_rtr"
                product = await extractProductByName(productName)

                const order = {
                    MerchantId: merchant.MerchantId,
                    MerchantPassword: merchant.MerchantPassword,
                    OperatorName: "MANAGER", // string
                    Amount: data.ammount,
                    PhoneNumber: data.number,
                    ProductMainCode: product ? product.Code : null,//320166 claro_pr_plan_rtr
                    CountryCode: 1,
                    ZipCode: 1,
                    PurchaseId: "", // int
                    SystemType: 4, // int
                }
                const resultConfig = await configApi.getConfiguration(merchant.MerchantId);  
                const resultCheck = await checkTransaction(data.ammount, data.number, merchant.MerchantId, resultConfig.MaxTransactions, resultConfig.MaxTransactionCap, resultConfig.MaxAmountByDay);
                if (product !== null && resultCheck === null) {
                    config = {
                        method: "POST",
                        url:
                            "http://bsapi.pinserve.com/api/Products/DoBlackstonePosOperation",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        //data: JSON.stringify(order),
                        data: order,
                    }

                    return axios(config)
                        .then(async function (response) {
                            //TODO --> GUARDAR EN LOG LOS DATOS DE TRANSACCION
                            // await saveLogResponse(merchant.MerchantId, 'payClaroPrPlanRTR', product.Code, order, response.data);
                            await configApi.insertTransactionApi(merchant.MerchantId, product.Code, data.ammount, data.number ,JSON.stringify(order), JSON.stringify(response.data));
                            res.status(200).send({ "Status": 200, "Message": "Complete transaction - Pay correct"});
                        })
                        .catch(function (error) {
                            console.log("mal", error);
                            res.status(400).send({ "Status": 400, "Message": "Error: Incomplete transaction - Not sent!"});
                        });
                } else if(resultCheck !== null) {
                    res.status(400).send({ "Status": resultCheck.Code, "Message": resultCheck.Msg});
                }
            }
            else {
                res.status(400).send({ "Status": 402, "Message": "Error: Error in merchant"});
            }
        }
        else {
            res.status(400).send({ "Status": 404, "Message": "Error: User not registered"});
        }
    },

    payAttPrepaidRtrPr: async (req, res) => {
        const data = req.body;

        //Validar usuario
        var user = await validateUser(data.idUserRapidito)

        if (user != null) {
            //Extraer merchantId y MerchantPassword
            var merchant = await extractMerchant(user.IdMerchant);
            if (merchant != null) {
                // Validar código
                const resControl = validationCode.validateCode(merchant.MerchantId, data.number, data.ValidationCode);

                if (!resControl) {
                    res.status(500).json({ "Status": 401, "Message": "Error - Validation Code"});
                    return;
                }
                const productName = "att_prepaid_rtr_pr"
                product = await extractProductByName(productName)

                const order = {
                    MerchantId: merchant.MerchantId,
                    MerchantPassword: merchant.MerchantPassword,
                    OperatorName: "MANAGER", // string
                    Amount: data.ammount,
                    PhoneNumber: data.number,
                    ProductMainCode: product.Code ? product.Code : null,//320167 att_prepaid_rtr_pr
                    CountryCode: 1,
                    ZipCode: 1,
                    PurchaseId: "", // int
                    SystemType: 4, // int
                }
                const resultConfig = await configApi.getConfiguration(merchant.MerchantId);  
                const resultCheck = await checkTransaction(data.ammount, data.number, merchant.MerchantId, resultConfig.MaxTransactions, resultConfig.MaxTransactionCap, resultConfig.MaxAmountByDay);
               
                if (product !== null && resultCheck === null) {
                    config = {
                        method: "POST",
                        url:
                            "http://bsapi.pinserve.com/api/Products/DoBlackstonePosOperation",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        //data: JSON.stringify(order),
                        data: order,
                    }

                    return axios(config)
                        .then(async function (response) {
                            //TODO --> GUARDAR EN LOG LOS DATOS DE TRANSACCION
                            // await saveLogResponse(merchant.MerchantId, 'payAttPrepaidRtrPr', product.Code, order, response.data);
                            
                            await configApi.insertTransactionApi(merchant.MerchantId, product.Code, data.ammount, data.number ,JSON.stringify(order), JSON.stringify(response.data));
                            res.status(200).send({ "Status": 200, "Message": "Complete transaction - Pay correct"});
                        })
                        .catch(function (error) {
                            console.log("mal", error);
                            res.status(400).send({ "Status": 402, "Message": "Error: Incomplete transaction - Not sent!"});
                        });
                } else if(resultCheck !== null) {
                    res.status(400).send({ "Status": resultCheck.Code, "Message": resultCheck.Msg});
                }
            }
            else {
                res.status(400).send({ "Status": 404, "Message": "Error: Error in merchant"});
            }
        }
        else {
            res.status(400).send({ "Status": 400, "Message": "Error: User not registered"});
        }
    },


}
