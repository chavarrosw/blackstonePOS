const db = require('./../db/dbconnection');
const util = require("../util/html");

module.exports = {
    getInvoice: async (req, res) => {
        const id = Buffer.from(req.params.id, 'base64').toString();
        const q = `SELECT * FROM log_transaction WHERE id = '${id}';`
        const result = await db.query(q);
        if (result.recordsets[0]) {
            const vm = {
                receipt: JSON.parse(JSON.parse(result.recordsets[0][0].logResponse))
            };
            const html = util.receipt(vm);
            res.send(html);
        } else {
            res.send({ msg: 'Invoice not found!'});
        }
    },
}