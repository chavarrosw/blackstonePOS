const db = require('./../db/dbconnection');

module.exports = {
    getAccount: async (req, res) => {
        const q = 'SELECT * FROM account_ath;'
        const result = await db.query(q);
        res.json({ data: result.recordset });
    },

    insertAccount: async (req, res) => {
        data = req.body
        const q = `INSERT INTO account_ath(merchantID,token)  VALUES ('${data.merchantID}','${data.token}'); SELECT * FROM Account_ATH WHERE merchantID = '${data.merchantID}' and deleted=0`
        const result = await db.query(q);
        res.json({ data: result });
    },

    selectOneAccount: async (req, res) => {
        data = req.body
        const q = `SELECT * FROM account_ath WHERE merchantID = '${data.merchantID}' and deleted=0`
        const result = await db.query(q);
        res.json({ data: result.recordsets });
    },

    deleteOneAccount: async (req, res) => {
        const id = req.params.id
        const q = `UPDATE account_ath SET deleted=1 WHERE id = '${id}'`
        const result = await db.query(q);
        res.json({ data: result });
    }
}
