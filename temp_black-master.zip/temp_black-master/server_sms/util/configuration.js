'use-strict'
const db = require('./../db/dbconnection');



module.exports = {
    /** Traemos la configuración del MerchantId */
    getConfiguration: async (MerchantId) => {
        const q = `select * from ConfigurationAPI where MerchantId = '${MerchantId}' and Active = 1;`;
        let result = await db.query(q);
        if (result.recordset.length === 0) {
            result = {
                MaxTransactions: 100,
                MaxTransactionCap: 100, 
                MaxAmountByDay: 5000
            }
        } else {
            result = result.recordset[0];
        }
        return result; 
    },
    /** Registramos y/o actualizamos la configuración asociada a un Merchant */
    setConfiguration: async (MerchantId, MaxTransactions, MaxTransactionCap, MaxAmountByDay) => {
        // Si existe se actualiza Active a cero y se inserta nuevo registro
        let queryData = `select * from ConfigurationAPI where MerchantId = '${MerchantId}' and Active = 1;`;
        let result1 = await db.query(queryData);
        if (result1.recordset.length !== 0) {
            let queryUpd = `update ConfigurationAPI set Active = 0 where Id = ${result1.recordset[0].Id}`;
            let result2 = await db.query(queryUpd);
        } 
        // Insertamos nueva configuración
        const q = `insert into ConfigurationAPI(MerchantId, MaxTransactions, MaxTransactionCap,MaxAmountByDay) values('${MerchantId}',${MaxTransactions},${MaxTransactionCap},${MaxAmountByDay});`;
        let result = await db.query(q);
        return result;
    },
    /** Traemos todas las transacciones del día de hoy */
    getTransactionsByDay: async (MerchantId, DateDay) => {
        /** Traemos todas las transacciones que sean del dia */
        let q = `select * from LogTransactionAPI where MerchantId = ${MerchantId};`;
        let result = await db.query(q);
        let amountAcum = 0;
        let phones = [];
        let transactions = result.recordset.filter(item => { 
            if (item.CreatedAt.toISOString().split('T')[0] === DateDay) {
                amountAcum += item.Amount;
                phones.push(item.PhoneNumber);
                return true;
            } else {
                return false;
            } } );
        // Estructuramos la respuesta
        const TotalTransactions = transactions.length;
        const TotalAmountByDay = amountAcum;
        return {
            TotalTransactions, TotalAmountByDay, phones
        };
    },
    /** Insertamos el log de una transacción */
    insertTransactionApi: async (MId, PCode, Amount, PhoneNumber, LogD, LogR) => {
        let q = `insert into LogTransactionAPI(MerchantId, ProductCode,Amount, PhoneNumber ,LogData, LogResponse) values('${MId}','${PCode}', ${Amount},'${PhoneNumber}','${LogD}','${LogR}');`;
        let result = await db.query(q);
        return result;
    }
}