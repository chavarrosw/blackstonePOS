module.exports = {
    receipt: (receipt) => {
        return `<html><head><title>Invoice</title></head><body><div id="myReceiptProduct" class="col-xs-12 col-sm-9 col-md-9">
        <h3>Receipts Sunpass Portal</h3>
        <table class="table-condensed receipt">
          <tbody>
          ${receipt['Receipt[ProductName]'] ? '<tr><td>Product Name:</td><td>' + receipt['Receipt[ProductName]'] + '</td></tr>' : ''}
          ${receipt['Receipt[ProductCountry]'] ? '<tr><td>Country:</td><td>' + receipt['Receipt[ProductCountry]'] + '</td></tr>' : ''} 
          ${receipt['Receipt[PhoneNumber]'] ? '<tr><td>Phone Number:</td><td>' + receipt['Receipt[PhoneNumber]'] + '</td></tr>' : ''} 
          ${receipt['Receipt[EmailAccount]'] ? '<tr><td>Email Account:</td><td>' + receipt['Receipt[EmailAccount]'] + '</td></tr>' : ''} 
          ${receipt['Receipt[CarrierName]'] ? '<tr><td>Carrier:</td><td>' + receipt['Receipt[CarrierName]'] + '</td></tr>' : ''} 
           <tr>
              <td>Access Numbers:</td>
            </tr>
            ${receipt['Receipt[ProductInstructions]'] ? '<tr><td>Terms and Conditions:</td><td>http://terms.blackstonepos.com</td></tr>': ''} 

            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
            ${receipt['Receipt[Amount]'] ? '<tr><td>Amount:</td><td>' + receipt['Receipt[Amount]'] + '</td></tr>' : ''}
            ${receipt['Receipt[Fee]'] ? '<tr><td>Fee:</td><td>' + receipt['Receipt[Fee]'] + '</td></tr>' : ''}

            ${receipt['Receipt[Tax]'] ? '<tr><td>Tax:</td><td>' + receipt['Receipt[Tax]'] + '</td></tr>' : ''}
            
            ${receipt['Receipt[Total]'] ? '<tr><td>Total:</td><td>' + receipt['Receipt[Total]'] + '</td></tr>' : ''}

            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
  
            ${receipt['Receipt[AccountNumber]'] ? '<tr><td>AccountNumber:</td><td>***' + receipt['Receipt[AccountNumber]'] + '</td></tr>' : ''}
            ${receipt['Receipt[PinNumber]'] ? '<tr><td>Pin Number:</td><td>' + receipt['Receipt[PinNumber]'] + '</td></tr>' : ''}
            ${receipt['Receipt[ControlNumber]'] ? '<tr><td>Control Number:</td><td>' + receipt['Receipt[ControlNumber]'] + '</td></tr>' : ''}
            ${receipt['Receipt[OrderNumber]'] ? '<tr><td>Order Number:</td><td>' + receipt['Receipt[OrderNumber]'] + '</td></tr>' : ''}
            ${receipt['Receipt[TransactionId]'] ? '<tr><td>Transaction Id:</td><td>' + receipt['Receipt[TransactionId]'] + '</td></tr>' : ''}


            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
            
            ${receipt['Receipt[MerchantName]'] ? '<tr><td>Merchant Name:</td><td>' + receipt['Receipt[MerchantName]'] + '</td></tr>' : ''}
            ${receipt['Receipt[CashierName]'] ? '<tr><td>Cashier Name:</td><td>' + receipt['Receipt[CashierName]'] + '</td></tr>' : ''}
            ${receipt['Receipt[MerchantAddress]'] ? '<tr><td>Address:</td><td>' + receipt['Receipt[MerchantAddress]'] + '</td></tr>' : ''}
            ${receipt['Receipt[MerchantPhoneNumber]'] ? '<tr><td>Merchant Phone:</td><td>' + receipt['Receipt[MerchantPhoneNumber]'] + '</td></tr>' : ''}
            ${receipt['Receipt[OrderDate]'] ? '<tr><td>Transaction Date:</td><td>' + (new Date(receipt['Receipt[OrderDate]']).toGMTString()) + '</td></tr>' : ''}

            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div></body></html>`;
    }
}