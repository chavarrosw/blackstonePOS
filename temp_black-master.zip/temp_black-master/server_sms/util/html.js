module.exports = {
    receipt: (vm) => {
        return `<html><head><title>Invoice</title></head><body><div id="myReceiptProduct" class="col-xs-12 col-sm-9 col-md-9">
        <h3>Receipts Sunpass Portal</h3>
        <table class="table-condensed receipt">
          <tbody>
          ${vm.receipt.ProductName ? '<tr><td>Product Name:</td><td>' + vm.receipt.ProductName + '</td></tr>' : ''}
          ${vm.receipt.ProductCountry ? '<tr><td>Country:</td><td>' + vm.receipt.ProductCountry + '</td></tr>' : ''} 
          ${vm.receipt.PhoneNumber ? '<tr><td>Phone Number:</td><td>' + vm.receipt.PhoneNumber + '</td></tr>' : ''} 
          ${vm.receipt.EmailAccount ? '<tr><td>Email Account:</td><td>' + vm.receipt.EmailAccount + '</td></tr>' : ''} 
          ${vm.receipt.CarrierName ? '<tr><td>Carrier:</td><td>' + vm.receipt.CarrierName + '</td></tr>' : ''} 
           <tr>
              <td>Access Numbers:</td>
            </tr>
            ${vm.receipt.ProductInstructions ? '<tr><td>Terms and Conditions:</td><td>http://terms.blackstonepos.com</td></tr>': ''} 

            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
            ${vm.receipt.Amount ? '<tr><td>Amount:</td><td>' + vm.receipt.Amount + '</td></tr>' : ''}
            ${vm.receipt.Fee ? '<tr><td>Fee:</td><td>' + vm.receipt.Fee + '</td></tr>' : ''}

            ${vm.receipt.Tax ? '<tr><td>Tax:</td><td>' + vm.receipt.Tax + '</td></tr>' : ''}
            
            ${vm.receipt.Total ? '<tr><td>Total:</td><td>' + vm.receipt.Total + '</td></tr>' : ''}

            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
  
            ${vm.receipt.AccountNumber ? '<tr><td>AccountNumber:</td><td>***' + vm.receipt.AccountNumber + '</td></tr>' : ''}
            ${vm.receipt.PinNumber ? '<tr><td>Pin Number:</td><td>' + vm.receipt.PinNumber + '</td></tr>' : ''}
            ${vm.receipt.ControlNumber ? '<tr><td>Control Number:</td><td>' + vm.receipt.ControlNumber + '</td></tr>' : ''}
            ${vm.receipt.OrderNumber ? '<tr><td>Order Number:</td><td>' + vm.receipt.OrderNumber + '</td></tr>' : ''}
            ${vm.receipt.TransactionId ? '<tr><td>Transaction Id:</td><td>' + vm.receipt.TransactionId + '</td></tr>' : ''}


            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
            
            ${vm.receipt.MerchantName ? '<tr><td>Merchant Name:</td><td>' + vm.receipt.MerchantName + '</td></tr>' : ''}
            ${vm.receipt.CashierName ? '<tr><td>Cashier Name:</td><td>' + vm.receipt.CashierName + '</td></tr>' : ''}
            ${vm.receipt.MerchantAddress ? '<tr><td>Address:</td><td>' + vm.receipt.MerchantAddress + '</td></tr>' : ''}
            ${vm.receipt.MerchantPhoneNumber ? '<tr><td>Merchant Phone:</td><td>' + vm.receipt.MerchantPhoneNumber + '</td></tr>' : ''}
            ${vm.receipt.OrderDate ? '<tr><td>Transaction Date:</td><td>' + (new Date(vm.receipt.OrderDate).toGMTString()) + '</td></tr>' : ''}

            <tr>
              <td colspan="2">
                <div class="divider"></div>
              </td>
            </tr>
          </tbody>
        </table>
      </div></body></html>`;
    }
}