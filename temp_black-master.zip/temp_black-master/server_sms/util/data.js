module.exports = {

    /*
    smsWireless: (data, dateT) => {
        return `You've purchased an Wireless TopUp. *~US 
        \nMobile Number: ${data["Receipt[MerchantPhoneNumber]"]}. 
        \nPIN: ${data["Receipt[PinNumber]"]}. 
        \nAmount: ${data["Receipt[Amount]"]}. 
        \nProduct Name: ${data["Receipt[ProductName]"]}.
        \nTrx Date: ${dateT}. 
        \nTrx Ref: ${data["Receipt[OrderNumber]"]}.
        \nMerchant Name: ${data["Receipt[MerchantName]"]}.`
    },
    */
    smsWireless: (data, dateT) => {
        return `You've purchased an Wireless TopUp, nAmount: ${data["Receipt[Amount]"]}, Product Name: ${data["Receipt[ProductName]"]}.`
    },

    /*
    smsLongdistance: (data, dateT) => {
        return `You've purchased an Intl Mob TopUp.
        \nNumber Recharged: ${data["Receipt[MerchantPhoneNumber]"]}. 
        \nCountry: ${data["Receipt[ProductCountry]"]}.
        \nOperator: ${data["Receipt[CarrierName]"]}.
        \nAmount: ${data["Receipt[Amount]"]}. 
        \nProduct Name: ${data["Receipt[ProductName]"]}.
        \nTrx Date: ${dateT}. 
        \nTrx Ref: ${data["Receipt[OrderNumber]"]}.
        \nMerchant Name: ${data["Receipt[MerchantName]"]}.
        \nCustomer Service: 1888-684-7323.`
    },
    */

    smsLongdistance: (data, dateT) => {
        return `You've purchased an Intl Mob TopUp, Amount: ${data["Receipt[Amount]"]}, Product Name: ${data["Receipt[ProductName]"]}`
    },

    // smsInternational: (data, dateT) => {
    //     return `You've purchased an ePIN.
    //     \nAmount: ${data["Receipt[Amount]"]}. 
    //     \nProduct Name: ${data["Receipt[ProductName]"]}.
    //     \nTrx Date: ${dateT}. 
    //     \nTrx Ref: ${data["Receipt[OrderNumber]"]}.
    //     \nMerchant Name: ${data["Receipt[MerchantName]"]}.
    //     \nCustomer Service: 1888-684-7323.`
    // },

    smsInternational: (data, dateT) => {
        return `You've purchased an ePIN, Amount: ${data["Receipt[Amount]"]}, Product Name: ${data["Receipt[ProductName]"]}.`
    },

    // smsPinless: (data, dateT) => {
    //     return `You've purchased a Pinless.
    //     \nMobile Number: ${data["Receipt[MerchantPhoneNumber]"]}. 
    //     \nAmount: ${data["Receipt[Amount]"]}. 
    //     \nProduct Name: ${data["Receipt[ProductName]"]}.
    //     \nTrx Date: ${dateT}. 
    //     \nTrx Ref: ${data["Receipt[OrderNumber]"]}.
    //     \nMerchant Name: ${data["Receipt[MerchantName]"]}.`
    // },

    smsPinless: (data, dateT) => {
        return `You've purchased a Pinless, Amount: ${data["Receipt[Amount]"]}, Product Name: ${data["Receipt[ProductName]"]}`
    },

    // smsPrepaidOthers: (data, dateT) => {
    //     return `You've purchased an prepaid Others.
    //     \nMobile Number: ${data["Receipt[MerchantPhoneNumber]"]}. 
    //     \nAmount: ${data["Receipt[Amount]"]}. 
    //     \nProduct Name: ${data["Receipt[ProductName]"]}.
    //     \nTrx Date: ${dateT}. 
    //     \nTrx Ref: ${data["Receipt[OrderNumber]"]}.
    //     \nMerchant Name: ${data["Receipt[MerchantName]"]}.`
    // },

    smsPrepaidOthers: (data, dateT) => {
        return `You've purchased an prepaid Others, Amount: ${data["Receipt[Amount]"]}, Product Name: ${data["Receipt[ProductName]"]}.`
    },


    //#region Email
    mailWireless: (data, dateT) => {
        return `<strong> You've purchased an Wireless TopUp. *~US </strong>
        <br><strong> Mobile Number:</strong> ${data["Receipt[MerchantPhoneNumber]"]}. 
        <br><strong>PIN:</strong> ${data["Receipt[PinNumber]"]}. 
        <br><strong>Amount:</strong> ${data["Receipt[Amount]"]}. 
        <br><strong>Product Name:</strong> ${data["Receipt[ProductName]"]}.
        <br><strong>Trx Date:</strong> ${dateT}. 
        <br><strong>Trx Ref:</strong> ${data["Receipt[OrderNumber]"]}.
        <br><strong>Merchant Name:</strong> ${data["Receipt[MerchantName]"]}.`
    },

    mailLongdistance: (data, dateT) => {
        return `<strong> You've purchased an Intl Mob TopUp.</strong>
        <br><strong>Number Recharged:</strong> ${data["Receipt[MerchantPhoneNumber]"]}. 
        <br><strong>Country:</strong> ${data["Receipt[ProductCountry]"]}.
        <br><strong>Operator:</strong> ${data["Receipt[CarrierName]"]}.
        <br><strong>Amount:</strong> ${data["Receipt[Amount]"]}. 
        <br><strong>Product Name:</strong> ${data["Receipt[ProductName]"]}.
        <br><strong>Trx Date:</strong> ${dateT}. 
        <br><strong>Trx Ref:</strong> ${data["Receipt[OrderNumber]"]}.
        <br><strong>Merchant Name:</strong> ${data["Receipt[MerchantName]"]}.
        <br><strong>Customer Service:</strong> 1888-684-7323.`
    },

    mailInternational: (data, dateT) => {
        return `<strong> You've purchased an ePIN.</strong>
        <br><strong>Amount:</strong> ${data["Receipt[Amount]"]}. 
        <br><strong>Product Name:</strong> ${data["Receipt[ProductName]"]}.
        <br><strong>Trx Date:</strong> ${dateT}. 
        <br><strong>Trx Ref:</strong> ${data["Receipt[OrderNumber]"]}.
        <br><strong>Merchant Name:</strong> ${data["Receipt[MerchantName]"]}.
        <br><strong>Customer Service:</strong> 1888-684-7323.`
    },

    mailPinless: (data, dateT) => {
        return `<strong> You've purchased a Pinless.</strong>
        <br><strong>Mobile Number:</strong> ${data["Receipt[MerchantPhoneNumber]"]}. 
        <br><strong>Amount:</strong> ${data["Receipt[Amount]"]}. 
        <br><strong>Product Name:</strong> ${data["Receipt[ProductName]"]}.
        <br><strong>Trx Date:</strong> ${dateT}. 
        <br><strong>Trx Ref:</strong> ${data["Receipt[OrderNumber]"]}.
        <br><strong>Merchant Name:</strong> ${data["Receipt[MerchantName]"]}.`
    },

    mailPrepaidOthers: (data, dateT) => {
        return `<strong> You've purchased an prepaid Others.</strong>
        <br><strong>Mobile Number:</strong> ${data["Receipt[MerchantPhoneNumber]"]}. 
        <br><strong>Amount:</strong> ${data["Receipt[Amount]"]}. 
        <br><strong>Product Name:</strong> ${data["Receipt[ProductName]"]}.
        <br><strong>Trx Date:</strong> ${dateT}. 
        <br><strong>Trx Ref:</strong> ${data["Receipt[OrderNumber]"]}.
        <br><strong>Merchant Name:</strong> ${data["Receipt[MerchantName]"]}.`
    },
    //#end region
}