module.exports = {
    validateCode: (MerchantId, PhoneNumber, code) => {
        const myDay = new Date();
        const arrData = (myDay.toISOString().split('T')[0]).split('-');
        const ddmm = parseInt(arrData[2] + arrData[1], 10);
        let PhoneNumberString = PhoneNumber + '';
        let MerchantIdString = MerchantId + '';
        // Obtenemos los últimos 4 dígitos
        const arrPhoneNumbers = PhoneNumberString.substr(-4, 4).split('');
        // Sumamos los últimos 4 números
        let sumPhone = 0;
        arrPhoneNumbers.forEach(element => {
            sumPhone += parseInt(element, 10);
        });
        // Obtenemos los primeros 5 dígitos
        const arrMID = MerchantIdString.substr(0, 5).split('');
        // Sumamos los últimos 5 dígitos
        let sumMID = 0;
        arrMID.forEach(element => {
            sumMID += parseInt(element, 10);
        });

        // Multiplicamos
        const codeControl = sumPhone * sumMID * ddmm; 

        // Verificamos
        return codeControl === code;
    }
}