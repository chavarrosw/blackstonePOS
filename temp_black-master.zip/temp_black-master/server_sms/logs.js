const db = require('./../db/dbconnection');

module.exports = {
    insertLog: async (req, res) => {
        data = req.body
        const q = `INSERT INTO log_transaction(merchantID,category,productCode,logData,logResponse) OUTPUT Inserted.ID VALUES ('${data.merchantID}','${data.category}','${data.productCode}','${JSON.stringify(data.logData)}','${JSON.stringify(data.logResponse)}');`
        const result = await db.query(q);
        res.json({ id: result.recordsets[0][0].ID });
    },
}