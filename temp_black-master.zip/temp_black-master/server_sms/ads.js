
const advertising = [
  {
    icon: "/assets/images/ads/autoexpreso.png",
    name: "AutoEpreso",
    position: 1,
    url: "http://www.autoexpreso.com"
  },
  {
    icon: "/assets/images/ads/claro.png",
    name: "Claro",
    position: 2,
    url: "http://www.claro.com"
  },
  {
    icon: "/assets/images/ads/att_logo.png",
    name: "AT&T",
    position: 3,
    url: "https://www.att.com"
  },
  {
    icon: "/assets/images/ads/t_mobile.png",
    name: "T-Mobile",
    position: 4,
    url: "https://www.t-mobile.com"
  },
  {
    icon: "/assets/images/ads/claro.png",
    name: "Claro",
    position: 5,
    url: "http://www.claro.com"
  },
];

module.exports = {
  getAds: async (req, res) => {
      res.status(200).json({
          code: 200,
          data: advertising
        })
  }
}